# Firmware_2021
Larger Scope Firmware to ideally contain Middleware's and apps as well
This is meant to be run on the STM Cube IDE. Open STM Cube IDE, make a 
new project and remove all the content of the project and replace it with the 
content from this repo to flash the firmware onto the board.
