#ifndef KISS_FFTAPI_H
#define KISS_FFTAPI_H
#include "kiss_fftr.h"

void fft_init(int nfft);

void compute_realfft(const kiss_fft_scalar *fin, kiss_fft_cpx *fout);

#endif
