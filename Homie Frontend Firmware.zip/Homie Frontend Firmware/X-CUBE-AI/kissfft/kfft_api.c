#include <kfft_api.h>



kiss_fftr_cfg fft_config;


void fft_init(int nfft){
	int inverse_fft = 0;
	fft_config = kiss_fftr_alloc(nfft, inverse_fft, 0, 0);
}

void compute_realfft(const kiss_fft_scalar *fin, kiss_fft_cpx *fout){
	kiss_fftr(fft_config, fin, fout);
}
