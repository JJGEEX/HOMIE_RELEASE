/*
 * circular_buffer.cpp
 *
 *  Created on: Nov 3, 2020
 *      Author: thwai
 */
#include "circular_buffer.hpp"

//constructor, dynamically allocating the buffer
Circular_Buffer::Circular_Buffer (uint32_t my_size){
	write = 0;
	read = 0;
	size = my_size;
	my_array = new int16_t [size];

}

Circular_Buffer::~Circular_Buffer (){
	delete my_array;

}

//reads from data source, writes to the circular buffer returns 1 if success, 0 if overflow
int Circular_Buffer::front_write(int16_t* data, uint32_t length){
	if(write_ready(length)){
		for(uint32_t i=0; i<length; i++){
			my_array[(write + i)%size] = data[i];
		}
		write = (write + length)%size;
		return 1;
	}
	return 0;
}


//writes to data source, reads from the circular buffer
int Circular_Buffer::back_read(int16_t* data, uint32_t length){
	if(read_ready(length)){
		for(uint32_t i=0; i<length; i++){
			data[i] = my_array[(read + i)%size];
		}
		read = (read + length)%size;
		return 1;
	}
	return 0;
}

int Circular_Buffer::back_read_noloop(int16_t* data, uint32_t length)
{
	//uint32_t sizeGot = 0;
	if(read_ready(length)) {
		if(length < (size - read)) // Lucky, we can do the whole thing with 1 memcpy
		{
			memcpy((void*)&data[0], (void*)&my_array[read], (sizeof(int16_t)*length));
			read = (read + length);
			return 1;
		}
		else // We need to do it in 2 memcpy calls
		{
			memcpy((void*)&data[0], (void*)&my_array[read], sizeof(int16_t)*(size-read));
			memcpy((void*)&data[(read+length)%size], (void*)&my_array[0], sizeof(int16_t)*(length-(size-read)));
			read = length-(size-read);
			return 1;
		}
	}
	return 0;
}

// Like the above function, but gets as much as it can and returns
// how much it was able to.
// Naturally, returns 0 if unable to get anythin
uint32_t Circular_Buffer::back_read_more(int16_t* data, uint32_t max_length)
{
	uint32_t sizeGot = 0;
	if(read_ready(max_length)){
		for(uint32_t i=0; i<max_length; i++){
			data[i] = my_array[(read + i)%size];
		}
		read = (read + max_length)%size;
		sizeGot = max_length;
		return sizeGot;
	}
	else
	{
		if(read > write)
			sizeGot = size - read + write;
		else
			sizeGot = write - read;
		return sizeGot;
	}
	//return 0;
}

// checks if there is space to read from to the circular buffer
int Circular_Buffer::read_ready(uint32_t length){
	while(length > size); // makes sure length input is not greater than size of the array
	uint32_t space_left =(write + size - read)%size;
	if(space_left >= length) return 1;
	else return 0;
}

// checks if there is space to write to the circular buffer
int Circular_Buffer::write_ready(uint32_t length){
	while(length > size);// makes sure length input is not greater than size of the array
	if(read > write){
		return (read - write) > length;
	}
	else{
		return (read + size - write) > length;
	}
//	uint32_t current_read_loc = read + size;
//	uint32_t space_left =(read + size - write)%size;
////	if((space_left > length)||(read == write)) return 1;
////	else return 0;
//	return 1;
}

uint32_t Circular_Buffer::get_size(void)
{
	return write - read;
}

//empty's the buffer
void Circular_Buffer::empty_buffer(){
	read = write;
}
