/*
 * error_handing.cpp
 *
 *  Created on: Oct 14, 2020
 *      Author: xavion
 */
#include "error_handling.hpp"

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	while(1);
  /* USER CODE END Error_Handler_Debug */
}



