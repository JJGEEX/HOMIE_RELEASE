/*
 * audio_in.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "audio_in.hpp"

static Circular_Buffer* circular_data_buffer;
static int32_t mic_buffer[MIC_BUFFER_SIZE];
static int16_t mic_compressed_buffer[MIC_BUFFER_SIZE/MIC_FREQ_SCALING];


/*******************************Static Functions****************************/
//for formatting functions
#define LARGEST_NUMBER 131072 //(2^17)
#define COMPLIMENT_NUMBER 262144 //(2^18)


static int twos_compliment(uint32_t x){
	if( x >= LARGEST_NUMBER){
		return x - COMPLIMENT_NUMBER;
	}
	else{
		return (int)x;
	}
}


static int format(uint32_t x){//only the top 18 bits are used out of the 24 bit number
	return twos_compliment(x>>6);
}

/***************************************************************************/




//Constructor for Microphone class
    Mic::Mic(Circular_Buffer* my_buffer, I2S* Mic_i2s){
    	circular_data_buffer = my_buffer;
    	my_i2s = Mic_i2s;
//    	void f = [](void) -> void { mic_callback();};//create a lambda function
    	Mic_i2s->mic_init((void(*)())&mic_callback, mic_buffer, MIC_BUFFER_SIZE);
//    	Mic_i2s->mic_init(&f, mic_buffer, MIC_BUFFER_SIZE);
    }

//Destructor for Microphone class
    Mic::~Mic(){
    }

//callback when mic buffer is full this scales down the data and puts it in a circular buffer
    void mic_callback(void){
    		for(int i=0; i<(MIC_BUFFER_SIZE/2/MIC_FREQ_SCALING); i++){
    			if(MIC_FREQ_SCALING == 1){//no Scale down 32000 samples/ sec
    				mic_compressed_buffer[i] = (int16_t)format(mic_buffer[i]);
    			}
    			else if(MIC_FREQ_SCALING == 2){//divide samples in two averaging the two values 16000 Samples/sec
    				mic_compressed_buffer[i] = (int16_t)((format(mic_buffer[2*i]) + format(mic_buffer[2*i+1]))/2);
    			}
    			else if(MIC_FREQ_SCALING == 8){//divide samples in two averaging the two values 8000 Samples/ sec
    				mic_compressed_buffer[i] = (int16_t)((format(mic_buffer[4*i]) + format(mic_buffer[4*i+1])+format(mic_buffer[4*i+2]) + format(mic_buffer[4*i+3]))/4);
    			}
    			else if(MIC_FREQ_SCALING == 4){//divide samples in two averaging the two values
    				mic_compressed_buffer[i] = (int16_t)((format(mic_buffer[8*i]) + format(mic_buffer[8*i+1])+format(mic_buffer[8*i+2]) + format(mic_buffer[8*i+3])+ format(mic_buffer[8*i+4]) + format(mic_buffer[8*i+5])+format(mic_buffer[8*i+6]) + format(mic_buffer[8*i+7]))/4);
    			}
    			else{
    				Error_Handler();
    			}
    		}
    		if(circular_data_buffer != 0){
    			circular_data_buffer->front_write(mic_compressed_buffer, (MIC_BUFFER_SIZE/2/MIC_FREQ_SCALING));//writes into the circular buffer
    			Homie_Scheduler.add_event(MICDONE_EVENT);
    		}
    }

    void mic_flushBuffers(void)
    {
    	bzero(&mic_buffer[0], MIC_BUFFER_SIZE);
    	bzero(&mic_compressed_buffer[0], MIC_BUFFER_SIZE/MIC_FREQ_SCALING);
    	circular_data_buffer->empty_buffer();
    }
