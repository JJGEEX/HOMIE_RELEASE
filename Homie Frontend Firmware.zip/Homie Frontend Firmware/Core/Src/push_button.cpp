/*
 * push_button.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "push_button.hpp"
#define CFG_BUTTON_SUPPORTED 1

static uint8_t* record;

GPIO_TypeDef* BUTTON_PORT[BUTTONn] = {BUTTON_SW1_GPIO_PORT, BUTTON_SW2_GPIO_PORT, BUTTON_SW3_GPIO_PORT};
const uint16_t BUTTON_PIN[BUTTONn] = {BUTTON_SW1_PIN, BUTTON_SW2_PIN, BUTTON_SW3_PIN};
const uint8_t BUTTON_IRQn[BUTTONn] = {BUTTON_SW1_EXTI_IRQn, BUTTON_SW2_EXTI_IRQn, BUTTON_SW3_EXTI_IRQn};


void SW1(void){
	*record |= 1; // means someone wants to record
	Homie_Scheduler.add_event(PUSHBUTTON_EVENT);
}

EXTI_HandleTypeDef EXTI_InitStruct = {0};

static void BSP_PB_Init(Button_TypeDef Button, ButtonMode_TypeDef ButtonMode)
{
  GPIO_InitTypeDef gpioinitstruct = {0};

  EXTI_ConfigTypeDef pExtiConfig = {0};

  /* Enable the BUTTON Clock */
  BUTTONx_GPIO_CLK_ENABLE(Button);

  /* Configure Button pin as input */
  gpioinitstruct.Pin = BUTTON_PIN[Button];
  gpioinitstruct.Mode = GPIO_MODE_IT_FALLING;
  gpioinitstruct.Pull = GPIO_NOPULL;//GPIO_PULLUP;
  gpioinitstruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(BUTTON_PORT[Button], &gpioinitstruct);

      /* Wait Button pin startup stability */
  HAL_Delay(1);

  EXTI_InitStruct.Line = EXTI_LINE_4;
  pExtiConfig.Line = EXTI_LINE_4;
  pExtiConfig.Mode = EXTI_MODE_INTERRUPT;
//  pExtiConfig.Mode = EXTI_MODE_EVENT;
  pExtiConfig.Trigger = EXTI_TRIGGER_FALLING;
  pExtiConfig.GPIOSel = EXTI_GPIOC;




  HAL_EXTI_SetConfigLine(&EXTI_InitStruct, &pExtiConfig);
  HAL_NVIC_SetPriority((IRQn_Type)BUTTON_IRQn[Button], 5, 7);
  HAL_NVIC_EnableIRQ((IRQn_Type)BUTTON_IRQn[Button]);

}



void Button_Init(uint8_t * mic_record){

	record = mic_record;
    BUTTON_SW1_GPIO_CLK_ENABLE();
    BSP_PB_Init(BUTTON_SW1, BUTTON_MODE_EXTI);
//	  BSP_PB_Init(BUTTON_SW2, BUTTON_MODE_EXTI);
//	  BSP_PB_Init(BUTTON_SW3, BUTTON_MODE_EXTI);


	  return;

}

//overwrites the standard EXTI Callback
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	switch(GPIO_Pin){
	case (BUTTON_SW1_PIN):
		//SW1 Interrupt
		SW1();
	break;

	default:
		while(1);
	break;
	}
}






