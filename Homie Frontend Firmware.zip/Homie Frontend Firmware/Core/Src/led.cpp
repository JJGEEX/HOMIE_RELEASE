/*
 * led.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "led.hpp"


void toggle_LED(int led){

	switch(led){
	case LED2:
		HAL_GPIO_TogglePin(LEDPORT2, LEDPIN2);
		break;
	default:
		while(1);
		break;
	}


}

