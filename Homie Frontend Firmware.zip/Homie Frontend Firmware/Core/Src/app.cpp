/*
 * app.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "app.hpp"
#include "app_data.hpp"



static Mic * my_mic;
Circular_Buffer * my_buffer;
Circular_Buffer * my_output_buffer;
static I2S * my_i2s;
static Speaker * my_speaker;









void STOP_EVNT(void){
//	HAL_Delay(1);
	Homie_Scheduler.add_event(SLEEP_EVENT);
}









//This allows for the setup and initialization of all modules
void app_setup(void){
	  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	  if(HAL_OK != HAL_Init()){
		 while(1);
	  }

	  SystemClock_Config();

	  /* Initialize all configured peripherals */
	  my_buffer = new Circular_Buffer(CIRCULAR_ARRAY_SIZE);
	  my_output_buffer = new Circular_Buffer(CIRCULAR_ARRAY_SIZE);
	  AI_Init(my_buffer);
	  USB_Init(my_buffer);



	  MX_GPIO_Init();

	  MX_RTC_Init();
	  MX_TIM16_Init();

	  //Initialize Audio
	  beep_init(my_output_buffer);
	  my_i2s = new I2S();
	  my_mic = new Mic(my_buffer, my_i2s); //Mic must go first since SAI_A
	  my_speaker = new Speaker(my_output_buffer, my_i2s);

	  //Initialize Visuals
	  Display_test();
	  clear_neoPixels();

	  //Initialize Wifi
	  write_LEDs(_DARK_GREEN);
	  WiFi_Demo(SECRET_SSID, SECRET_PASS, makeIP(192, 168, 0, 115), 5555);
	  //WiFi_resetFortuneCookie();
	  write_LEDs(_CLEAR);
	  // ENABLE INTERRUPTS FOR THE TIMER
	  // These will need to be stopped during transmission functions and the like.
	  HAL_TIM_Base_Start_IT(&htim16);


}

//This allows for configuring to all the applications
void app_config(void){
//	  Homie_Scheduler.init_flag(AI_Guess, I2SDONE_EVENT);
	  Homie_Scheduler.init_flag(I2S_Done, MICDONE_EVENT);//does stream_ping and AI_guess
	  Homie_Scheduler.init_flag(STOP_EVNT, SLEEP_EVENT);
	  Homie_Scheduler.add_event(SLEEP_EVENT);
	  Homie_Scheduler.init_flag(WIFI_PACKETCHECK, PKTCHECK_EVENT);
	  Homie_Scheduler.init_flag(WIFI_STREAMEVT, WIFI_ASEND_EVENT);
	  //Homie_Scheduler.add_event(WIFI_ASEND_EVENT);
//	  Homie_Scheduler.add_event(PKTCHECK_EVENT);
	  //This is for streaming via usb -----------------------------------------------------------
	//  Homie_Scheduler.init_flag(Stream_Ping, I2SDONE_EVENT); //starts sending usb data if available on the circular buffer
	//  Homie_Scheduler.init_flag((void (*)())Open_Stream, PUSHBUTTON_EVENT);
	//  Homie_Scheduler.add_event(PUSHBUTTON_EVENT);
	//------------------------------------------------------------------------------------------------

}







