/*
 * audio_out.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "audio_out.hpp"


static Circular_Buffer* circular_data_buffer;
static int32_t speaker_buffer[SPEAKER_BUFFER_SIZE];//needed 800 extra to prevent issues
static int16_t speaker_compressed_buffer[SPEAKER_BUFFER_SIZE];

//speaker constructor
    Speaker::Speaker(Circular_Buffer* my_buffer, I2S* Mic_i2s){

    	circular_data_buffer = my_buffer;
    	my_i2s = Mic_i2s;
    	Mic_i2s->speaker_init((void(*)())&speaker_callback, speaker_buffer, SPEAKER_BUFFER_SIZE);
    }

//speaker destructor
    Speaker::~Speaker(){

    }

//speaker callback
    /*
    void speaker_callback(void){
    	if(circular_data_buffer->back_read(speaker_compressed_buffer, SPEAKER_BUFFER_SIZE/2)){
    		for(int i=0; i<SPEAKER_BUFFER_SIZE/2; i++){
    			speaker_buffer[i*2] = SPEAKER_SCALING*((int32_t)speaker_compressed_buffer[i]);
    			speaker_buffer[(i*2)+1] = SPEAKER_SCALING*((int32_t)speaker_compressed_buffer[i]);
        		}
    	}
    	else{
    		for(int i=0; i<SPEAKER_BUFFER_SIZE; i++){
    			speaker_buffer[i] = 0;
    		}
    	}

           }
    */

void speaker_callback(void) {
	if (circular_data_buffer->back_read_noloop(speaker_compressed_buffer, SPEAKER_BUFFER_SIZE / 2)) {
		for (int i = 0; i < SPEAKER_BUFFER_SIZE / 2; i++) {
			speaker_buffer[2 * i] = ((int32_t) speaker_compressed_buffer[i]) << 8; //make it fit 24 bit audio
			speaker_buffer[2 * i + 1] = ((int32_t) speaker_compressed_buffer[i]) << 8; //make it fit 24 bit audio
		}
	} else {
		for (int i = 0; i < SPEAKER_BUFFER_SIZE; i++) {
			speaker_buffer[i] = 0;
		}
	}

}

