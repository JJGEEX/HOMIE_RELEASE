/*
 * app_ai.cpp
 *
 *  Created on: Apr 6, 2021
 *      Author: thwai
 */



#include "app_data.hpp"



static bool latch = true;
static uint32_t noReplyCounter = 0;
bool AI_block = true;
bool Stream_block = false;

static bool freeDataStop = false;

void I2S_Done(void){
//	Stream_Ping();
//	AI_Guess();
//	compute_fft();

	if (!AI_block) {
		noReplyCounter = 0;  // We got a reply,  so reset the thing
							 // that watches to see if we get a reply.

		if(freeDataStop == true)
		{
			freeDataStop = false;
			return;
		}

		float x = get_results();
		if (x >= 0) {
			char str[20];

			sprintf(str, " %.4f \n\r", x);
			usb_printf(str);
			if ((x > .60) && latch) {
				latch = false;
				freeDataStop = true;
				write_LEDs(_DARK_BLUE);

				// =============WAKE WORD RECOGNIZED============= //
				AI_block = true;
				Homie_Scheduler.add_event(WIFI_ASEND_EVENT);

				AI_clear_buffer();

				//socket = WiFi_getSocket
				// ============================================== //

				HAL_Delay(500);
				//display_printf("ERROR: PLEASE CONNECT THE HOMIE BACKEND");
				usb_printf((char*) " Stop!\n\r");
				clear_neoPixels();
			} else if (x <= .75) {
				latch = true;
			}
		}
	} else if (Stream_block) {
	//} else {
		noReplyCounter++;
		if(noReplyCounter > 2500)
		{
			//AI_block = false;
			noReplyCounter = 0;
			write_LEDs(_PURE_RED);
			display_printf("NO RESPONSE");
			clear_neoPixels();
			WiFi_kick();
			HAL_Delay(50);
			WiFi_Demo(SECRET_SSID, SECRET_PASS, makeIP(192, 168, 0, 115), 5555);
			AI_block = true;
			Stream_block = false;

		}
	}

}
