/*
 * wifi.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: Xavion Cowans & Grant Capan
 */

#include "usb.hpp"
#include "wifi.hpp"
#include "display.hpp"
#include "stdio.h"
#include "WiFiSocketBuffer.hpp"

// Cached values of retrieved data
static char _ssid[] = {0};
static uint8_t _bssid[] = {0};
static uint8_t _mac[] = {0};
static uint8_t _localIp[] = {0,0,0,0};
static uint8_t _subnetMask[] = {0,0,0,0};
static uint8_t _gatewayIp[] = {0,0,0,0};
static uint8_t _sock;





//Init for the Wifi Module
void WIFI_Init(void){
	airLift.SPI1_open();
	  if(!airLift.initialized)
	  {
		  airLift.begin();
	  }
}




/* uint8_t WiFi_Demo(ssid, pass, IPAddr, port)
 * Description: This function will perform a demonstration of the WiFi functionalities
 * 				implemented using the Adafruit AirLift.
 * 				Call it, and then watch the output of the USB printf messages
 * 				with your favorite Serial Terminal application for further instructions.
 * Parameters:
 * 		char *ssid: Pointer to the character array (C string) containing the SSID
 * 					of the WiFi network you wish to connect to.
 * 		char *pass: Pointer to the character array containing the password
 * 					of the WiFi network you wish to connect to.
 * uint32_t IPAddr: The IP address of the device you wish to connect to, stored
 * 					as a uint32_t.  You must get this from said device.
 * 					You may use the provided "makeIP()" function to create this, i.e.:
 *
 * 			WiFi_Demo("NetworkSSID", "thePassword", makeIP(192, 168, 0, 123), 12345);
 *
 * 	 uint32_t port: The port on which you want to connect.
 * 	 				I've been using 5555 for my testing.
 */
uint8_t WiFi_Demo(char *ssid, char *pass, uint32_t IPAddr, uint32_t port)
{
	//wl_status_t current_status = WL_NO_SHIELD;
	uint8_t current_status = -1;

	airLift.SPI1_open();
	airLift.begin();

	char firmwareVersion[6];
	WiFi_getFirmwareVersion(firmwareVersion);

	current_status = WiFi_getStatus();

	if(current_status == WL_CONNECTED)
	{
		USB_printf("Already connected, skipping WiFi Demo.\n");
		return 0;
	}

	ScanNetworks();

	WiFi_connectWPA(); // Don't forget to put the SSID & WPA of the network
					   // you want to connect to in the SECRET_SSID & SECRET_WPA
					   // defines in wifi.hpp

	//USB_printf("Will now begin periodically printing connection info.\n\n");

	printCurrentNet();

	HAL_Delay(1000);
	USB_printf("Next, get the IP of the AirLift.\n");
	HAL_Delay(1000);

	WiFi_updateLocalInfo();

	//========================
	// TCP SERVER TEST
	//========================
	USB_printf("Start a TCP server.\n");

	uint8_t socketVal = WiFi_getSocket();
	char printBuf[128];
	sprintf(printBuf, "Got socket: %d\n", socketVal);
	USB_printf(printBuf);

	WiFi_startServer(port, socketVal, TCP_MODE);
	uint8_t server_status;
	do {
		server_status = WiFi_getServerState(0);
		if (server_status == 0) {
			USB_printf("Trying again in a second...\n");
			HAL_Delay(1000);
		}
	} while (server_status == 0);
	sprintf(printBuf, "Got server status: %d\n", server_status);
	USB_printf(printBuf);

	sprintf(printBuf, "\nSetup complete, try connecting to me!\n"
					  "Open a terminal on your Linux machine and type:\n\n"
					  "echo \"Hello, AirLift!\" | nc (MY IP ADDRESS) %lu\n",
					  port);
	USB_printf(printBuf);

	//DEBUG: Status printing
	/*sprintf(printBuf, "Will now monitor server status...\n");
	USB_printf(printBuf);
	bool status_changed = false;
	uint8_t lastStatus = 0;
	uint8_t status = 0;*/

	int avBytes;
	uint16_t timesRun = 0;
	bool dataBool = false;
	uint8_t dataBuf[100];
	uint16_t dataLen;
	char sendString[] = "Message received!\n";
	int clientAvailable = 0;

	uint8_t nextSock;

	bool recieved_message = true; // SET TO TRUE, SO SKIPS THE TEST
	while (!recieved_message && timesRun < 50) {
		timesRun++;
		HAL_Delay(200);

		//DEBUG: Status printing
		/*status = WiFi_getServerState(socketVal);
		if (status != lastStatus) {
			lastStatus = status;
			WiFi_DEBUG_printServerStatus(status);
		}*/
		_sock = socketVal;
		avBytes = WiFiServer_availData(socketVal); // This "avBytes" name is actually kind
												   // of deceiving, talk to Grant if you have
												   // questions.
		while (avBytes != 255)
		{
			char c;
			do {
				c = WiFiClient_read(avBytes);
				if (c != 255) // Print the next character of the message
						{
					sprintf(printBuf, "%c", c);
					USB_printf(printBuf);
				} else // Done printing the message, send a reply to the client.
				{
					WiFi_TCP_sendData(0, (uint8_t*) &sendString,
							strlen(sendString));
					//Display_test();
					recieved_message = true;

				}
			} while (c != 255);

			avBytes = WiFiServer_availData(socketVal);
		}
	}
}

const uint16_t tx_max = 1500;
uint8_t audio_buffer[tx_max];

// ======================================= //
// NEW DMA AUDIO STREAMING
// ======================================= //
//uint8_t WiFi_AudioStreamTest(void)
uint8_t WiFi_AudioStreamTest(Circular_Buffer* my_buffer)
{
	// Wait to get some audio
	uint8_t availBytes = -1;
	bool audioPacketWaiting = false;
	char messageBuf[32];
	char audioHDR[] = "APCKT";
	char audioFTR[] = "ADONE";
	//char audioHDR[] = {'A', 'P', 'C', 'K', 'T', 0x7c};

	// STAGE 1 of the process:
	//  Waiting for a notification that the next packet will be audio
	while(!audioPacketWaiting)
	{
		availBytes = WiFiServer_availData(_sock);
		if(availBytes == 255) // Slow down a bit to not overwhelm the AirLift
			HAL_Delay(1);

		uint8_t retLength;
		retLength = WiFiClient_bigRead(availBytes, (uint8_t*)&messageBuf[0], sizeof(messageBuf));

		//if(messageBuf)
		int result = -99;
		if(availBytes != 255)
		{
			messageBuf[sizeof(audioHDR) - 1] = '\0';
			char checkBuf[sizeof(audioHDR)];
			memcpy(checkBuf, messageBuf, sizeof(audioHDR));
			result = strcmp(audioHDR, checkBuf);
			if(audioHDR== checkBuf)
			{
				result = 0;
			}
		}
		if(result == 0)
			audioPacketWaiting = true;
	}

	bool started = false;
	bool audioDone = false;

	while(!audioDone)
	{
		availBytes = WiFiServer_availData(_sock);
		if(availBytes == 255)
			HAL_Delay(1);
		//NEW WAY OF DOING IT: JUST END WHEN OUT OF DATA
		uint16_t retLength = -1;
		retLength = WiFiClient_bigRead(availBytes, (uint8_t*)&audio_buffer[0], sizeof(audio_buffer));

		if(availBytes == 255)
			audioDone = true;
		else // LOAD THE RECEIVED DATA INTO THE BUFFER TO BE PLAYED
			my_buffer->front_write((int16_t*)audio_buffer, retLength/2);

		// if this is broke later put it back
		// OLD WAY
		/*
		availBytes = WiFiServer_availData(_sock);

		uint16_t retLength = -1;
		retLength = WiFiClient_bigRead(availBytes, (uint8_t*)&audio_buffer[0], sizeof(audio_buffer));

		//if(retLength == sizeof(audioHDR))
		if(retLength < 20)
		{
			//int result = -99;
			audio_buffer[sizeof(audioFTR)-1] = '\0';
			char checkBuf[sizeof(audioFTR)];
			memcpy(checkBuf, audio_buffer, sizeof(audioFTR));
			//result = strcmp(audioHDR, checkBuf);
			if(audioFTR == checkBuf)
			{
				audioDone = true;
				volatile uint8_t breakVar = 0;
				breakVar++;
			}
		} else {
			// LOAD THE RECEIVED DATA INTO THE BUFFER TO BE PLAYED
			my_buffer->front_write((int16_t*)audio_buffer, retLength/2);
		}
		*/
	}


	// STAGE 2 of the process:
	//   Fetch the audio packet (whose announcement was detected in stage 1)
	//   and process it so that it can be
	/*while(audioPacketWaiting)
	{
		availBytes = WiFiServer_availData(_sock);

		if(availBytes != 255)
		{
			//audioAmp.play_audio_from_wifi(availBytes);
			audioAmp.fill_buffer_from_wifi(availBytes);
			started = true;
		}
		else if (started)
		{
			volatile uint8_t breakVar = 0;
			if(!audioAmp.play()) {
				USB_printf("done.");
				audioPacketWaiting = false;
			}
			breakVar++;
		}
		//uint8_t retLength;
		//retLength = WiFiClient_bigRead(availBytes, (uint8_t*)&messageBuf[0], sizeof(messageBuf));
	}*/
	return 0;
}

// ======================================= //
// THIS IS THE OLD, NON-DMA STREAM TEST
// ======================================= //
/*
uint8_t WiFi_AudioStreamTest(void)
{
	// Wait to get some audio
	uint8_t availBytes = -1;
	bool audioPacketWaiting = false;
	char messageBuf[32];
	char expectedResult[] = "APCKT";
	//char expectedResult[] = {'A', 'P', 'C', 'K', 'T', 0x7c};

	// STAGE 1 of the process:
	//  Waiting for a notification that the next packet will be audio
	while(!audioPacketWaiting)
	{
		availBytes = WiFiServer_availData(_sock);

		uint8_t retLength;
		retLength = WiFiClient_bigRead(availBytes, (uint8_t*)&messageBuf[0], sizeof(messageBuf));

		//if(messageBuf)
		int result = -99;
		if(availBytes != 255)
		{
			messageBuf[sizeof(expectedResult) - 1] = '\0';
			char checkBuf[sizeof(expectedResult)];
			memcpy(checkBuf, messageBuf, sizeof(expectedResult));
			result = strcmp(expectedResult, checkBuf);
			if(expectedResult == checkBuf)
			{
				result = 0;
			}
		}
		if(result == 0)
			audioPacketWaiting = true;
	}

	bool started = false;
	// STAGE 2 of the process:
	//   Fetch the audio packet (whose announcement was detected in stage 1)
	//   and process it so that it can be
	while(audioPacketWaiting)
	{
		availBytes = WiFiServer_availData(_sock);

		if(availBytes != 255)
		{
			//audioAmp.play_audio_from_wifi(availBytes);
			audioAmp.fill_buffer_from_wifi(availBytes);
			started = true;
		}
		else if (started)
		{
			volatile uint8_t breakVar = 0;
			if(!audioAmp.play()) {
				USB_printf("done.");
				audioPacketWaiting = false;
			}
			breakVar++;
		}
		//uint8_t retLength;
		//retLength = WiFiClient_bigRead(availBytes, (uint8_t*)&messageBuf[0], sizeof(messageBuf));
	}
	return 0;
} */

// uint8_t WiFi_packetCheckEvent(void):
//
// Returns the value of the socket on which bytes are available.
// If it returns 255, there are none available.
uint8_t WiFi_packetCheckEvent(void)
{
	uint8_t returnVal;
	returnVal = WiFiServer_availData(_sock);

	return returnVal;
}


void WiFi_kick(void)
{
	 HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin,GPIO_PIN_RESET);   //setting the reset (ACTIVE LOW)
	 HAL_Delay(1000); //delay
	 HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin,GPIO_PIN_SET);   //clearing the reset
	 //HAL_Delay(1000); //delay
}

/* Is this setup function still necessary?
 * 		-Grant
 */
void Wifi_setup(void){
 HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin,GPIO_PIN_RESET);   //setting the reset (ACTIVE LOW)
 HAL_Delay(1000); //delay
 HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin,GPIO_PIN_SET);   //clearing the reset
 HAL_Delay(1000); //delay
 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_SET); //chip select
 //char WIFI_TX_TEST_DATA[16] = {'0','x','3','7'};  //the command to
 //char WIFI_TX_TEST_DATA = 0x37;
 uint8_t WIFI_TX_TEST_DATA = 0x37;
 //SPI1_send((uint8_t*) WIFI_TX_TEST_DATA);
 //SPI1_expectResponse();
 //SPI1_send(&WIFI_TX_TEST_DATA, sizeof(WIFI_TX_TEST_DATA));
 //SPI1_receive((uint8_t*) WIFI_RX_DATA);

}

void WiFi_updateLocalInfo(void)
{
	char printBuf[40];
	uint8_t *IP_ptr = &_localIp[0];
	uint8_t *mask_ptr = &_subnetMask[0];
	uint8_t *gate_ptr = &_gatewayIp[0];

	WiFi_getNetworkData(IP_ptr, mask_ptr, gate_ptr);

	sprintf(printBuf, "Got Network Data.\n");
	USB_printf(printBuf);

	sprintf(printBuf, "IP Address: %d.%d.%d.%d\n", _localIp[0], _localIp[1], _localIp[2], _localIp[3]);
	USB_printf(printBuf);
	sprintf(printBuf, "Subnet Mask: %d.%d.%d.%d\n", _subnetMask[0], _subnetMask[1], _subnetMask[2], _subnetMask[3]);
	USB_printf(printBuf);
	sprintf(printBuf, "Gateway IP: %d.%d.%d.%d\n", _gatewayIp[0], _gatewayIp[1], _gatewayIp[2], _gatewayIp[3]);
	USB_printf(printBuf);
}

void WiFi_getNetworkData(uint8_t *ip, uint8_t *mask, uint8_t *gwip)
{
    tParam params[PARAM_NUMS_3] = { {0, (char*)ip}, {0, (char*)mask}, {0, (char*)gwip}};

    airLift.waitForSlaveReady();

    airLift.spiSlaveSelect();

    // Send Command
    airLift.sendCmd(GET_IPADDR_CMD, PARAM_NUMS_1);

    uint8_t _dummy = DUMMY_DATA;
    airLift.sendParam(&_dummy, sizeof(_dummy), LAST_PARAM);

    // pad to multiple of 4
    airLift.readChar();
    airLift.readChar();

    airLift.spiSlaveDeselect();
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    airLift.waitResponseParams(GET_IPADDR_CMD, PARAM_NUMS_3, params);

    airLift.spiSlaveDeselect();
}

void WiFi_getFirmwareVersion(char * fw_data){

	//volatile uint8_t breakVal = 0;
	  char fv[FW_VER_LENGTH];
	  for(unsigned int i = 0; i < sizeof(fv); i++)
		  fv[i] = 0;
	  if(!airLift.initialized)
	  {
		  airLift.begin();
	  }
	  airLift.waitForSlaveReady();
	  airLift.spiSlaveSelect();
	  // Send Command

	  airLift.sendCmd(GET_FW_VERSION_CMD, PARAM_NUMS_0);

	  airLift.spiSlaveDeselect();
	  HAL_Delay(100);
	  // Wait for the reply to be ready
	  airLift.waitForSlaveReady();
	  airLift.spiSlaveSelect();

	  // Wait for reply
	  uint8_t _dataLen = 0;
	  airLift.waitResponseCmd(GET_FW_VERSION_CMD, PARAM_NUMS_1, (uint8_t*)fv, &_dataLen);

	  for(unsigned int j = 0; j < sizeof(fv); j++)
	  {
		  fw_data[j] = fv[j];
	  }

	  airLift.spiSlaveDeselect();

	  USB_printf((char*)"Firmware version = ");
	  USB_printf(fv);
	  USB_printf((char*)"\n");
	  return;

}

uint8_t WiFi_getStatus(void)
{
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(GET_CONN_STATUS_CMD, PARAM_NUMS_0);

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = -1;
	uint8_t _dataLen = 0;
	//while(!airLift.waitResponseCmd(GET_CONN_STATUS_CMD, PARAM_NUMS_1, &_data, &_dataLen)){};
	airLift.waitResponseCmd(GET_CONN_STATUS_CMD, PARAM_NUMS_1, &_data, &_dataLen);

	airLift.spiSlaveDeselect();
	return _data;
}

///////please enter your sensitive data in the Secret tab/arduino_secrets.h
char ssid[] = SECRET_SSID;        // your network SSID (name)
char pass[] = SECRET_PASS;    // your network password (use for WPA, or use as key for WEP)
int status = WL_IDLE_STATUS;     // the Wifi radio's status

int8_t wifiSetPassphrase(const char* ssid, uint8_t ssid_len, const char *passphrase, const uint8_t len)
{
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
    // Send Command
    airLift.sendCmd(SET_PASSPHRASE_CMD, PARAM_NUMS_2);
    airLift.sendParam((uint8_t*)ssid, ssid_len, NO_LAST_PARAM);
    airLift.sendParam((uint8_t*)passphrase, len, LAST_PARAM);

    // pad to multiple of 4
    int commandSize = 6 + ssid_len + len;
    while (commandSize % 4) {
        airLift.readChar();
        commandSize++;
    }

    airLift.spiSlaveDeselect();
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    uint8_t _data = 0;
    uint8_t _dataLen = 0;
    if (!airLift.waitResponseCmd(SET_PASSPHRASE_CMD, PARAM_NUMS_1, &_data, &_dataLen))
    {
        //WARN("error waitResponse");
        _data = WL_FAILURE;
    }
    airLift.spiSlaveDeselect();
    return _data;
}

int8_t WiFi_connectWPA(void)
{
	uint8_t status = WL_IDLE_STATUS;
	uint8_t attempts = WL_MAX_ATTEMPT_CONNECTION;
	// set passphrase
	while(status != WL_CONNECTED)
	{
		USB_printf("Attempting to connect to WPA SSID: ");
		USB_printf(ssid);
		USB_printf("\n");
		if (wifiSetPassphrase(ssid, strlen(ssid), pass, strlen(pass))!= WL_FAILURE)
		{
			do
			{
				//delay(WL_DELAY_START_CONNECTION);
				//HAL_Delay(5000);
				display_printf("CONNECTING");
				status = WiFi_getStatus();
			}
			while ((( status == WL_IDLE_STATUS)||(status == WL_NO_SSID_AVAIL)||(status == WL_SCAN_COMPLETED))&&(--attempts>0));
		}else{
			status = WL_CONNECT_FAILED;
			return status;
		}
		// wait 5 seconds for connection:
		//display_printf("TRYING TO CONNECT...");
		//HAL_Delay(5000);
	}
	uint8_t colors[3] = {30, 0xD0, 30};
	neo_write_LEDs(colors);
	display_printf("DONE");
	USB_printf("You're connected to the network.\n");
	colors[0] = 0;
	colors[1] = 0;
	colors[2] = 0;
	neo_write_LEDs(colors);

	return status;
}

void WiFi_setSock(uint8_t newSock)
{
	_sock = newSock;
}




void printCurrentNet(void)
{
	char printString[40];
	//char *printValPtr = printString;
	char SSID[32];
	char *ssid_ptr = SSID;
	ssid_ptr = WiFi_getCurrentSSID();

	// print the SSID of the network you're attached to:
	sprintf(printString, "SSID: %s\n", ssid_ptr);
	USB_printf(printString);

	// print the MAC address of the router you're attached to:
	uint8_t *bssid_ptr = _bssid;
	char bssid_formatted[20];
	bssid_ptr = WiFi_getCurrentBSSID();
	sprintf(printString, "%s", "BSSID: ");
	USB_printf(printString);
	printMacAddress(bssid_ptr);

	// print the received signal strength:
	long rssi = WiFi_getCurrentRSSI();
	sprintf(printString, "signal strength (RSSI):\n%ld\n", rssi);
	USB_printf(printString);

	// print the encryption type:
	uint8_t encryption = WiFi_getCurrentEncryptionType();
	sprintf(printString, "Encryption Type:\n%x\n\n", encryption);
	USB_printf("\n");
}

char* WiFi_getCurrentSSID()
{
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(GET_CURR_SSID_CMD, PARAM_NUMS_1);

	uint8_t _dummy = DUMMY_DATA;
	airLift.sendParam(&_dummy, 1, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();
	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	memset(_ssid, 0x00, sizeof(_ssid));

	// Wait for reply
	uint8_t _dataLen = 0;
	airLift.waitResponseCmd(GET_CURR_SSID_CMD, PARAM_NUMS_1, (uint8_t*)_ssid, &_dataLen);

	airLift.spiSlaveDeselect();

    return _ssid;
}

uint8_t* WiFi_getCurrentBSSID()
{
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(GET_CURR_BSSID_CMD, PARAM_NUMS_1);

	uint8_t _dummy = DUMMY_DATA;
	airLift.sendParam(&_dummy, 1, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();
	airLift.spiSlaveDeselect();

	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _dataLen = 0;
	airLift.waitResponseCmd(GET_CURR_BSSID_CMD, PARAM_NUMS_1, _bssid, &_dataLen);

	airLift.spiSlaveDeselect();

    return _bssid;
}

int32_t WiFi_getCurrentRSSI()
{
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(GET_CURR_RSSI_CMD, PARAM_NUMS_1);

	uint8_t _dummy = DUMMY_DATA;
	airLift.sendParam(&_dummy, 1, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();

	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _dataLen = 0;
	int32_t rssi = 0;
	airLift.waitResponseCmd(GET_CURR_RSSI_CMD, PARAM_NUMS_1, (uint8_t*)&rssi, &_dataLen);

	airLift.spiSlaveDeselect();

    return rssi;
}

uint8_t WiFi_getCurrentEncryptionType()
{
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(GET_CURR_ENCT_CMD, PARAM_NUMS_1);

	uint8_t _dummy = DUMMY_DATA;
	airLift.sendParam(&_dummy, 1, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();

	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _dataLen = 0;
	uint8_t encType= 0;
	airLift.waitResponseCmd(GET_CURR_ENCT_CMD, PARAM_NUMS_1, (uint8_t*)&encType, &_dataLen);

	airLift.spiSlaveDeselect();

    return encType;
}

void printMacAddress(uint8_t mac[])
{
	char zero = '0';
	char sep = ':';
	char nl = '\n';
	char holder[5];
	for (int i = 5; i >= 0; i--) {
		if(mac[i] < 16)
			USB_printf("0");
		sprintf(holder, "%x", mac[i]);
		USB_printf(holder);
		if (i > 0) {
			USB_printf(":");
		}
	}
	USB_printf("\n");
}

void ScanNetworks(void)
{
	//clear multi demsional array

	uint8_t attempts = NUM_NETWORK_ATTEMPTS;
	uint8_t NumOfNetworks = 0;
	char netString[MAX_SSID_LENGTH];
	char StringPrint[40];

	//-----------------------------------------------------------
	//start scanning networks
	//------------------------------------------------------------

	airLift.waitForSlaveReady();

	//select the right slave
	airLift.spiSlaveSelect();
	//Send Command
	airLift.sendCmd(START_SCAN_NETWORKS, PARAM_NUMS_0);  //may have to send "start scan networks" first

	airLift.spiSlaveDeselect();
	//wait for slave to be ready
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();


	//waiting for reply
	uint8_t nw_data = 0;
	uint8_t nw_datalen = 0;

	if(!airLift.waitResponseCmd(START_SCAN_NETWORKS, PARAM_NUMS_1, &nw_data, &nw_datalen)) //can a while loop suffice?
	{
		printf("error in waitResponse");
		nw_data = WL_FAILURE;
	}

	airLift.spiSlaveDeselect();

	//-----------------------------------------------------------
	//finished  the start of scanning networks
	//------------------------------------------------------------

	// MUST INSERT A DELAY HERE!! This value of 500 is definitely overkill, but
	// it is required that the slave be DESELECTED for a sufficiently long
	// time before the next interaction can be performed.
	// Otherwise, the AirLift can stop responding altogether.
	// --Grant
	HAL_Delay(500);

	//-----------------------------------------------------------
	//get scanning networks
	//------------------------------------------------------------

	airLift.waitForSlaveReady();
	//select the right slave
	airLift.spiSlaveSelect();
	//Send  scan networks Command
	airLift.sendCmd(SCAN_NETWORKS, PARAM_NUMS_0);

	airLift.spiSlaveDeselect();
	//wait for slave to be ready
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();


	uint8_t ssidListNum = 0;  //number of ssids returned
	airLift.waitResponse(SCAN_NETWORKS, &ssidListNum, (uint8_t**) networkSSID, MAX_NETWORK_LIST);

	airLift.spiSlaveDeselect();

	//printf("%s",ssidListNum);

	if(ssidListNum == -1)
	{
		//sprintf(printString, "Could not find wifi networks");
		USB_printf("Could not find any wifi Networks");
		while(true);
	}


	//USB_printf("Number of Networks: ");
	sprintf(StringPrint, "Number of Networks: %d", ssidListNum);
	USB_printf(StringPrint);
	USB_printf("\n");

	//-----------------------------------------------------------
	//finished scanning networks
	//------------------------------------------------------------

	//-----------------------------------------------------------
	//start displaying networks
	//------------------------------------------------------------

	int thisNet = 0;

	while(thisNet < ssidListNum)
	{
		//Format Networks-----------------------------------------
		uint8_t zero_flag = 0;
		uint8_t string_index = 0;
		for(int i=0; i<MAX_SSID_LENGTH; i++){
			if(networkSSID[thisNet][i]){//not null character
				networkSSID[thisNet][string_index++] = networkSSID[thisNet][i]; //move string pointer to the start of the non null characters
			}
			else if(zero_flag){
				networkSSID[thisNet][string_index] = 0;
				break;
			}
		}
		//--------------------------------------------------------

		sprintf(netString, "SSID: %s", networkSSID[thisNet]);
		USB_printf(netString);
		//USB_printf("SSID: ");
		//USB_printf(networkSSID[thisNet]);
		USB_printf("\n");
		thisNet++;

	}
}

int16_t INTERNAL_ping(uint32_t ipAddress, uint8_t ttl)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(PING_CMD, PARAM_NUMS_2);
	airLift.sendParam((uint8_t*)&ipAddress, sizeof(ipAddress), NO_LAST_PARAM);
	airLift.sendParam((uint8_t*)&ttl, sizeof(ttl), LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint16_t _data;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseCmd(PING_CMD, PARAM_NUMS_1, (uint8_t*)&_data, &_dataLen))
	{
		USB_printf("INTERNAL_ping Error\n");
		_data = WL_PING_ERROR;
	}
	airLift.spiSlaveDeselect();
	return _data;
}

int WiFiPing(const char* hostName, uint8_t ttl)
{
	uint32_t ip;
	char printBuf[32];

	if (!WiFi_getHostByName(hostName, &ip)) {
		return WL_PING_UNKNOWN_HOST;
	}

	//sprintf(printBuf, "IP: %lu\n", ip);
	//USB_printf(printBuf);

	//sprintf(printBuf, "Formatted: %d.%d.%d.%d\n", ((uint8_t)ip & 0xff), ((uint8_t)(ip & 0xff00)>>8), ((uint8_t)(ip & 0xff0000)>>16), ((uint8_t)(ip & 0xff000000)>>24));
	sprintf(printBuf, "IP: %u.%u.%u.%u\n", ((uint8_t)(ip & 0xff)), ((uint8_t)((ip>>8) & 0xff)), ((uint8_t)((ip>>16) & 0xff)), ((uint8_t)((ip>>24) & 0xff)));
	USB_printf(printBuf);
	HAL_Delay(250);

	//sprintf(printBuf, "Cheating, hardcoded IP to 37.210.45.2...\n");
	//USB_printf(printBuf);
	//ip = 50343205;

	return INTERNAL_ping(ip, ttl);
}

/*int WifiPing(uint32_t ipAddress){

	int local_return = 0;
	char PingPrint[30];
	//char ipAddress[20];

	airLift.waitForSlaveReady();

	//select the right slave
	airLift.spiSlaveSelect();
	//Send Command
	airLift.sendCmd(PING_CMD, PARAM_NUMS_1);  //may need this to be PARAM_NUM_2 but we shall see
	airLift.sendParam((uint8_t*)&ipAddress, sizeof(ipAddress), LAST_PARAM);

	airLift.readChar();

	airLift.spiSlaveDeselect();
	//wait for slave to be ready
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	//wait for reply
	uint16_t ping_data = 0;
	uint8_t ping_dataLen = 0;
	if(!airLift.waitResponseCmd(PING_CMD, PARAM_NUMS_1, (uint8_t*) &ping_data, &ping_dataLen))
	{
		USB_printf("Error during the Wait Response");
		ping_data = WL_FAILURE;
	}

	airLift.spiSlaveDeselect();

	if(ping_data >= 0){
		sprintf(PingPrint, "Ping Successful! RTT: %d", ping_data);
		USB_printf(PingPrint);
		USB_printf("\n");
		local_return = 0;
	}
	else {
		USB_printf("Ping NOT successful");
		USB_printf("\n");
		local_return = -1;

	}

	return local_return;

}*/

//uint32_t rasPi_ip = 0xC0A82BED;
//uint32_t rasPi_ip = 0xC0A82BE8;
uint32_t rasPi_ip = 0xE82BA8C0;
uint16_t rasPi_port = 10000;
//uint8_t  rasPi_sock = 10;
char testData[] = "Hello, Pi!";

void TEST_connectTCP()
{
	char printBuf[64];
	//uint8_t clientState = -1;
	wl_tcp_state clientState;
	uint8_t interimValue;
	uint8_t rasPi_sock = 255;
	USB_printf("Beginning TCP Test.\n");

	//USB_printf("Getting a socket.\n");
	//rasPi_sock = WiFi_getSocket();


	int result = 0;
	while(!result)
	{
		USB_printf("Calling: WiFi_connect()\n");
		result = WiFi_connect(rasPi_ip, rasPi_port, rasPi_sock);
		HAL_Delay(1000);
	}

	USB_printf("Exited loop.\n");


	USB_printf("\nNow checking TCP Client State on the socket...\n\n");
	interimValue = WiFi_TCP_getClientState(rasPi_sock);
	clientState = (wl_tcp_state)interimValue;
	sprintf(printBuf, "socket %d status: %d\n", rasPi_sock, interimValue);
	USB_printf(printBuf);

	/*USB_printf("\nNow checking TCP Client State on every socket...\n\n");
	for(uint8_t i = 0; i < 255; i++)
	{
		interimValue = WiFi_TCP_getClientState(i);
		clientState = (wl_tcp_state)interimValue;
		sprintf(printBuf, "sock %d result: %d\n", i, interimValue);
		USB_printf(printBuf);
	}*/

	USB_printf("Calling: WiFi_startClient()...\n");
	WiFi_INTERNAL_startClient(rasPi_ip, rasPi_port, rasPi_sock, TCP_MODE);


	USB_printf("\nNow checking TCP Client State on the socket...\n\n");
	interimValue = WiFi_TCP_getClientState(rasPi_sock);
	clientState = (wl_tcp_state)interimValue;
	sprintf(printBuf, "socket %d status: %d\n", rasPi_sock, interimValue);
	USB_printf(printBuf);
	//USB_printf("\nNow checking TCP Client State...\n");
	//WiFi_TCP_getClientState(rasPi_sock);
	USB_printf("Now sending data...\n");
//	WiFi_TCP_sendData(rasPi_sock, (uint8_t *)testData, sizeof(testData));
	WiFi_TCP_sendData(0, (uint8_t *)testData, sizeof(testData));
	USB_printf("Finished.\n");
	HAL_Delay(3000);
}

uint8_t timeToLive = 128;
int pingResult;
char hostName[] = "www.google.com";
//char hostName[] = "www.snkrs.com";
int TEST_pingGoogle()
{
	USB_printf("Pinging ");
	USB_printf(hostName);
	USB_printf(": \n");

	pingResult = WiFiPing(hostName, timeToLive);

	char printString[24];
	sprintf(printString, "result= %d\n", pingResult);
	USB_printf(printString);
	return pingResult;

	//if (pingResult == -1)
	//{
		//USB_printf("Seems broken, kicking...\n");
		//airLift.kick();
	//}
}

#define SERVER "cdn.syndication.twimg.com"
#define PATH   "/widgets/followbutton/info.json?screen_names=adafruit"
int TEST_Adafruit()
{
	USB_printf("Performing Adafruit-provided test. (ported by me)\n");

	uint8_t rasPi_sock = 255;

	if(WiFi_hostConnect(SERVER, 443, rasPi_sock))
	{
		char printBuf[32];
		sprintf(printBuf, "connected to server.\n");
		USB_printf(printBuf);
		sprintf(printBuf, "GET %s HTTP/1.1\n", PATH);
		USB_printf(printBuf);
		sprintf(printBuf, "Host: %s\n", SERVER);
		USB_printf(printBuf);
		sprintf(printBuf, "Connection: close\n");
		USB_printf(printBuf);
		/*USB_printf("connected to server.\n");
		// Make an HTTP request:
		USB_printf("GET " PATH " HTTP/1.1");
		USB_printf("Host: " SERVER);
		USB_printf("Connection: close\n");*/
	}
}


int WiFi_hostConnect(char *host, uint16_t port, uint8_t sock)
{
	//uint8_t  remote_addr[WL_IPV4_LENGTH];
	uint32_t ip;
	uint32_t *ip_ptr;
	if (WiFi_getHostByName(host, ip_ptr))
	{
		//ip = ip_ptr;
		return WiFi_connect(ip, port, sock);
	}
	return 0;
}

const char test_hostname[] = "google.com";
int WiFi_connect(uint32_t ip, uint16_t port, uint8_t sock)
{
	char printBuf[32];
	if (sock != NO_SOCKET_AVAIL)
	{
		//WiFi_stop();
		WiFiClient_stop(&sock);
	}

	USB_printf("Getting a socket...\n");
	sock = WiFi_getSocket();
	sprintf(printBuf, "Got socket: %d\n", sock);
	USB_printf(printBuf);
	//USB_printf("Got socket:\n");
	if (sock != NO_SOCKET_AVAIL)
	{
		//WiFi_startClient(uint32_t(ip), port, sock, TCP_MODE);
		//WiFi_startClientWithHost(test_hostname, sizeof(test_hostname), ip, port, sock, TCP_MODE);
		WiFi_INTERNAL_startClient(ip, port, sock, TCP_MODE);

		//unsigned long start = millis();
		// wait 4 second for the connection to close

		bool connected = false;
		uint16_t delayCounts = 0;
		while(!connected && delayCounts < 10000)
		{
			connected = WiFiClient_connected(sock);
			HAL_Delay(1);
			delayCounts++;
		}

		//if (!WiFiClient_connected(sock))
		if(!connected)
		{
			return 0;
		}
	} else {
		USB_printf("No Socket available");
		return 0;
	}
	return 1;
}

uint32_t makeIP(uint8_t seg1, uint8_t seg2, uint8_t seg3, uint8_t seg4)
{
	uint32_t returnVal = 0;
	returnVal |= seg1;
	returnVal = returnVal<<8;
	returnVal |= seg2;
	returnVal = returnVal<<8;
	returnVal |= seg3;
	returnVal = returnVal<<8;
	returnVal |= seg4;
	return returnVal;
}

/* WiFi_setDNS()
 * validParams: can be used to pick which DNS server to use (AirLift can have 2)
 *
 * EXAMPLE: WiFi_setDNS(1, makeIP(37,235,1,174), 0)
 * 			--> This will make the AirLift use 37.235.1.174 (a FreeDNS server) as the only DNS server.
 */
void WiFi_setDNS(uint8_t validParams, uint32_t dns_server1, uint32_t dns_server2)
{
	airLift.spiSlaveSelect();

    // Send Command
    airLift.sendCmd(SET_DNS_CONFIG_CMD, PARAM_NUMS_3);
    airLift.sendParam((uint8_t*)&validParams, 1, NO_LAST_PARAM);
    airLift.sendParam((uint8_t*)&dns_server1, 4, NO_LAST_PARAM);
    airLift.sendParam((uint8_t*)&dns_server2, 4, LAST_PARAM);

    airLift.spiSlaveDeselect();
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    uint8_t _data = 0;
    uint8_t _dataLen = 0;
    if (!airLift.waitResponseCmd(SET_DNS_CONFIG_CMD, PARAM_NUMS_1, &_data, &_dataLen))
    {
    	USB_printf("WiFi_setDNS Error\n");
        //WARN("error waitResponse");
        _data = WL_FAILURE;
    }
    airLift.spiSlaveDeselect();
}


uint8_t WiFi_reqHostByName(const char* aHostname)
{
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(REQ_HOST_BY_NAME_CMD, PARAM_NUMS_1);
	airLift.sendParam((uint8_t*)aHostname, strlen(aHostname), LAST_PARAM);

	// pad to multiple of 4
	int commandSize = 5 + strlen(aHostname);
	while (commandSize % 4) {
		airLift.readChar();
		commandSize++;
	}

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	uint8_t result = airLift.waitResponseCmd(REQ_HOST_BY_NAME_CMD, PARAM_NUMS_1, &_data, &_dataLen);

	airLift.spiSlaveDeselect();

	if (result) {
		result = (_data == 1);
	}

	HAL_Delay(200);
	//HAL_Delay(340);
	return result;
}

int INTERNAL_getHostByName(uint32_t **aResult)
{
	uint8_t  _ipAddr[WL_IPV4_LENGTH];
	uint32_t dummy = 0xFFFFFFFF;
	int result = 0;
	uint32_t intermed = 0;

	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(GET_HOST_BY_NAME_CMD, PARAM_NUMS_0);

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseCmd(GET_HOST_BY_NAME_CMD, PARAM_NUMS_1, _ipAddr, &_dataLen))
	{
		USB_printf("INTERNAL_getHostByName Error\n");
	}else{
		//aResult = ((uint32_t&)_ipAddr[3]<<24)|((uint32_t&)_ipAddr[2]<<16)|((uint32_t&)_ipAddr[1]<<8)|((uint32_t&)_ipAddr[0]);
		//uint32_t intermed = 0;
		//aResult = 0;

		for(uint8_t i = 0; i < 4; i++)
		{
			intermed |= (uint32_t)_ipAddr[i]<<(8*i);
		}
		//aResult = (uint32_t*)intermed;
		**aResult = intermed;
		//uint32_t *pointo = &intermed;
		//*aResult = pointo;
		result = (intermed != dummy);
	}
	airLift.spiSlaveDeselect();
	HAL_Delay(200);
	//HAL_Delay(340);
	return result;
}

int WiFi_getHostByName(const char* aHostname, uint32_t* aResult)
{
	uint32_t theval;
	uint32_t *val;
	if (WiFi_reqHostByName(aHostname))
	{
		return INTERNAL_getHostByName(&aResult);
	}else{
		return 0;
	}
}


void WiFi_startClientWithHost(const char* host, uint8_t host_len, uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(START_CLIENT_TCP_CMD, PARAM_NUMS_5);
	airLift.sendParam((uint8_t*)host, host_len);
	airLift.sendParam((uint8_t*)&ipAddress, sizeof(ipAddress));
	airLift.sendParam(port);
	airLift.sendParam(&sock, 1);
    airLift.sendParam(&protMode, 1, LAST_PARAM);

    // pad to multiple of 4
    int commandSize = 17 + host_len;
    while (commandSize % 4) {
    	airLift.readChar();
    	commandSize++;
    }

    airLift.spiSlaveDeselect();
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    uint8_t _data = 0;
    uint8_t _dataLen = 0;
    if (!airLift.waitResponseCmd(START_CLIENT_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
    {
    	//WARN("error waitResponse");
    	USB_printf("error waitResponse\n");
    }
    airLift.spiSlaveDeselect();
}

uint8_t WiFiClient_connected(uint8_t sock)
{
	if (sock == 255) {
		return 0;
	} else if (WiFiSocketBuffer.available(sock)) {
		return 1;
	} else {
		//uint8_t s = WiFiClient_status();
		uint8_t s = WiFi_TCP_getClientState(sock);

		uint8_t result =  !(s == LISTEN || s == CLOSED || s == FIN_WAIT_1 ||
							s == FIN_WAIT_2 || s == TIME_WAIT ||
							s == SYN_SENT || s== SYN_RCVD ||
							(s == CLOSE_WAIT));

		if (result == 0) {
			WiFiSocketBuffer.close(sock);
			sock = 255;
		}

		return result;
	}
}

uint8_t WiFiClient_status(uint8_t sock)
{
	if (sock == 255) {
		return CLOSED;
	} else {
		//return WiFi_getClientState(sock);
		return WiFi_TCP_getClientState(sock);
	}
}

int WiFiClient_available(uint8_t socket)
{
	if (socket != 255)
	{
		return WiFiSocketBuffer.available(socket);
	}

	return 0;
}

int WiFiClient_read(uint8_t socket)
{
	if (!WiFiClient_available(socket))
	{
		return -1;
	}

	uint8_t b;

	WiFiSocketBuffer.read(socket, &b, sizeof(b));

	return b;
}

size_t WiFiClient_bigRead(uint8_t socket, uint8_t* returnArr, size_t capacity)
{
	if (!WiFiClient_available(socket))
	{
		//return -1;
		return 1;
	}

	size_t returnLength = 0;
	returnLength = WiFiSocketBuffer.read(socket, returnArr, capacity);

	//return b;
	return returnLength;
}


void WiFiClient_stop(uint8_t *sock)
{
	if (*sock == 255)
		return;

	WiFi_stopClient(*sock);

	int count = 0;
	// wait maximum 5 secs for the connection to close
	while (WiFiClient_status(*sock) != CLOSED && ++count < 50)
		HAL_Delay(100);

	WiFiSocketBuffer.close((int)&sock);
	*sock = 255;
}

// Start server TCP on port specified
/*void WiFi_stopClient(uint8_t sock)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(STOP_CLIENT_TCP_CMD, PARAM_NUMS_1);
	airLift.sendParam(&sock, 1, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseCmd(STOP_CLIENT_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
	{
		USB_printf("error waitResponse\n");
	}
	airLift.spiSlaveDeselect();
}*/

// Start server TCP on port specified
void WiFi_startServer(uint16_t port, uint8_t sock, uint8_t protMode)
{
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(START_SERVER_TCP_CMD, PARAM_NUMS_3);
	airLift.sendParam(port);
	airLift.sendParam(&sock, 1);
	airLift.sendParam(&protMode, 1, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseCmd(START_SERVER_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
	{
		//WARN("No response to server start");
		USB_printf("No response to server start.\n");
	}
	airLift.spiSlaveDeselect();
}

void WiFi_DEBUG_printServerStatus(uint8_t status)
{
	char printBuf[32];
	switch(status)
	{
	case CLOSED: // 0
		sprintf(printBuf, "Status: CLOSED\n");
		break;
	case LISTEN: // 1
		sprintf(printBuf, "Status: LISTEN\n");
		break;
	case SYN_SENT: // 2... etc
		sprintf(printBuf, "Status: SYN_SENT\n");
		break;
	case SYN_RCVD:
		sprintf(printBuf, "Status: SYN_RCVD\n");
		break;
	case ESTABLISHED:
		sprintf(printBuf, "Status: ESTABLISHED\n");
		break;
	case FIN_WAIT_1:
		sprintf(printBuf, "Status: FIN_WAIT_1\n");
		break;
	case FIN_WAIT_2:
		sprintf(printBuf, "Status: FIN_WAIT_2\n");
		break;
	case CLOSE_WAIT:
		sprintf(printBuf, "Status: CLOSE_WAIT\n");
		break;
	case CLOSING:
		sprintf(printBuf, "Status: CLOSING\n");
		break;
	case LAST_ACK:
		sprintf(printBuf, "Status: LAST_ACK\n");
		break;
	case TIME_WAIT:
		sprintf(printBuf, "Status: TIME_WAIT\n");
		break;
	default:
		sprintf(printBuf, "ERROR: UNKNOWN STATE DETECTED!!\n");
		break;
	}
	USB_printf(printBuf);
}

uint8_t WiFi_getServerState(uint8_t sock)
{
	airLift.spiSlaveSelect();
    // Send Command
    airLift.sendCmd(GET_STATE_TCP_CMD, PARAM_NUMS_1);
    airLift.sendParam(&sock, sizeof(sock), LAST_PARAM);

    // pad to multiple of 4
    airLift.readChar();
    airLift.readChar();

    airLift.spiSlaveDeselect();
    HAL_Delay(50);
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    uint8_t _data = 0;
    uint8_t _dataLen = 0;
    if (!airLift.waitResponseCmd(GET_STATE_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
    {
    	USB_printf("Error: Failed to get server state.\n");
        //WARN("error waitResponse");
    }
    airLift.spiSlaveDeselect();
   return _data;
}

bool WiFiServer_getData(uint8_t sock, uint8_t *data, uint8_t peek)
//bool WiFiServer_getData(uint8_t sock, uint8_t *data)
{
	//WAIT_FOR_SLAVE_SELECT();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(GET_DATA_TCP_CMD, PARAM_NUMS_2);
	airLift.sendParam(&sock, sizeof(sock));
	airLift.sendParam(peek, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseData8(GET_DATA_TCP_CMD, &_data, &_dataLen))
	{
		//WARN("error waitResponse");
		USB_printf("error in WiFiServer_getData()\n");
	}
	airLift.spiSlaveDeselect();
	if (_dataLen!=0)
	{
		*data = _data;
		return true;
	}
	return false;
}

struct WiFiClient_DataStruct WiFiServer_availableClient()
{
	WiFiClient_DataStruct retStruct;
	retStruct._socket = NO_SOCKET_AVAIL;

	if (_sock != NO_SOCKET_AVAIL) {
		retStruct._socket = WiFiServer_availServer(_sock);
	}

	if (retStruct._socket != NO_SOCKET_AVAIL) {

		if (status != NULL) {
			status = WiFiClient_status(retStruct._socket);
		}

		return retStruct;
	}

	retStruct._socket = 255;
	return retStruct;
}

uint16_t WiFiServer_availData(uint8_t sock)
{
	/*if (!SpiDrv::available()) {
		return 0;
	}*/

	//WAIT_FOR_SLAVE_SELECT();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(AVAIL_DATA_TCP_CMD, PARAM_NUMS_1);
	airLift.sendParam(&sock, sizeof(sock), LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _dataLen = 0;
	uint16_t len = 0;

	airLift.waitResponseCmd(AVAIL_DATA_TCP_CMD, PARAM_NUMS_1, (uint8_t*)&len,  &_dataLen);

	airLift.spiSlaveDeselect();

	return len;
}

uint8_t WiFiServer_availServer(uint8_t sock)
{
	if (!airLift.available()) {
		return 255;
	}

	//WAIT_FOR_SLAVE_SELECT();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(AVAIL_DATA_TCP_CMD, PARAM_NUMS_1);
	airLift.sendParam(&sock, sizeof(sock), LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _dataLen = 0;
	uint16_t socket = 0;

	airLift.waitResponseCmd(AVAIL_DATA_TCP_CMD, PARAM_NUMS_1, (uint8_t*)&socket,  &_dataLen);

	airLift.spiSlaveDeselect();

	return socket;
}

// Start TCP client on port specified
void WiFi_INTERNAL_startClient(uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode)
{
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(START_CLIENT_TCP_CMD, PARAM_NUMS_4);
	airLift.sendParam((uint8_t*)&ipAddress, sizeof(ipAddress));
	airLift.sendParam(port);
	airLift.sendParam(&sock, 1);
	airLift.sendParam(&protMode, 1, LAST_PARAM);

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	HAL_Delay(500);
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseCmd(START_CLIENT_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
	{
		//WARN("error waitResponse");
		USB_printf("Error: Failed to start TCP client.\n");
	}
	airLift.spiSlaveDeselect();
}

static uint8_t clientConnected;

int WiFiClient_Connect(uint32_t ip, uint16_t port) {
    if (_sock != NO_SOCKET_AVAIL)
    {
      //stop();
      WiFiClient_stop(&_sock);
    }

    //_sock = ServerDrv::getSocket();
    _sock = WiFi_getSocket();
    if (_sock != NO_SOCKET_AVAIL)
    {
    	//ServerDrv::startClient(ip, port, _sock);
    	WiFi_INTERNAL_startClient(ip, port, _sock, TCP_MODE);

    	//unsigned long start = millis();
    	unsigned long check_times = 0;

    	// wait 4 second for the connection to close
    	//while (!WiFiClient_connected(_sock) && millis() - start < 10000)
    	while (!WiFiClient_connected(_sock) && check_times < 4000)
    	{
    		check_times++;
    		HAL_Delay(1);
    	}

    	if (!WiFiClient_connected(_sock))
       	{
    		return 0;
    	}
    } else {
    	//Serial.println("No Socket available");
    	USB_printf("No Socket available\n");
    	return 0;
    }
    return 1;
}

void WiFi_stopClient(uint8_t sock)
{
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
    // Send Command
    airLift.sendCmd(STOP_CLIENT_TCP_CMD, PARAM_NUMS_1);
    airLift.sendParam(&sock, 1, LAST_PARAM);

    // pad to multiple of 4
    airLift.readChar();
    airLift.readChar();

    airLift.spiSlaveDeselect();
    HAL_Delay(10);
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    uint8_t _data = 0;
    uint8_t _dataLen = 0;
    if (!airLift.waitResponseCmd(STOP_CLIENT_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
    {
    	USB_printf("error waitResponse in STOPCLIENT\n");
        //WARN("error waitResponse");
    }
    airLift.spiSlaveDeselect();
}



// Get TCP Client State
uint8_t WiFi_TCP_getClientState(uint8_t sock)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(GET_CLIENT_STATE_TCP_CMD, PARAM_NUMS_1);
	airLift.sendParam(&sock, sizeof(sock), LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();
	HAL_Delay(10);
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseCmd(GET_CLIENT_STATE_TCP_CMD, PARAM_NUMS_1, &_data, &_dataLen))
	{
		USB_printf("Error: getClientState failed\n");
	}
	airLift.spiSlaveDeselect();
	HAL_Delay(3);
	return _data;
}

uint8_t WiFi_TCP_availServer(uint8_t sock)
{
    if (!airLift.available()) {
        return 255;
    }

    airLift.spiSlaveSelect();
    // Send Command
    airLift.sendCmd(AVAIL_DATA_TCP_CMD, PARAM_NUMS_1);
    airLift.sendParam(&sock, sizeof(sock), LAST_PARAM);

    // pad to multiple of 4
    airLift.readChar();
    airLift.readChar();

    airLift.spiSlaveDeselect();
    //Wait the reply elaboration
    airLift.waitForSlaveReady();
    airLift.spiSlaveSelect();

    // Wait for reply
    uint8_t _dataLen = 0;
    uint16_t socket = 0;

    airLift.waitResponseCmd(AVAIL_DATA_TCP_CMD, PARAM_NUMS_1, (uint8_t*)&socket,  &_dataLen);

    airLift.spiSlaveDeselect();

    return socket;
}

uint16_t WiFi_TCP_sendData(uint8_t sock, const uint8_t *data, uint16_t len)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(SEND_DATA_TCP_CMD, PARAM_NUMS_2);
	airLift.sendBuffer(&sock, sizeof(sock));
	airLift.sendBuffer((uint8_t *)data, len, LAST_PARAM);

	// pad to multiple of 4
	int commandSize = 9 + len;
	while (commandSize % 4) {
		airLift.readChar();
		commandSize++;
	}

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint16_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseData8(SEND_DATA_TCP_CMD, (uint8_t*)&_data, &_dataLen))
	{
		USB_printf("error waitResponse\n");
	}
	airLift.spiSlaveDeselect();

	return _data;
}

/*bool WiFi_TCP_getDataBuf(uint8_t sock, uint8_t *_data, uint16_t *_dataLen)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(GET_DATABUF_TCP_CMD, PARAM_NUMS_2);
	airLift.sendBuffer(&sock, sizeof(sock));
	airLift.sendBuffer((uint8_t *)_dataLen, sizeof(*_dataLen), LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	if (!airLift.waitResponseData16(GET_DATABUF_TCP_CMD, _data, _dataLen))
	{
		USB_printf("error waitResponse\n");
	}
	airLift.spiSlaveDeselect();
	if (*_dataLen!=0)
	{
		return true;
	}
	return false;
}*/

bool WiFi_TCP_getData(uint8_t sock, uint8_t *data, uint8_t peek)
{
	//WAIT_FOR_SLAVE_SELECT();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(GET_DATA_TCP_CMD, PARAM_NUMS_2);
	airLift.sendParam(&sock, sizeof(sock));
	airLift.sendParam(peek, LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseData8(GET_DATA_TCP_CMD, &_data, &_dataLen))
	{
		//WARN("error waitResponse");
		USB_printf("waitResponse error in WiFi_TCP_getData.\n");
	}
	airLift.spiSlaveDeselect();
	if (_dataLen!=0)
	{
		*data = _data;
		return true;
	}
	return false;
}

//bool ServerDrv::getDataBuf(uint8_t sock, uint8_t *_data, uint16_t *_dataLen)
bool WiFi_TCP_getDataBuf(uint8_t sock, uint8_t *_data, uint16_t *_dataLen)
{
	//WAIT_FOR_SLAVE_SELECT();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(GET_DATABUF_TCP_CMD, PARAM_NUMS_2);
	airLift.sendBuffer(&sock, sizeof(sock));
	airLift.sendBuffer((uint8_t *)_dataLen, sizeof(*_dataLen), LAST_PARAM);

	// pad to multiple of 4
	airLift.readChar();

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	if (!airLift.waitResponseData16(GET_DATABUF_TCP_CMD, _data, _dataLen))
	//if (!airLift.waitResponseCmd16(GET_DATABUF_TCP_CMD, PARAM_NUMS_2, _data, _dataLen))
	{
		//WARN("error waitResponse");
		USB_printf("error waitResponse\n");
		//*_dataLen = 0;
	}
	airLift.spiSlaveDeselect();
	if (*_dataLen!=0)
	{
		return true;
	}
	return false;
}

bool WiFi_TCP_insertDataBuf(uint8_t sock, const uint8_t *data, uint16_t _len)
{
	airLift.spiSlaveSelect();
	// Send Command
	airLift.sendCmd(INSERT_DATABUF_CMD, PARAM_NUMS_2);
	airLift.sendBuffer(&sock, sizeof(sock));
	airLift.sendBuffer((uint8_t *)data, _len, LAST_PARAM);

	// pad to multiple of 4
	int commandSize = 9 + _len;
	while (commandSize % 4) {
		airLift.readChar();
		commandSize++;
	}

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = 0;
	uint8_t _dataLen = 0;
	if (!airLift.waitResponseData8(INSERT_DATABUF_CMD, &_data, &_dataLen))
	{
		USB_printf("error waitResponse\n");
	}
	airLift.spiSlaveDeselect();
	if (_dataLen!=0)
	{
		return (_data == 1);
	}
	return false;
}

uint8_t WiFi_getSocket()
{
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Send Command
	airLift.sendCmd(GET_SOCKET_CMD, PARAM_NUMS_0);

	airLift.spiSlaveDeselect();
	//Wait the reply elaboration
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	// Wait for reply
	uint8_t _data = -1;
	uint8_t _dataLen = 0;
	airLift.waitResponseCmd(GET_SOCKET_CMD, PARAM_NUMS_1, &_data, &_dataLen);

	airLift.spiSlaveDeselect();

	// Set the internal value.
	_sock = _data;

	return _data;
}

int SendPacket(const char * host, uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode ,char * data2send)
{
	//------------------------------------------------------------------------------------
	// Beginning the packet
	//-----------------------------------------------------------------------------------

	airLift.waitForSlaveReady();

	airLift.spiSlaveSelect();

	airLift.sendCmd(START_CLIENT_TCP_CMD, PARAM_NUMS_5);
	airLift.sendParam((uint8_t*) host, strlen(host));   //might need be the other send param function
	airLift.sendParam((uint8_t*) &ipAddress, sizeof(ipAddress));
	airLift.sendParam(port);
	airLift.sendParam(&sock, 1);
	airLift.sendParam(&protMode, 1, LAST_PARAM);


	//I believe this is making sure that when data is sent, it is going to be streamed at a specific porpotion....
	int commandSize = 17 + strlen(host);     //might need to be size of, this also may affect reference above
	while(commandSize % 4){
		airLift.readChar();
		commandSize++;
	}

	airLift.spiSlaveDeselect();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	uint8_t _Data = 0;
	uint8_t _DataLen = 0;
	if(!airLift.waitResponseCmd(START_CLIENT_TCP_CMD, PARAM_NUMS_1, &_Data, &_DataLen))
	{
		USB_printf("There something going on with the Start client wait response");
	}
	airLift.spiSlaveDeselect();

	//-------------------------------------------------------------
	//End of beginning the packet
	//-------------------------------------------------------------
	//-------------------------------------------------------------
	//Writing the packet
	//-------------------------------------------------------------

	airLift.waitForSlaveReady();

	airLift.spiSlaveSelect();
	airLift.sendCmd(INSERT_DATABUF_CMD, PARAM_NUMS_2);
	airLift.sendBuffer(&sock, sizeof(sock));
	airLift.sendBuffer((uint8_t*)data2send,sizeof(data2send),LAST_PARAM);

	commandSize = 0;    //using the same variable from above
	commandSize = 9 + sizeof(data2send);
	while(commandSize %4){
		airLift.readChar();
		commandSize++;
	}

	airLift.spiSlaveDeselect();
	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	uint8_t packeto_data = 0;
	uint8_t packeto_dataLen = 0;

	if(!airLift.waitResponseData8(INSERT_DATABUF_CMD, &packeto_data, &packeto_dataLen)){
		USB_printf("There is something wrong with the data buffer wait command....");
	}

	airLift.spiSlaveDeselect();

	if(_DataLen == 0){
		return false;     //in the aurdrino code, this was checking and doing the opposite...
	}

	//-------------------------------------------------------------
	//End of writing the packet
	//-------------------------------------------------------------

	airLift.waitForSlaveReady();

	airLift.spiSlaveSelect();
	airLift.sendCmd(SEND_DATA_UDP_CMD, PARAM_NUMS_1);
	airLift.sendParam(&sock, sizeof(sock),LAST_PARAM);

	//pad to multiple of 4
	airLift.readChar();
	airLift.readChar();

	airLift.spiSlaveDeselect();

	airLift.waitForSlaveReady();
	airLift.spiSlaveSelect();

	uint8_t Packet_Data = 0;
	uint8_t Packet_DataLen = 0;

	if(!airLift.waitResponseData8(SEND_DATA_UDP_CMD, &Packet_Data, &Packet_DataLen)){
		USB_printf("There is an error with the send data UPD command");
	}

	airLift.spiSlaveDeselect();

	if(Packet_DataLen == 0){
		return 0;
	}

	return 1;

	//-------------------------------------------------------------
	//Ending the packet
	//-------------------------------------------------------------
}


