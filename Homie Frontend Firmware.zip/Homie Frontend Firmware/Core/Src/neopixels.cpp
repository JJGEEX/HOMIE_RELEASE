/*
 * neopixels.cpp
 *
 *  Created on: Feb 20, 2021
 *      Author: Grant modified by Xavion
 */

#include "neopixels.hpp"



// LED parameters
#define NUM_BPP (3) // WS2812B
//#define NUM_BPP (4) // SK6812
#define NUM_PIXELS (11)
#define NUM_BYTES (NUM_BPP * NUM_PIXELS)

// LED color buffer
uint8_t rgb_arr[NUM_BYTES] = {0};

// A delay function of my own making, because HAL delays
// are too fast for neopixels
void shorterDelay(int counter)
{
	while(counter--);
}

void neo_neoPixelsInit(void)
{
	GPIO_InitTypeDef initStruct = {0};

	// Set up pin A
	initStruct.Pin = GPIO_PIN_0;
	initStruct.Mode = GPIO_MODE_OUTPUT_PP;
	initStruct.Pull = GPIO_PULLUP;
	//initStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	initStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &initStruct);

//	// Set up pin A ////set up for dev board
//	initStruct.Pin = GPIO_PIN_15;
//	initStruct.Mode = GPIO_MODE_OUTPUT_PP;
//	initStruct.Pull = GPIO_PULLUP;
//	//initStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	initStruct.Speed = GPIO_SPEED_FREQ_HIGH;
//	HAL_GPIO_Init(GPIOC, &initStruct);


	// Verify operation by pulling it high and then low.
	HAL_GPIO_WritePin(NP_PORT, NP_DATAPIN, GPIO_PIN_SET);
	HAL_GPIO_WritePin(NP_PORT, NP_DATAPIN, GPIO_PIN_RESET);

	//make the neopixels off
	//clear_neoPixels();
}

void neo_write0bit(void)
{
	// As configured now, this seems to give a
	// LOW time of ~200ns.
	// https://wp.josh.com/2014/05/13/ws2812-neopixels-are-not-so-finicky-once-you-get-to-know-them/
	// If this article ^ is correct, we should be good
	// so long as it's between 200ns and 500ns.
	// Typ. == ~350ns.

	NP_PORT->BSRR = NP_DATAPIN;
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	NP_PORT->BRR = NP_DATAPIN;
}

void neo_write1bit(void)
{
	NP_PORT->BSRR = NP_DATAPIN;
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	NP_PORT->BRR = NP_DATAPIN;
}

void delayCheckFunction(void)
{
	// Set up:
	HAL_GPIO_WritePin(NP_PORT, NP_DATAPIN, GPIO_PIN_RESET);
	while(1) {
		//neo_write0bit();
		//neo_write1bit();
		//shorterDelay(1);

		NP_PORT->BSRR = NP_DATAPIN;
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		NP_PORT->BRR = NP_DATAPIN;

		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
		asm("NOP");
	}

	/*while(1){
		HAL_GPIO_WritePin(NP_PORT, NP_DATAPIN, GPIO_PIN_SET);
		shorterDelay(1);
		HAL_GPIO_WritePin(NP_PORT, NP_DATAPIN, GPIO_PIN_RESET);
		shorterDelay(1);
	}*/
}

//void writeNeoPixels(uint8_t numPix, uint32_t)

void neo_setVal(uint8_t index, uint8_t r, uint8_t g, uint8_t b)
{
	rgb_arr[index*NUM_BPP]     = g;
	rgb_arr[index*NUM_BPP + 1] = r;
	rgb_arr[index*NUM_BPP + 2] = b;
}

void neo_writePixels(void)
{
	USB_printf("write neopixels\n");
	for (uint8_t npIndex = 0; npIndex < NUM_PIXELS; npIndex++) {
		for (uint8_t ci = 0; ci < 3; ci++) // Red, Green, or Blue
		{
			for (uint8_t bc = 8; bc != 0; bc--) // bc == "Bit Cursor"
			{
				uint8_t bitMask = 0b1 << (bc-1);
				// IF THIS BIT IS A 0
				if (!(rgb_arr[npIndex*NUM_BPP + ci] & bitMask)) {
					//USB_printf("0");
					NP_PORT->BSRR = NP_DATAPIN;
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					NP_PORT->BRR = NP_DATAPIN;
				}
				// ELSE IF THIS BIT IS A 1
				else
				{
					//USB_printf("1");
					NP_PORT->BSRR = NP_DATAPIN;
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					asm("NOP");
					NP_PORT->BRR = NP_DATAPIN;
				}

				// Inter-bit-delay (between 450ns and 5000ns)
				// Will aim for 1000.
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				asm("NOP");
				//shorterDelay(10);
			}
			//USB_printf(" ");
		}
		//shorterDelay(40);
		//HAL_Delay(2);
		//USB_printf("\n");
	}

}

void clear_neoPixels(void){
	  neo_neoPixelsInit();
	  uint8_t clear[3] = {0x00, 0x00, 0x00};


	  for(int i = 0; i < NUM_PIXELS; i++)
	  {
		  neo_setVal((uint8_t)i, clear[0], clear[1], clear[2]);
		  neo_writePixels();
	  }
}

void write_pattern(uint8_t * color, uint8_t flash_type, int speed){
	bool even_odd = false;
	if(speed == NEOPIXEL_SPEED_NA){
		    			 //leads to correct flash f
		for(int j = 0; j < NUM_PIXELS; j++){
			neo_setVal((uint8_t)j, color[0], color[1], color[2]);
		}
		neo_writePixels();
	}
	else if(speed != NEOPIXEL_SPEED_NA){
		switch(flash_type){                 //leads to correct flash function
			case NEOPIXEL_STEADY_FLASH:
				 for(int j = 0; j < NUM_PIXELS; j++){
						 neo_setVal((uint8_t)j, color[0], color[1], color[2]);
					 }
				 neo_writePixels();
				 HAL_Delay(speed);
				 clear_neoPixels();
				 HAL_Delay(speed);
				 for(int j = 0; j < NUM_PIXELS; j++){
						 neo_setVal((uint8_t)j, color[0], color[1], color[2]);
					 }
				 neo_writePixels();
				 HAL_Delay(speed);
				 clear_neoPixels();
				 HAL_Delay(speed);
				 for(int j = 0; j < NUM_PIXELS; j++){
						  neo_setVal((uint8_t)j, color[0], color[1], color[2]);
					  }
				neo_writePixels();
				break;
			case NEOPIXEL_LEFT_RIGHT_SCROLL:
				  for(int j = 0; j < NUM_PIXELS; j++){
					  neo_setVal((uint8_t)j, color[0], color[1], color[2]);
					  HAL_Delay(speed);
					  neo_writePixels();
				  }
				break;
			case NEOPIXEL_RIGHT_LEFT_SCROLL:
				  for(int j = NUM_PIXELS; j > 0; j--){
					  neo_setVal((uint8_t)j, color[0], color[1], color[2]);
					  HAL_Delay(speed);
					  neo_writePixels();
				  }
				break;
			case NEOPIXEL_CONVERGENCE_SCROLL:
				((NUM_PIXELS % 2) == 0) ? (even_odd = true) : (even_odd = false);
				if(even_odd == true){
					int divider1 = ((NUM_PIXELS)/2);     // takes into account bit fields and such
					int end = NUM_PIXELS - 1;
					for(int start = 0; start < divider1; start++){
						neo_setVal((uint8_t)start, color[0], color[1], color[2]);
						neo_setVal((uint8_t)end, color[0], color[1], color[2]);
						HAL_Delay(speed);
						neo_writePixels();
						end--;
					}
				}
				else{
					int divider1 = ((NUM_PIXELS)/2);     // takes into account bit fields and such
					int end = NUM_PIXELS - 1;
					for(int start = 0; start < divider1; start++){
						neo_setVal((uint8_t)start, color[0], color[1], color[2]);
						neo_setVal((uint8_t)end, color[0], color[1], color[2]);
						HAL_Delay(speed);
						neo_writePixels();
						end--;
					}
					neo_setVal((uint8_t)divider1, color[0], color[1], color[2]);
					HAL_Delay(speed);
					neo_writePixels();
				}
				break;
			case NEOPIXEL_DIVERGENCE_SCROLL:
				((NUM_PIXELS % 2) == 0) ? (even_odd = true) : (even_odd = false);
				if(even_odd == true){
					int divider1 = ((NUM_PIXELS)/2);// takes into account bit fields and such
					int divider2 = ((NUM_PIXELS)/2) - 1;
					int start = divider2 - 1;
					neo_setVal((uint8_t)divider2, color[0], color[1], color[2]);
					neo_setVal((uint8_t)divider1, color[0], color[1], color[2]);
					HAL_Delay(speed);
					neo_writePixels();
					for(int end = divider1+1; end < NUM_PIXELS; end++){
						neo_setVal((uint8_t)start, color[0], color[1], color[2]);
						neo_setVal((uint8_t)end, color[0], color[1], color[2]);
						HAL_Delay(speed);
						neo_writePixels();
						start--;
					}
				}
				else{
					int divider1 = ((NUM_PIXELS)/2);     // takes into account bit fields and such
					int start = divider1 - 1;
					neo_setVal((uint8_t)divider1, color[0], color[1], color[2]);
					HAL_Delay(speed);
					neo_writePixels();
					for(int end = divider1+1; end < NUM_PIXELS-1; end++){
						neo_setVal((uint8_t)start, color[0], color[1], color[2]);
						neo_setVal((uint8_t)end, color[0], color[1], color[2]);
						HAL_Delay(speed);
						neo_writePixels();
						start--;
					}
				}
				break;
		default:
				for(int j = 0; j < NUM_PIXELS; j++){
					neo_setVal((uint8_t)j, color[0], color[1], color[2]);
				}
				neo_writePixels();
				break;
		}
	}

}


void neo_demo(void){
	neo_error();
	HAL_Delay(1000);
	neo_success();
	HAL_Delay(1000);
	neo_pairing();
	HAL_Delay(1000);
	neo_paired();
	HAL_Delay(1000);
	neo_notification();
	HAL_Delay(1000);
	neo_listening();
	HAL_Delay(1000);
	neo_heard();
	HAL_Delay(1000);
	neo_default();

}

void neo_error(void){
	clear_neoPixels();    //may need to just call this prior to the function
	uint8_t error_array[3] = DARK_RED;
	write_pattern(error_array, NEOPIXEL_CONVERGENCE_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	write_pattern(error_array, NEOPIXEL_STEADY_FLASH, NEOPIXEL_SPEED_SLOW);
}

void neo_success(void){
	clear_neoPixels();
	uint8_t success_array[3] = DARK_GREEN;
	write_pattern(success_array, NEOPIXEL_DIVERGENCE_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	write_pattern(success_array, NEOPIXEL_STEADY_FLASH, NEOPIXEL_SPEED_SLOW);

}

void neo_pairing(void){
	clear_neoPixels();
	uint8_t pairing_array[3] = DARK_WHITE;
	write_pattern(pairing_array, NEOPIXEL_LEFT_RIGHT_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	HAL_Delay(NEOPIXEL_SPEED_MEDIUM);
	clear_neoPixels();
	write_pattern(pairing_array, NEOPIXEL_LEFT_RIGHT_SCROLL, NEOPIXEL_SPEED_MEDIUM);
}

void neo_paired(void){
	clear_neoPixels();
	uint8_t paired_array[3] = DARK_WHITE;
	write_pattern(paired_array, NEOPIXEL_STEADY_FLASH, NEOPIXEL_SPEED_MEDIUM);
	HAL_Delay(NEOPIXEL_SPEED_MEDIUM);
	clear_neoPixels();
	write_pattern(paired_array, NEOPIXEL_STEADY_FLASH, NEOPIXEL_SPEED_MEDIUM);

}

void neo_notification(void){
	clear_neoPixels();
	uint8_t notif_array[3] = PURE_GREEN;
	write_pattern(notif_array, NEOPIXEL_CONVERGENCE_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	write_pattern(notif_array, NEOPIXEL_STEADY_FLASH, NEOPIXEL_SPEED_SLOW);

}

void neo_listening(void){
	clear_neoPixels();
	uint8_t listening_array[3] = DARK_BLUE;
	write_pattern(listening_array, NEOPIXEL_LEFT_RIGHT_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	clear_neoPixels();
	write_pattern(listening_array, NEOPIXEL_RIGHT_LEFT_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	HAL_Delay(NEOPIXEL_SPEED_FAST);
	clear_neoPixels();
	write_pattern(listening_array, NEOPIXEL_LEFT_RIGHT_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	clear_neoPixels();
	write_pattern(listening_array, NEOPIXEL_RIGHT_LEFT_SCROLL, NEOPIXEL_SPEED_MEDIUM);

}

void neo_heard(void){
	clear_neoPixels();
	uint8_t heard_array[3] = DARK_BLUE;
	write_pattern(heard_array, NEOPIXEL_DIVERGENCE_SCROLL, NEOPIXEL_SPEED_MEDIUM);
	write_pattern(heard_array, NEOPIXEL_STEADY_FLASH, NEOPIXEL_SPEED_SLOW);
}

void neo_default(void){
	clear_neoPixels();
	uint8_t default_array[3] = DARK_WHITE;
	write_pattern(default_array, NEOPIXEL_NO_FLASH, NEOPIXEL_SPEED_NA);
}

void neo_write_LED(uint8_t index, uint8_t * color){
	neo_setVal((uint8_t) index, color[0], color[1], color[2]);
	neo_writePixels();                                    //will call neo_val lower function
}

void neo_write_LEDs(uint8_t * color){
	write_pattern(color, NEOPIXEL_NO_FLASH, NEOPIXEL_SPEED_NA);
}

void write_LEDs(uint8_t r, uint8_t g, uint8_t b){
	uint8_t color[3] = {r, g, b};
	neo_write_LEDs(color);
}


