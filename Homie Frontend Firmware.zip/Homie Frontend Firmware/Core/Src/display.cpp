/******************************************************************************
SparkFun_Alphanumeric_Display.cpp
SparkFun Alphanumeric Display Library Source File
Priyanka Makin @ SparkFun Electronics
Original Creation Date: February 25, 2020
https://github.com/sparkfun/SparkFun_Alphanumeric_Display_Arduino_Library

Updated May 2, 2020 by Gaston Williams to add defineChar function

Pickup a board here: https://sparkle.sparkfun.com/sparkle/storefront_products/16391

This file implements all functions of the HT16K33 class. Functions here range
from printing to one or more Alphanumeric Displays, changing the display settings, and writing/
reading the RAM of the HT16K33.

The Holtek HT16K33 seems to be susceptible to address changes intra-sketch. The ADR pins
are muxed with the ROW and COM drivers so as semgents are turned on/off that affect
the ADR1/ADR0 pins the address has been seen to change. The best way around this is
to do a isConnected check before updateRAM() is sent to the driver IC.

Development environment specifics:
	IDE: Arduino 1.8.9
	Hardware Platform: Arduino Uno
	Alphanumeric Display Breakout Version: 1.0.0

This code is beerware; if you see me (or any other SparkFun employee) at the
local, and you've found our code helpful, please buy us a round!

Distributed as-is; no warranty is given.
******************************************************************************/

#include "display.hpp"
HT16K33 alphaNum;

extern RTC_DateTypeDef current_date;
extern RTC_TimeTypeDef current_time;
extern RTC_HandleTypeDef hrtc;

/*--------------------------- Character Map ----------------------------------*/
#define SFE_ALPHANUM_UNKNOWN_CHAR 95

//This is the lookup table of segments for various characters
//For AVR architecture, use PROGMEM

static const uint16_t alphanumeric_segs[96]{

	//nmlkjihgfedcba
	0b00000000000000, //' ' (space)
	0b00001000001000, //'!'  - added to map
	0b00001000000010, //'"' - added to map
 	0b1001101001110,  //'#'
	0b1001101101101,  //'$'
	0b10010000100100, //'%'
	0b110011011001,   //'&'
	0b1000000000,	  //'''
	0b111001,         //'('
	0b1111,           //')'
	0b11111010000000, //'*'
	0b1001101000000,  //'+'
	0b10000000000000, //','
	0b101000000,	  //'-'
	0b00000000000000, //'.' - changed to blank
	0b10010000000000, //'/'
	0b111111,         //'0'
	0b10000000110,	  //'1'
	0b101011011,	  //'2'
	0b101001111,	  //'3'
	0b101100110,	  //'4'
	0b101101101,	  //'5'
	0b101111101,	  //'6'
	0b1010000000001,  //'7'
	0b101111111,	  //'8'
	0b101100111,	  //'9'
	0b00000000000000, //':' - changed to blank
	0b10001000000000, //';'
	0b110000000000,   //'<'
	0b101001000,	  //'='
	0b01000010000000, //'>'
    0b01000100000011, //'?' - Added to map
	0b00001100111011, //'@' - Added to map
	0b101110111,	  //'A'
	0b1001100001111,  //'B'
	0b111001,         //'C'
	0b1001000001111,  //'D'
	0b101111001,	  //'E'
	0b101110001,	  //'F'
	0b100111101,	  //'G'
	0b101110110,	  //'H'
	0b1001000001001,  //'I'
	0b11110,          //'J'
	0b110001110000,   //'K'
	0b111000,         //'L'
	0b10010110110,	  //'M'
	0b100010110110,   //'N'
	0b111111,         //'O'
	0b101110011,	  //'P'
	0b100000111111,   //'Q'
	0b100101110011,   //'R'
	0b110001101,	  //'S'
	0b1001000000001,  //'T'
	0b111110,         //'U'
	0b10010000110000, //'V'
	0b10100000110110, //'W'
	0b10110010000000, //'X'
	0b1010010000000,  //'Y'
	0b10010000001001, //'Z'
	0b111001,         //'['
	0b100010000000,   //'\'
	0b1111,           //']'
    0b10100000000000, //'^' - Added to map
	0b1000,			  //'_'
	0b10000000,		  //'`'
	0b101011111,	  //'a'
	0b100001111000,   //'b'
	0b101011000,	  //'c'
	0b10000100001110, //'d'
	0b1111001,        //'e'
	0b1110001,        //'f'
	0b110001111,	  //'g'
	0b101110100,	  //'h'
	0b1000000000000,  //'i'
	0b1110,           //'j'
	0b1111000000000,  //'k'
	0b1001000000000,  //'l'
	0b1000101010100,  //'m'
	0b100001010000,   //'n'
	0b101011100,	  //'o'
	0b10001110001,	  //'p'
	0b100101100011,   //'q'
	0b1010000,        //'r'
	0b110001101,	  //'s'
	0b1111000,        //'t'
	0b11100,          //'u'
	0b10000000010000, //'v'
	0b10100000010100, //'w'
	0b10110010000000, //'x'
	0b1100001110,	  //'y'
	0b10010000001001, //'z'
	0b10000011001001, //'{'
	0b1001000000000,  //'|'
	0b110100001001,   //'}'
	0b00000101010010, //'~' - Added to map
	0b11111111111111, //Unknown character (DEL or RUBOUT)
};

/*--------------------------- Device Status----------------------------------*/
//For our purpose, the addressLeftCenter, addressRightCenter, andaddressRight will be the
//macro: DEFAULT_NOTHING_ATTACHED.



bool HT16K33::begin(uint8_t addressLeft, uint8_t addressLeftCenter, uint8_t addressRightCenter, uint8_t addressRight)
{

	_deviceAddressLeft = addressLeft;				//grab the address of the alphanumeric
	_deviceAddressLeftCenter = addressLeftCenter;   //grab the address of the alphanumeric
	_deviceAddressRightCenter = addressRightCenter; //grab the address of the alphanumeric
	_deviceAddressRight = addressRight;				//grab the address of the alphanumeric

	if (_deviceAddressRight != DEFAULT_NOTHING_ATTACHED)
		numberOfDisplays = 4;
	else if (_deviceAddressRightCenter != DEFAULT_NOTHING_ATTACHED)
		numberOfDisplays = 3;
	else if (_deviceAddressLeftCenter != DEFAULT_NOTHING_ATTACHED)
		numberOfDisplays = 2;
	else
		numberOfDisplays = 1;

	//TODO: malloc more displayRAM
	uint8_t address_array[4] = {addressLeft,addressLeftCenter,addressRightCenter, addressRight};

	//_i2cPort = &wirePort; //Remember the user's setting
	//CREATE STRUCTURE ELEMENTS HERE FOR ANi2c
	//static I2C_HandleTypeDef ANi2c = {0};

	ANi2c.Instance = I2C1;
	ANi2c.Mode = HAL_I2C_MODE_MASTER;
	ANi2c.Init.Timing = 0x00000EE;
	ANi2c.Init.OwnAddress1 = 0x25;
	ANi2c.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	ANi2c.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	ANi2c.Init.OwnAddress2 = 0;
	ANi2c.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
	ANi2c.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	ANi2c.Init.NoStretchMode = I2C_NOSTRETCH_ENABLE;
	//I2C_HandleTypeDef *ANi2c_pointer = ANi2c;
	if (HAL_I2C_Init(&ANi2c) != HAL_OK)
	  {
	    Error_Handler();
	  }


	//HAL_I2C_Init(&ANi2c);

	     // COME BACK TO THIS IF THINGS ARE BROKEN, MAY BE A PLACE TO TROUBLESHOOT
	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (isConnected(i, address_array[i]) == false)
		{
			//Serial.println("Failed isConnected()");
			return false;
		}

		/* if (checkDeviceID(i) == false)
		 {
		 	//Serial.println(i);
		 	//Serial.println("Hello, I've failed checkDeviceID()");
		 	return false;
		 }  */
	}

	if (initialize() == false)
	{
		//Serial.println("Failed initialize()");
		return false;
	}

	if (initalize_library() == false)  //initialize library for display
		return false;

	if (clear() == false) //Clear all displays
	{
		//Serial.println("Failed clear()");
		return false;
	}

	displayContent[4 * 4] = '\0'; //Terminate the array because we are doing direct prints

	return true;
}

//Check that all displays are responding
//The Holtek IC sometimes fails to respond. This attempts multiple times before giving up.
bool HT16K33::isConnected(uint8_t displayNumber, uint16_t DevAddress)
{
	DevAddress = DevAddress << 1;
	uint8_t x = HAL_I2C_IsDeviceReady(&ANi2c, DevAddress, MAX_TRIES_BEFORE_GIVING_UP, MAX_TIMEOUT_TIME);

	if(x != HAL_OK){
		return false;
	}
	else
		return true;

}


bool HT16K33::initialize()
{
	//Turn on system clock of all displays
	if (enableSystemClock() == false)
	{
		//Serial.println("Init: Failed enableSystemClock()");
		return false;
	}

	//Set brightness of all displays to full brightness
	if (setBrightness(16) == false)
	{
		//Serial.println("Init: Failed setBrightness()");
		return false;
	}

	//Blinking set - blinking off
	if (setBlinkRate(ALPHA_BLINK_RATE_NOBLINK) == false)
	{
		//Serial.println("Init: Failed setBlinkRate()");
		return false;
	}

	//Turn on all displays
	if (displayOn() == false)
	{
		//Serial.println("Init: Failed display on");
		return false;
	}

	return true;
}

// //Verify that all objects on I2C bus are alphanumeric displays
// bool HT16K33::checkDeviceID(uint8_t displayNumber)
// {
// 	uint8_t address = lookUpDisplayAddress(displayNumber);
// 	uint8_t test = 0xAA;
// 	uint8_t temp;
// 	//Turn off display - DEBUG: should it be ALL or ONE?
// 	singleDisplayOff(displayNumber);
// 	//Write 0xAA to register 0
// 	writeRAM(address, 0, (uint8_t *)&test, 1);
// 	//Read it back, it should be 0xAA
// 	readRAM(address, 0, (uint8_t *)&temp, sizeof((uint8_t)temp));
// 	if (temp != test)
// 		return false;
// 	//DEBUGGING: taking this out for now... can't call this write to ALL displays when we haven't initalized all displays yet!
// 	//Clear the write we just did
// 	// clear();
// 	//Turn display back on
// 	singleDisplayOn(displayNumber);
// 	return true;
// }

bool HT16K33::enableSystemClock()
{
	bool status = true;
	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (enableSystemClockSingle(i) == false)
			status = false;
	}
	return status;
}

bool HT16K33::disableSystemClock()
{
	bool status = true;
	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (disableSystemClockSingle(i) == false)
			status = false;
	}
	return status;
}

bool HT16K33::enableSystemClockSingle(uint8_t displayNumber)
{
	uint8_t dataToWrite = ALPHA_CMD_SYSTEM_SETUP | 1; //Enable system clock

	bool status = writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite);
	HAL_Delay(1); //Allow display to start
	return (status);
}

bool HT16K33::disableSystemClockSingle(uint8_t displayNumber)
{
	uint8_t dataToWrite = ALPHA_CMD_SYSTEM_SETUP & 0; //Standby mode

	return (writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite));
}

uint8_t HT16K33::lookUpDisplayAddress(uint8_t displayNumber)
{
	switch (displayNumber)
	{
	case 0:
		return _deviceAddressLeft;
		break;
	case 1:
		return _deviceAddressLeftCenter;
		break;
	case 2:
		return _deviceAddressRightCenter;
		break;
	case 3:
		return _deviceAddressRight;
		break;
	}

	return 0; //We shouldn't get here
}

/*-------------------------- Display configuration functions ---------------------------*/

bool HT16K33::clear()
{
	//Clear the displayRAM array
	for (uint8_t i = 0; i < 16 * numberOfDisplays; i++)
		displayRAM[i] = 0;

	digitPosition = 0;

	return (updateDisplay());
}

//Duty valid between 1 and 16
bool HT16K33::setBrightness(uint8_t duty)
{
	bool status = true;
	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (setBrightnessSingle(i, duty) == false)
			status = false;
	}
	return status;
}

bool HT16K33::setBrightnessSingle(uint8_t displayNumber, uint8_t duty)
{
	if (duty > 15)
		duty = 15; //Error check

	uint8_t dataToWrite = ALPHA_CMD_DIMMING_SETUP | duty;
	return (writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite));
}

//Parameter "rate" in Hz
//Valid options for "rate" are defined by datasheet: 2, 1, or 0.5 Hz
//Any other input to this function will result in steady alphanumeric display
bool HT16K33::setBlinkRate(float rate)
{
	bool status = true;
	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (setBlinkRateSingle(i, rate) == false)
			status = false;
	}
	return status;
}

bool HT16K33::setBlinkRateSingle(uint8_t displayNumber, float rate)
{
	if (rate == 2)
	{
		blinkRate = ALPHA_BLINK_RATE_2HZ;
	}
	else if (rate == 1)
	{
		blinkRate = ALPHA_BLINK_RATE_1HZ;
	}
	else if (rate == 0.5)
	{
		blinkRate = ALPHA_BLINK_RATE_0_5HZ;
	}
	//default to no blink
	else
	{
		blinkRate = ALPHA_BLINK_RATE_NOBLINK;
	}

	uint8_t dataToWrite = ALPHA_CMD_DISPLAY_SETUP | (blinkRate << 1) | displayOnOff;
	return (writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite));
}

bool HT16K33::displayOnSingle(uint8_t displayNumber)
{
	return setDisplayOnOff(displayNumber, true);
}
bool HT16K33::displayOffSingle(uint8_t displayNumber)
{
	return setDisplayOnOff(displayNumber, false);
}

//Set or clear the display on/off bit of a given display number
bool HT16K33::setDisplayOnOff(uint8_t displayNumber, bool turnOnDisplay)
{
	if(turnOnDisplay == true){
		displayOnOff = ALPHA_DISPLAY_ON;
		uint8_t dataToWrite = ALPHA_CMD_DISPLAY_SETUP | (blinkRate << 1) | displayOnOff;
		return (writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite));
	}
	else{
		displayOnOff = ALPHA_DISPLAY_OFF;
		uint8_t dataToWrite = ALPHA_CMD_DISPLAY_SETUP | (blinkRate << 1) & displayOnOff;
		return (writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite));
	}
	//uint8_t dataToWrite = ALPHA_CMD_DISPLAY_SETUP | (blinkRate << 1) | displayOnOff;
	//return (writeRAM(lookUpDisplayAddress(displayNumber), dataToWrite));
}

//Turn on/off the entire display
bool HT16K33::displayOn()
{
	bool status = true;

	displayOnOff = ALPHA_DISPLAY_ON;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (displayOnSingle(i) == false)
			status = false;
	}

	return status;
}

bool HT16K33::displayOff()
{
	bool status = true;

	displayOnOff = ALPHA_DISPLAY_OFF;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (displayOffSingle(i) == false)
			status = false;
	}

	return status;
}

bool HT16K33::decimalOnSingle(uint8_t displayNumber)
{
	return setDecimalOnOff(displayNumber, true);
}

bool HT16K33::decimalOffSingle(uint8_t displayNumber)
{
	return setDecimalOnOff(displayNumber, false);
}

bool HT16K33::setDecimalOnOff(uint8_t displayNumber, bool turnOnDecimal)
{
	uint8_t adr = 0x03;
	//uint8_t adr = 0x04;
	uint8_t dat;

	if (turnOnDecimal == true)
	{
		decimalOnOff = ALPHA_DECIMAL_ON;
		dat = 0x01;
		displayRAM[adr + displayNumber * 16] = displayRAM[adr + displayNumber * 16] | dat;

	}
	else
	{
		decimalOnOff = ALPHA_DECIMAL_OFF;
		dat = 0x00;
		displayRAM[adr + displayNumber * 16] = displayRAM[adr + displayNumber * 16] & dat;

	}

	//displayRAM[adr + displayNumber * 16] = displayRAM[adr + displayNumber * 16] | dat;
	return (updateDisplay());
}

//Turn on/off the entire display
bool HT16K33::decimalOn()
{
	bool status = true;

	decimalOnOff = ALPHA_DECIMAL_ON;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (decimalOnSingle(i) == false)
			status = false;
	}

	//Serial.println(status);
	return status;
}

bool HT16K33::decimalOff()
{
	bool status = true;

	decimalOnOff = ALPHA_DECIMAL_OFF;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (decimalOffSingle(i) == false)
			status = false;
	}
	return status;
}

bool HT16K33::colonOnSingle(uint8_t displayNumber)
{
	return setColonOnOff(displayNumber, true);
}

bool HT16K33::colonOffSingle(uint8_t displayNumber)
{
	return setColonOnOff(displayNumber, false);
}

bool HT16K33::setColonOnOff(uint8_t displayNumber, bool turnOnColon)
{
	uint8_t adr = 0x01;
	//uint8_t adr = 0x02;
	uint8_t dat;

	if (turnOnColon == true)
	{
		colonOnOff = ALPHA_COLON_ON;
		dat = 0x01;
		displayRAM[adr + displayNumber * 16] = displayRAM[adr + displayNumber * 16] | dat;

	}
	else
	{
		colonOnOff = ALPHA_COLON_OFF;
		dat = 0x00;
		displayRAM[adr + displayNumber * 16] = displayRAM[adr + displayNumber * 16] & dat;
	}


	//displayRAM[adr + displayNumber * 16] = displayRAM[adr + displayNumber * 16] | dat;
	return (updateDisplay());
}

bool HT16K33::colonOn()
{
	bool status = true;

	colonOnOff = ALPHA_COLON_ON;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (colonOnSingle(i) == false)
			status = false;
	}
	return status;
}

bool HT16K33::colonOff()
{
	bool status = true;

	colonOnOff = ALPHA_COLON_OFF;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{
		if (colonOffSingle(i) == false)
			status = false;
	}
	return status;
}

/*---------------------------- Light up functions ---------------------------------*/

//Given a segment and a digit, set the matching bit within the RAM of the Holtek RAM set
void HT16K33::illuminateSegment(uint8_t segment, uint8_t digit)
{
	uint8_t com;
	uint8_t row;

	com = segment - 'A'; //Convert the segment letter back to a number

	if (com > 6)
		com -= 7;
	if (segment == 'I')
		com = 0;
	if (segment == 'H')
		com = 1;

	row = digit % 4; //Convert digit (1 to 16) back to a relative position on a given display
	if (segment > 'G')
		row += 4;

	uint8_t offset = digit / 4 * 16;
	uint8_t adr = com * 2 + offset;

	//Determine the address
	if (row > 7)
		adr++;

	//Determine the data bit
	if (row > 7)
		row -= 8;
	uint8_t dat = 1 << row;

	//Temp DEBUGGING - clear segments that might affect A0/A1
	//dat &= 0b11111100;

	// Serial.print("illSeg Digit: ");
	// Serial.print(digit);
	// Serial.print("\t row: ");
	// Serial.print(row);
	// Serial.print("\t com: ");
	// Serial.print(com);
	// Serial.print("\t adr: ");
	// Serial.print(adr);
	// Serial.println();

	displayRAM[adr] = displayRAM[adr] | dat;
}

//Given a binary set of segments and a digit, store this data into the RAM array
void HT16K33::illuminateChar(uint16_t segmentsToTurnOn, uint8_t digit)
{
	for (uint8_t i = 0; i < 14; i++) //There are 14 segments on this display
	{
		if ((segmentsToTurnOn >> i) & 0b1)
			illuminateSegment('A' + i, digit); //Convert the segment number to a letter
	}
}

//Show a character on display
void HT16K33::printChar(uint8_t displayChar, uint8_t digit)
{
	//moved alphanumeric_segs array to PROGMEM
	uint16_t characterPosition = 65532;

	//space
	if (displayChar == ' ')
		characterPosition = 0;
	//Printable Symbols
	else if (displayChar >= '!' && displayChar <= '~')
	{
		characterPosition = displayChar - '!' + 1;
	}

	uint8_t dispNum = digitPosition / 4;
	//Take care of special characters
	if (characterPosition == 14) //'.'
		decimalOnSingle(dispNum);
	if (characterPosition == 26) //':'
		colonOnSingle(dispNum);
	if (characterPosition == 65532) //unknown character
		characterPosition = SFE_ALPHANUM_UNKNOWN_CHAR;

	// //Error check
	// if (characterPosition > sizeof(alphanumeric_segs))
	// 	characterPosition = sizeof(alphanumeric_segs) - 1; //Unknown char

	uint16_t segmentsToTurnOn = getSegmentsToTurnOn(characterPosition);

	illuminateChar(segmentsToTurnOn, digit);
}

//Update the list to define a new segments display for a particular character
bool HT16K33::defineChar(uint8_t displayChar, uint16_t segmentsToTurnOn)
{
	bool result = false;

	//Check to see if character is within range of displayable ASCII characters
	if (displayChar >= ' ' && displayChar <= '~')
	{
	  //Get the index of character in table and update its 14-bit segment value
	  uint16_t characterPosition = displayChar - '!' + 1;

      //Create a new character definition
      struct CharDef * pNewCharDef = (CharDef *)calloc(1, sizeof(CharDef));

	  //Set the position to the table index
      pNewCharDef -> position = characterPosition;
      //Mask the segment value to 14 bits only
      pNewCharDef -> segments = segmentsToTurnOn & 0x3FFF;
      //New definition always goes at the end of the list
      pNewCharDef -> next = NULL;

      //If list is empty set it to the new item
      if (pCharDefList == NULL)
      {
	    pCharDefList = pNewCharDef;
      }
      else
      {
      //Otherwise go to the end of the list and add it there
      struct CharDef * pTail = pCharDefList;

      while(pTail->next != NULL)
      {
        pTail = pTail->next;
      }

      pTail->next = pNewCharDef;
    }
	//We added the definition so we're all good
	result = true;
  }
  return result;
}

//Get the character map from the definition list or default table
uint16_t HT16K33::getSegmentsToTurnOn(uint8_t charPos)
{
  uint16_t segments = 0;
  //pointer to a defined character in list
  struct CharDef * pDefChar = pCharDefList;

  //Search the chacters list for a match
  while(pDefChar && (pDefChar->position != charPos))
  {
    pDefChar = pDefChar -> next;
  }

  //If we found a match return that value
  if (pDefChar != NULL)
  {
    segments = pDefChar -> segments;
  }
  //Otherwise get the value from the table
  /*
  else
  {
    segments = pgm_read_word_near(alphanumeric_segs + charPos);
  }
 */
  return segments;
}

/*
 * Write a byte to the display.
 * Required for Print.
 */
size_t HT16K33::write(uint8_t b)
{
	//If user wants to print '.' or ':', don't increment the digitPosition!
	if (b == '.' | b == ':')
		printChar(b, 0);
	else
	{
		printChar(b, digitPosition++);
		digitPosition %= (numberOfDisplays * 4); //Convert displays to number of digits
	}

	return (updateDisplay()); //Send RAM buffer over I2C bus
}

/*
 * Write a character buffer to the display.
 * Required for Print.
 */
size_t HT16K33::write(const uint8_t *buffer, size_t size)
{
	size_t n = size;
	uint8_t buff;

	//Clear the displayRAM array
	for (uint8_t i = 0; i < 16 * numberOfDisplays; i++)
		displayRAM[i] = 0;

	digitPosition = 0;

	while (size--)
	{
		buff = *buffer++;
		//For special characters like '.' or ':', do not increment the digitPosition
		if (buff == '.')
			printChar('.', 0);
		else if (buff == ':')
			printChar(':', 0);
		else
		{
			printChar(buff, digitPosition);
			displayContent[digitPosition] = buff; //Record to internal array

			digitPosition++;
			digitPosition %= (numberOfDisplays * 4);
		}
	}

	updateDisplay(); //Send RAM buffer over I2C bus

	return n;
}

//Write a string to the display
size_t HT16K33::write(const char *str)
{
	if (str == NULL)
		return 0;
	return write((const uint8_t *)str, strlen(str));
}

//Push the contents of displayRAM out to the various displays in 16 byte chunks
bool HT16K33::updateDisplay()
{
	//printRAM();

	bool status = true;

	for (uint8_t i = 0; i < numberOfDisplays; i++)
	{

		if (writeRAM(lookUpDisplayAddress(i), 0, (uint8_t *)(displayRAM + (i * 16)), 16) == false)
		{
			//Serial.print("updateDisplay fail at display 0x");
			//Serial.println(lookUpDisplayAddress(i), HEX);
			status = false;
		}
	}

	return status;
}

//Shift the display content to the right one digit
bool HT16K33::shiftRight(uint8_t shiftAmt)
{
	for (uint8_t x = (4 * numberOfDisplays) - shiftAmt; x >= shiftAmt; x--)
	{
		displayContent[x] = displayContent[x - shiftAmt];
	}

	//Clear the leading characters
	for (uint8_t x = 0; x < shiftAmt; x++)
	{
		if (x + shiftAmt > (4 * numberOfDisplays))
			break; //Error check

		displayContent[0 + x] = ' ';
	}

	//return (print(displayContent));
	return 1;
}

//Shift the display content to the left one digit
bool HT16K33::shiftLeft(uint8_t shiftAmt)
{
	for (int x = 0; x < 4 * numberOfDisplays; x++)
	{
		if (x + shiftAmt > (4 * numberOfDisplays))
			break; //Error check
		displayContent[x] = displayContent[x + shiftAmt];
	}

	//Clear the trailing characters
	for (int x = 0; x < shiftAmt; x++)
	{
		if (4 * numberOfDisplays - 1 - x < 0)
			break; //Error check

		displayContent[4 * numberOfDisplays - 1 - x] = ' ';
	}

	//return (print(displayContent));
	return 1;
}

/*----------------------- Internal I2C Abstraction -----------------------------*/

bool HT16K33::readRAM(uint8_t address, uint8_t reg, uint8_t *buff, uint8_t buffSize)
{
	uint8_t displayNum = 0;
	if (address == _deviceAddressLeftCenter)
		displayNum = 1;
	else if (address == _deviceAddressRightCenter)
		displayNum = 2;
	else if (address == _deviceAddressRight)
		displayNum = 3;
	isConnected(displayNum, address); //Wait until display is ready

	uint8_t readBuff[buffSize+1];
	readBuff[0] = reg;
	for(int i = 1; i < buffSize + 1; i++){
		readBuff[i] = buff[i-1];
	}
	buffSize = buffSize + 1;
	//May need to do the specific start function for the Alphanumeric Display
	uint8_t x = HAL_I2C_Master_Receive(&ANi2c, address, readBuff, buffSize, MAX_TIMEOUT_TIME);
	if(x != HAL_OK){
		while(x != HAL_OK){
			x = HAL_I2C_IsDeviceReady(&ANi2c, address, MAX_TRIES_BEFORE_GIVING_UP, MAX_TIMEOUT_TIME);
		}
	}
/*
	_i2cPort->beginTransmission(address);
	_i2cPort->write(reg);
	_i2cPort->endTransmission(false);

	if (_i2cPort->requestFrom(address, buffSize) > 0)
	{
		for (uint8_t i = 0; i < buffSize; i++)
			buff[i] = _i2cPort->read();
		return true;
	}
*/
	return true;
}

// //Overloaded function declaration
// //Use when reading just one byte of data
// bool HT16K33::read(uint8_t reg, uint8_t data)
// {
// 	return (read(reg, (uint8_t *)&data, (uint8_t)sizeof(data)));
// }

//Write the contents of the RAM array out to the Holtek IC
//After much testing, it
bool HT16K33::writeRAM(uint8_t address, uint8_t reg, uint8_t *buff, uint8_t buffSize)
{
	uint8_t displayNum = 0;
	if (address == _deviceAddressLeftCenter)
		displayNum = 1;
	else if (address == _deviceAddressRightCenter)
		displayNum = 2;
	else if (address == _deviceAddressRight)
		displayNum = 3;
	//isConnected(displayNum); //Wait until display is ready
	uint8_t writeBuff[buffSize+1];
	writeBuff[0] = reg;
	for(int i = 1; i < buffSize + 1; i++){
		writeBuff[i] = buff[i-1];
		}
	buffSize = buffSize + 1;

	address = address << 1;   //PUT HERE FOR DEBUGGING
	//May need to do the specific start function for the Alphanumeric Display
	//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);  //setting SCL High
	//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); // bringing SDA Low -This mimics start bit
	uint8_t x = HAL_I2C_Master_Transmit(&ANi2c, address, &writeBuff[0], buffSize, MAX_TIMEOUT_TIME);
    //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);  //setting SCL High
	//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET); // bringing SDA High-This mimics stop bit
	//char printBuf[32];
	//sprintf(printBuf, "WriteRAM Response: %d\n", x);
	//USB_printf(printBuf);
	if(x != HAL_OK){
		while(x != HAL_OK){
			x = HAL_I2C_IsDeviceReady(&ANi2c, address, MAX_TRIES_BEFORE_GIVING_UP, MAX_TIMEOUT_TIME);
			//sprintf(printBuf, "Is Ready? %d\n", x);
			//USB_printf(printBuf);
		}
	}


	return true;
}

//Write a single byte to the display. This is often a command byte.
//The address of the data to write is contained in the first four bits of dataToWrite
bool HT16K33::writeRAM(uint8_t address, uint8_t dataToWrite)
{
	uint8_t temp = 0;
	return (writeRAM(address, dataToWrite, (uint8_t *)&temp, 0));
}


//Function tests basic functionality of ONE display.
void Display_test(void){
	uint8_t y = alphaNum.begin(DEFAULT_ADDRESS,  SECOND_ADDRESS,  255,  255);
//	uint8_t y = alphaNum.begin(SECOND_ADDRESS, DEFAULT_ADDRESS, 255,  255);
	while(y != true){
		USB_printf("Error on beginning function");
	}
	uint8_t k = alphaNum.displayOff();
	while(k != true){
		USB_printf("Error with turning the display off");
	}

	uint8_t i = alphaNum.clear();
	while(i != true){
		usb_printf("Error with clearing");
	}

	bool t = alphaNum.initalize_library();
	while(t != true){
		usb_printf("Error with initializing");
	}


//	char * test_str_pr = {};
//
//	test_str_pr = "0000";
//	alphaNum.MultiPrintStr(test_str_pr, ALPHA_BLINK_RATE_2HZ);
//



	char * test_str_pr = {};

	test_str_pr = "  JJGEEX";
	alphaNum.MultiPrintStr(test_str_pr, ALPHA_BLINK_RATE_2HZ);

	//Display_Time();

	//Display_Date();

	uint8_t j = alphaNum.colonOffSingle(1);
	if(j != true){
		USB_printf("Error with colon on function");
	}

	/*
	uint8_t p = alphaNum.decimalOn();
	while(p != true){
		USB_printf("Error with Decimal");
	} */

	/*
	uint8_t flash = alphaNum.setBlinkRate(ALPHA_BLINK_RATE_2HZ);
	while(flash != true){
		USB_printf("Error with flash");
	} */


	uint8_t z = alphaNum.updateDisplay();
	while(z != true){
		USB_printf("Error on Update");
	}

//	uint8_t x = alphaNum.displayOn();
//	while(x != true){
//		USB_printf("Display on Error");
//	}

}


bool HT16K33::initalize_library(void){ //May need to optimize approach if memory becomes a concern
	uint8_t running_error_check = true;

	running_error_check = (running_error_check) & alphaNum.defineChar(' ',0x0000); //space
	running_error_check = (running_error_check) & alphaNum.defineChar('!',0x208); // '!'
	running_error_check = (running_error_check) & alphaNum.defineChar('"',0x202);
	running_error_check = (running_error_check) & alphaNum.defineChar('#',0x134e);
	running_error_check = (running_error_check) & alphaNum.defineChar('$',0x136d);
	running_error_check = (running_error_check) & alphaNum.defineChar('%',0x2424);
	running_error_check = (running_error_check) & alphaNum.defineChar('&',0xcd9);
	running_error_check = (running_error_check) & alphaNum.defineChar('`',0x200);
	running_error_check = (running_error_check) & alphaNum.defineChar('(',0x39);
	running_error_check = (running_error_check) & alphaNum.defineChar(')',0xf);
	running_error_check = (running_error_check) & alphaNum.defineChar('*',0x3e80);
	running_error_check = (running_error_check) & alphaNum.defineChar('+',0x1340);
	running_error_check = (running_error_check) & alphaNum.defineChar(',',0x2000);
	running_error_check = (running_error_check) & alphaNum.defineChar('-',0x140);
	running_error_check = (running_error_check) & alphaNum.defineChar('/',0x2400);
	running_error_check = (running_error_check) & alphaNum.defineChar('0',0x3f);
	running_error_check = (running_error_check) & alphaNum.defineChar('1',0x406);
	running_error_check = (running_error_check) & alphaNum.defineChar('2',0x15b);
	running_error_check = (running_error_check) & alphaNum.defineChar('3',0x14f);
	running_error_check = (running_error_check) & alphaNum.defineChar('4',0x166);
	running_error_check = (running_error_check) & alphaNum.defineChar('5',0x16d);
	running_error_check = (running_error_check) & alphaNum.defineChar('6',0x17d);
	running_error_check = (running_error_check) & alphaNum.defineChar('7',0x1401);
	running_error_check = (running_error_check) & alphaNum.defineChar('8',0x17f);
	running_error_check = (running_error_check) & alphaNum.defineChar('9',0x167);
	running_error_check = (running_error_check) & alphaNum.defineChar(';',0x2200);
	running_error_check = (running_error_check) & alphaNum.defineChar('<',0xC00);
	running_error_check = (running_error_check) & alphaNum.defineChar('=',0x148);
	running_error_check = (running_error_check) & alphaNum.defineChar('>',0x1080);
	running_error_check = (running_error_check) & alphaNum.defineChar('?',0x1103);
	running_error_check = (running_error_check) & alphaNum.defineChar('@',0x338);
	running_error_check = (running_error_check) & alphaNum.defineChar('A',0x177);
	running_error_check = (running_error_check) & alphaNum.defineChar('B',0x130f);
	running_error_check = (running_error_check) & alphaNum.defineChar('C',0x39);
	running_error_check = (running_error_check) & alphaNum.defineChar('D',0x120f);
	running_error_check = (running_error_check) & alphaNum.defineChar('E',0x179);
	running_error_check = (running_error_check) & alphaNum.defineChar('F',0x171);
	running_error_check = (running_error_check) & alphaNum.defineChar('G',0x13d);
	running_error_check = (running_error_check) & alphaNum.defineChar('H',0x176);
	running_error_check = (running_error_check) & alphaNum.defineChar('I',0x1209);
	running_error_check = (running_error_check) & alphaNum.defineChar('J',0x1e);
	running_error_check = (running_error_check) & alphaNum.defineChar('K',0xc70);
	running_error_check = (running_error_check) & alphaNum.defineChar('L',0x38);
	running_error_check = (running_error_check) & alphaNum.defineChar('M',0x4b6);
	running_error_check = (running_error_check) & alphaNum.defineChar('N',0x8b6);
	running_error_check = (running_error_check) & alphaNum.defineChar('O',0x3f);
	running_error_check = (running_error_check) & alphaNum.defineChar('P',0x173);
	running_error_check = (running_error_check) & alphaNum.defineChar('Q',0x83f);
	running_error_check = (running_error_check) & alphaNum.defineChar('R',0x973);
	running_error_check = (running_error_check) & alphaNum.defineChar('S',0x18d);
	running_error_check = (running_error_check) & alphaNum.defineChar('T',0x1201);
	running_error_check = (running_error_check) & alphaNum.defineChar('U',0x3e);
	running_error_check = (running_error_check) & alphaNum.defineChar('V',0x2430);
	running_error_check = (running_error_check) & alphaNum.defineChar('W',0x2836);
	running_error_check = (running_error_check) & alphaNum.defineChar('X',0x2c80);
	running_error_check = (running_error_check) & alphaNum.defineChar('Y',0x1480);
	running_error_check = (running_error_check) & alphaNum.defineChar('Z',0x2409);
	running_error_check = (running_error_check) & alphaNum.defineChar('[',0x39);
	running_error_check = (running_error_check) & alphaNum.defineChar('\\',0x880);   //will result in only one back-slash
	running_error_check = (running_error_check) & alphaNum.defineChar(']',0xf);
	running_error_check = (running_error_check) & alphaNum.defineChar('^',0x2800);
	running_error_check = (running_error_check) & alphaNum.defineChar('_',0x8);
	running_error_check = (running_error_check) & alphaNum.defineChar('a',0x15f);
	running_error_check = (running_error_check) & alphaNum.defineChar('b',0x878);
	running_error_check = (running_error_check) & alphaNum.defineChar('c',0x158);
	running_error_check = (running_error_check) & alphaNum.defineChar('d',0x210e);
	running_error_check = (running_error_check) & alphaNum.defineChar('e',0x79);
	running_error_check = (running_error_check) & alphaNum.defineChar('f',0x71);
	running_error_check = (running_error_check) & alphaNum.defineChar('g',0x18f);
	running_error_check = (running_error_check) & alphaNum.defineChar('h',0x174);
	running_error_check = (running_error_check) & alphaNum.defineChar('i',0x1000);
	running_error_check = (running_error_check) & alphaNum.defineChar('j',0xe);
	running_error_check = (running_error_check) & alphaNum.defineChar('k',0x1e00);
	running_error_check = (running_error_check) & alphaNum.defineChar('l',0x1200);
	running_error_check = (running_error_check) & alphaNum.defineChar('m',0x1154);
	running_error_check = (running_error_check) & alphaNum.defineChar('n',0x850);
	running_error_check = (running_error_check) & alphaNum.defineChar('o',0x15c);
	running_error_check = (running_error_check) & alphaNum.defineChar('p',0x471);
	running_error_check = (running_error_check) & alphaNum.defineChar('q',0x963);
	running_error_check = (running_error_check) & alphaNum.defineChar('r',0x50);
	running_error_check = (running_error_check) & alphaNum.defineChar('s',0x18D);
	running_error_check = (running_error_check) & alphaNum.defineChar('t',0x78);
	running_error_check = (running_error_check) & alphaNum.defineChar('u',0x1c);
	running_error_check = (running_error_check) & alphaNum.defineChar('v',0x2010);
	running_error_check = (running_error_check) & alphaNum.defineChar('w',0x2814);
	running_error_check = (running_error_check) & alphaNum.defineChar('x',0x2c80);
	running_error_check = (running_error_check) & alphaNum.defineChar('y',0x30e);
	running_error_check = (running_error_check) & alphaNum.defineChar('z',0x2409);
	running_error_check = (running_error_check) & alphaNum.defineChar('{',0x20c9);
	running_error_check = (running_error_check) & alphaNum.defineChar('|',0x1200);
	running_error_check = (running_error_check) & alphaNum.defineChar('}',0xd09);
	running_error_check = (running_error_check) & alphaNum.defineChar('~',0x152);
//	running_error_check = (running_error_check) & alphaNum.defineChar('ALL',0x3fff); //this may cause problems

	return running_error_check;
}

void HT16K33::error_print(uint8_t error_type){
	if(error_type == INTERNAL_ERROR){
		USB_printf("Internal Error");
	}

	else if(error_type == EXTERNAL_ERROR){
	alphaNum.printChar('E', 1);
	alphaNum.printChar('r', 2);
	alphaNum.printChar('r', 3);
	}
}

bool HT16K33::SinglePrintStr(char * print_str, uint8_t flash){
	uint8_t dis_off = alphaNum.displayOff();
	if(dis_off != true){
		error_print(EXTERNAL_ERROR);
		return false;
	}
	alphaNum.clear();
	uint8_t brite = true;
	switch(flash){

	case ALPHA_BLINK_RATE_NOBLINK:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_NOBLINK);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	case ALPHA_BLINK_RATE_2HZ:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_2HZ);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	case ALPHA_BLINK_RATE_1HZ:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_1HZ);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	case ALPHA_BLINK_RATE_0_5HZ:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_0_5HZ);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	default:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_NOBLINK);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;
	}

	for(int i = 0; i < 4; i++){
		alphaNum.printChar(print_str[i], i);
	}

	uint8_t update = alphaNum.updateDisplay();
	while(update != true){
		error_print(INTERNAL_ERROR);
		return false;
	}
 return true;
}




bool HT16K33::UpdateDisplaySingle(uint8_t display_num)
{
	//printRAM();

	bool status = true;

		if(writeRAM(lookUpDisplayAddress(display_num), 0, (uint8_t *)(displayRAM + (display_num * 16)), 16) == false)
		{
			//Serial.print("updateDisplay fail at display 0x");
			//Serial.println(lookUpDisplayAddress(i), HEX);
			status = false;
		}

	return status;
}

bool HT16K33::MultiPrintStr(char * print_str, uint8_t flash){
	uint8_t dis_off = alphaNum.displayOff();
	if(dis_off != true){
		error_print(EXTERNAL_ERROR);
		return false;
	}
	alphaNum.clear();
	uint8_t brite = true;
	switch(flash){

	case ALPHA_BLINK_RATE_NOBLINK:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_NOBLINK);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	case ALPHA_BLINK_RATE_2HZ:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_2HZ);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	case ALPHA_BLINK_RATE_1HZ:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_1HZ);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	case ALPHA_BLINK_RATE_0_5HZ:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_0_5HZ);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;

	default:
		brite = alphaNum.setBrightness(ALPHA_BLINK_RATE_NOBLINK);
		if(brite != true){
			error_print(EXTERNAL_ERROR);
		}
		break;
	}


	for(int i = 0; i < 8; i++){
			alphaNum.printChar(print_str[i], i);
	}

	uint8_t update = alphaNum.updateDisplay();
	while(update != true){
		error_print(INTERNAL_ERROR);
		return false;
	}
 return true;

}

//setup display
void Display_Init(void){
	uint8_t y = alphaNum.begin(DEFAULT_ADDRESS,  255,  255,  255);
	while(y != true){
		USB_printf("Error on beginning function");
	}
	uint8_t k = alphaNum.displayOff();
	while(k != true){
		USB_printf("Error with turning the display off");
	}

	uint8_t i = alphaNum.clear();
	while(i != true){
		USB_printf("Error with clearing");
	}
}

void display_printf(const std::string aTxEndMessage){
	c_display_printf((char*)aTxEndMessage.c_str());
}

void c_display_printf(char* my_string){
	//alphaNum.SinglePrintStr(my_string, 0);
	int i = -1;
	while(my_string[++i]);//get the strings length


	if(i<=8){//keeps whatever is printed if less than 8 long
		alphaNum.MultiPrintStr(my_string, 0);
		alphaNum.displayOn();
	}
	else{//scrolls through the string once if more than 8
		char disp[9] = "        "; //8 spaces
		for(int j= 0; j<i+8; j++){
			for(int k = 0; k<7; k++){
				disp[k] = disp[k+1];
			}
			if(j < i){//if spaces
				disp[7] = my_string[j];
			}
			else{//if after string
				disp[7] = ' ';
			}

			alphaNum.MultiPrintStr(disp, 0);
			alphaNum.displayOn();
			HAL_Delay(150);

		}
	}
	alphaNum.displayOff();
}

void display_static_printf(const std::string aTxEndMessage){
	c_display_static_printf((char*)aTxEndMessage.c_str());
}

void display_printf_stepModeStart(const std::string aTxEndMessage)
{
	USB_printf("display_stepModeStart\n");
	return;
}

void display_printf_stepAdvance(void)
{
	USB_printf("display_stepAdvance\n");
	return;
}

// Displays a string (8 chars or less) and leaves it there.
void c_display_static_printf(char* my_string){
	int i = -1;
	while(my_string[i++]); // get the string's length

	if(i <= 8) {
		alphaNum.MultiPrintStr(my_string, 0);
		alphaNum.displayOn();
	} else {
		return;
	}
	return;
}

void Display_On(void){
    alphaNum.displayOn();
}

void Display_Off(void){
	alphaNum.displayOff();
}


void Display_Time(void){
	RTC_Init();    //Will need to be moved
	//char timeString[10];
	bool t = alphaNum.displayOff();
	while(t != true){
		Error_Handler();
	}
	char print_time[8];
	char * print_hours = &print_time[4];
	char * print_min = &print_time[6];
	HAL_RTC_GetTime(&hrtc, &current_time, RTC_FORMAT_BCD);
	uint8_t hour = current_time.Hours;
	uint8_t minutes = current_time.Minutes;

	//print_hours = BCD_conversion(hour);
	BCD_conversion(hour, print_hours);
	//print_min = BCD_conversion(minutes);
	BCD_conversion(minutes, print_min);

	alphaNum.MultiPrintStr(&print_time[0], ALPHA_BLINK_RATE_2HZ);

}

void Display_Date(void){
	RTC_Init();    //Will need to be moved
	//char timeString[10];
	bool t = alphaNum.displayOff();
	while(t != true){
		Error_Handler();
	}
	char print_date[8];
	char * print_year = &print_date[6];
	char * print_day = &print_date[3];
	char * print_month = &print_date[0];

	HAL_RTC_GetDate(&hrtc, &current_date, RTC_FORMAT_BCD);
	uint8_t month = current_date.Month;
	uint8_t date = current_date.Date;
	uint8_t year = current_date.Year;


	BCD_conversion(month, print_month);
	BCD_conversion(date, print_day);
	BCD_conversion(year, print_year);

	alphaNum.MultiPrintStr(&print_date[0], ALPHA_BLINK_RATE_2HZ);

}

void BCD_conversion(uint8_t bcd_value, char *ptr_str){
//char * BCD_conversion(uint8_t bcd_value){
	uint8_t tenths = bcd_value >> 4;
	uint8_t ones = bcd_value << 4;
	ones = ones >> 4;
	//char ptr_str[2];

	switch(tenths){
	case 0:
		ptr_str[0] = '0';
		break;
	case 1:
		ptr_str[0] = '1';
		break;
	case 2:
		ptr_str[0] = '2';
		break;
	case 3:
		ptr_str[0] = '3';
		break;
	case 4:
		ptr_str[0] = '4';
		break;
	case 5:
		ptr_str[0] = '5';
		break;
	case 6:
		ptr_str[0] = '6';
		break;
	case 7:
		ptr_str[0] = '7';
		break;
	case 8:
		ptr_str[0] = '8';
		break;
	case 9:
		ptr_str[0] = '9';
		break;

	default:
		ptr_str[0] = 'E';
		break;
	}


	switch(ones){
	case 0:
		ptr_str[1] = '0';
		break;
	case 1:
		ptr_str[1] = '1';
		break;
	case 2:
		ptr_str[1] = '2';
		break;
	case 3:
		ptr_str[1] = '3';
		break;
	case 4:
		ptr_str[1] = '4';
		break;
	case 5:
		ptr_str[1] = '5';
		break;
	case 6:
		ptr_str[1] = '6';
		break;
	case 7:
		ptr_str[1] = '7';
		break;
	case 8:
		ptr_str[1] = '8';
		break;
	case 9:
		ptr_str[1] = '9';
		break;

	default:
		ptr_str[1] = 'E';
		break;

	}
	return;
	//return ptr_str;
}

//bool HT16K33::ShiftPrintR(char * print_str, uint8_t size, uint8_t shiftAmt, bool loop){
//
//}
//
//bool HT16K33::ShiftPrintL(char * print_str, uint8_t size, uint8_t shiftAmt, bool loop){
//
//}
