/*
 * app_w.cpp
 *
 *  Created on: Apr 6, 2021
 *      Author: thwai
 */


#include "app_data.hpp"
#include "audio_in.hpp"


static uint8_t aStreamArr[3200];
static uint32_t totalsentmicbytes = 0;


void WiFi_streamPing(){
	if(Stream_block)
		return;
	else if(my_buffer->read_ready(1600))
	{
		if(my_buffer->back_read((int16_t*)aStreamArr, 1600)) // 800 = 1600 / 2
		{
			WiFi_TCP_sendData(0, (uint8_t*)&aStreamArr[0], 3200);
			totalsentmicbytes += 3200;
		}
	}
	/*if (my_buffer->back_read_noloop((int16_t*) aStreamArr, 1600)) // 800 = 1600 / 2
	{
		WiFi_TCP_sendData(0, (uint8_t*) &aStreamArr[0], 3200);
	}*/
}

void WIFI_STREAMEVT(void){
	WiFi_streamPing();
	if(totalsentmicbytes < 200000)
		Homie_Scheduler.add_event(WIFI_ASEND_EVENT);
}





#define AUDIO_PACKET		1

static uint8_t avBytes = -1	;
char messageBuf[32];
char testHDR[] = "TPCKT";
char audioHDR[] = "APCKT";
char audioFTR[] = "ADONE";
char mstrtHDR[] = "MSTRM";
char mstopHDR[] = "MSTOP";
char m3pktHDR[] = "M3PKT";
char vrerrHDR[] = "VRERR"; // for when the back-end fails to recognize a command
char canclHDR[] = "CANCL"; // for when we cancel a command by saying "Stop" to the front-end

char cnerrHDR[] = "CNERR"; // for when there's a connection error with backend
char cnrdyHDR[] = "CNRDY"; // let the front end know that the backend is recovered from the connection error
char plswtHDR[] = "PLSWT"; // so the backend can tell the frontend to wait.

char hanndHDR[] = "HANND"; // The first half of a handshake
char shakeHDR[] = "SHAKE"; // The second half of a handshake (we actually send this to the backend)

char gdataHDR[] = "GDATA"; // The back end lets us know it got good data
char flushHDR[] = "FLUSH"; // backend lets us know that it has flushed the data




uint8_t WiFi_ReadHeader(uint8_t socket)
{
	uint8_t retLength = WiFiClient_bigRead(socket, (uint8_t*)&messageBuf[0], sizeof(messageBuf));

	uint8_t result = 255;
	messageBuf[sizeof(audioHDR) - 1] = '\0';
	char checkBuf[sizeof(audioHDR)];
	memcpy(checkBuf, messageBuf, sizeof(audioHDR));
	//result = strcmp(audioHDR, checkBuf);
	if (testHDR == checkBuf)
		result = 2;
	if (audioHDR == checkBuf)
		result = 1;
	else
		result = 0;
	return result;
}



static uint8_t packetType;
static uint32_t startTick;
static uint32_t stopTick;

static char commandLog[2048];
static uint16_t cLogIndex = 0;

void WIFI_PACKETCHECK(void){
	// Add something here to make this event not happen SUPER often (might slow
	// 		things down if it's running all the time).
	avBytes = WiFi_packetCheckEvent();

	/* Small delay to keep from overwhelming the AirLift with two transactions too close together. */
	HAL_Delay(2);

	if(avBytes != 255)
	{
		/* There's a packet available, so read it from the AirLift. */
		uint16_t retLength = WiFiClient_bigRead(avBytes, (uint8_t*)&messageBuf[0], sizeof(messageBuf));
		if(retLength == 1)
			return;

		{
		char pBuf[32];
		sprintf(pBuf, "got data on socket %d\n", avBytes);
		USB_printf(pBuf);
		}

		/*if(retLength == 0)
		{
			HAL_Delay(1);
			return;
		}*/

		/* If it looks like there might be a control packet there*/
		// vvv This is an endline '\n' character right now because that's easier
		//     to test in a NetCat terminal.  But, when we do things in Python
		//     with the Socket library, it will probably be better to do
		//     this as a '\0' NULL character.
		//if(messageBuf[5] == '\0')  //if(messageBuf[5] == '\0')
		if((messageBuf[5] == '\0') || (messageBuf[5] == '\n'))  //if(messageBuf[5] == '\0')
		{
			/* Cut out 6 characters from the received packet */
			/* (6 characters == the length of a data header  */
			//USB_printf("<3");
			memcpy(&commandLog[cLogIndex], messageBuf, 5);
			cLogIndex += 5;
			bool isAudioPacket = false;
			uint8_t result = 255;
			char checkBuf[sizeof(audioHDR)];
			memcpy(checkBuf, messageBuf, sizeof(audioHDR));
			checkBuf[sizeof(audioHDR) - 1] = '\0';
			/* Compare the first six characters with the audio packet header */
			if (!strcmp(audioHDR, checkBuf)) {
				packetType = AUDIO_PACKET;
			}
			/* Compare the first six characters with the testing packet header */
			else if (!strcmp(testHDR, checkBuf)) {
				packetType = TESTING_PACKET;
			}
			/* If it's start mic stream */
			else if (!strcmp(mstrtHDR, checkBuf)) {
				packetType = MICSTRM_START_PACKET;
			}
			/* If it's stop mic stream */
			else if (!strcmp(mstopHDR, checkBuf)) {
				packetType = MICSTRM_STOP_PACKET;
			}
			else if (!strcmp(m3pktHDR, checkBuf)) {
				packetType = MP3_AUDIO_PACKET;
			}
			else if (!strcmp(canclHDR, checkBuf)) {
				packetType = COMMAND_CANCEL_PACKET;
			}
			else if (!strcmp(vrerrHDR, checkBuf)) {
				packetType = VOICE_REC_ERROR_PACKET;
			}
			else if (!strcmp(cnerrHDR, checkBuf)) {
				packetType = CONNECTION_ERROR_PACKET;
			}
			else if (!strcmp(cnrdyHDR, checkBuf)) {
				packetType = CONNECTION_READY_PACKET;
			}
			else if (!strcmp(hanndHDR, checkBuf)) {
				packetType = HANDSHAKE_REQUEST_PACKET;
			}
			else if (!strcmp(gdataHDR, checkBuf)) {
				packetType = GOOD_DATA_PACKET;
			}
			else if (!strcmp(flushHDR, checkBuf)) {
				packetType = DATA_FLUSH_PACKET;
			}
			else if (!strcmp(plswtHDR, checkBuf)) {
				packetType = PLEASE_WAIT_PACKET;
			}
			/* Otherwise it's a normal text packet */
			else {
				packetType = TEXT_PACKET;
			}
		}

		//isAudioPacket = !strcmp(audioHDR, checkBuf);

		//if(!strcmp(testHDR, checkBuf))
		//{
			// Prepare to send some data
			/*
			int16_t sendData[4000];
			sine_send_buffer->back_read(&sendData[0], 4000);
			WiFi_TCP_sendData(0, (uint8_t*)&sendData[0], (sizeof(int16_t)*4000)*2);
			*/
		//	Homie_Scheduler.rem_event(WIFI_ASEND_EVENT);

		//}

		/* ^^^ This can be expanded with other types of headers to handle
		 * more types of data.
		 */



		switch(packetType)
		{
		case AUDIO_PACKET:
		{
			uint16_t fail_times = 0;
			clear_neoPixels();
			Display_Off();
			bool audioDone = false;
			const uint16_t tx_max = 1500;
			uint8_t audio_buffer[tx_max];
			while(!audioDone) /* Get more data and feed it to the amp */
			{
				avBytes = WiFi_packetCheckEvent();
				//if(avBytes == 255)
				//	HAL_Delay(1);

				if(avBytes == 255)
				{
					HAL_Delay(1);
					fail_times++;

					if(fail_times > 2000)
						audioDone = true;
				}
				else {
					fail_times = 0;
					retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
					my_output_buffer->front_write((int16_t*) audio_buffer, retLength / 2);

					//
					// THIS IS THE TERRIBLE, HACKY THING I MENTIONED IN THE COMMIT MESSAGE.
					// REALLY BAD IDEA FOR NUMEROUS REASONS, BUT REDUCES OCCURRENCES OF
					// AUDIO GAPS A BIT.
					// MIGHT USE IT FOR DEMO NEXT WEEK.
					//
					// Sometimes transactions are too short -- check for this, and
					// compensate when it happens by doing another transaction, if
					// data happens to be available.
					//if(retLength < 1000)
					if (retLength == 1500) {
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
						while (!(my_output_buffer->front_write((int16_t*) audio_buffer, retLength / 2)));
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
						while (!(my_output_buffer->front_write( (int16_t*) audio_buffer, retLength / 2)));
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
						while (!(my_output_buffer->front_write( (int16_t*) audio_buffer, retLength / 2)));
					} else if (retLength < 500) {
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
						while (!(my_output_buffer->front_write( (int16_t*) audio_buffer, retLength / 2)));
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
						while (!(my_output_buffer->front_write( (int16_t*) audio_buffer, retLength / 2)));
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &audio_buffer[0], sizeof(audio_buffer));
						while (!(my_output_buffer->front_write( (int16_t*) audio_buffer, retLength / 2)));
					}
				}
			}

			HAL_Delay(25);
			// Now, we send a thing to the back end to let it know
			// we've processed all the audio data.
			char dataStartThing[] = "ADONE";
			WiFi_TCP_sendData(0, (uint8_t*)&dataStartThing[0], strlen(dataStartThing)*sizeof(char));

			break;
		}
		case MICSTRM_START_PACKET:
		{
			Homie_Scheduler.rem_event(MICDONE_EVENT);
			AI_block = true;

			Homie_Scheduler.add_event(WIFI_ASEND_EVENT);
			break;
		}
		case MICSTRM_STOP_PACKET:
		{
			Homie_Scheduler.rem_event(WIFI_ASEND_EVENT);
			AI_block = false;

			Homie_Scheduler.add_event(MICDONE_EVENT);
			break;
		}
		case COMMAND_CANCEL_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;
			//display_printf("I DID NOT CATCH THAT");
			display_printf("STOP");
			uint8_t colors[3] = { 0x00, 0x00, 0xFF };
			neo_write_LEDs(colors);
			HAL_Delay(200);
			clear_neoPixels();
			HAL_Delay(200);
			neo_write_LEDs(colors);
			HAL_Delay(200);
			clear_neoPixels();
			break;
		}
		case VOICE_REC_ERROR_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;
			//uint8_t colors[3] = { 0xFF, 0x00, 0x00 };
			//neo_write_LEDs(colors);
			write_LEDs(_ORANGE);
			//display_printf("I DID NOT CATCH THAT");
			//display_printf("VOICE REC ERROR");
			display_static_printf("VOSK ERR");
			Stream_block = true;
			clear_neoPixels();
			HAL_Delay(5);
			break;
		}
		case CONNECTION_ERROR_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;

			display_static_printf("CONN ERR");

			uint8_t colors[3] = {0xFF, 0x00, 0x00};
			neo_write_LEDs(colors);
			Stream_block = true;

			break;
		}
		case CONNECTION_READY_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;

			HAL_Delay(25);

			clear_neoPixels();
			Display_Off();

			HAL_Delay(25);

			// Send something to backend to let it clear stuff
			char dataStartThing[] = "YEETO";
			WiFi_TCP_sendData(0, (uint8_t*)&dataStartThing[0], strlen(dataStartThing)*sizeof(char));

			break;
		}
		case DATA_FLUSH_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;

			write_LEDs(_TURQUOISE);
			AI_block = false;
			Stream_block = false;
			break;
		}
		case HANDSHAKE_REQUEST_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;

			HAL_Delay(100);

			// Got the handshake request, reply to the backend
			WiFi_TCP_sendData(0, (uint8_t*)&shakeHDR[0], 5);

			break;
		}
		case GOOD_DATA_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;

			mic_flushBuffers();
			my_buffer->empty_buffer();
			Homie_Scheduler.rem_event(WIFI_ASEND_EVENT);
			write_LEDs(_ORANGE);
			display_static_printf("DATAGOOD");
			totalsentmicbytes = 0;

			Stream_block = true;

			break;
		}
		case PLEASE_WAIT_PACKET:
		{
			volatile uint8_t thebreaker = 0;
			thebreaker++;

			display_static_printf("PLS WAIT");

			break;
		}
		case MP3_AUDIO_PACKET:
		{
			char mp3PrintBuf[64];
			int bytesLeft = 0;

			bool brokenFrameFlag = false;
			bool finalFrameFlag = false;

			bool audioDone = false;
			bool doneDecoding = false;
			bool needMoreData = true;
			int16_t lc = 0; // load cursor

			const uint16_t tx_max = 1500;
			uint8_t audio_buffer[tx_max];

			unsigned char helix_inBuf[INBUF_SIZE];
			unsigned char *HX_inBuf_ptr = &helix_inBuf[0];
			//short* helix_outBuf;
			//short helix_outBuf[INBUF_SIZE/4];


			uint8_t fail_check = 0;

			while(!audioDone) /* Get more data and feed it to the amp */
			{
				startTick = HAL_GetTick();
				while(needMoreData)
				{
					avBytes = WiFi_packetCheckEvent();
					if (avBytes == 255)
					{
						if(fail_check > 10)
							audioDone = true;

						fail_check++;
						HAL_Delay(1);
						if(brokenFrameFlag)
						{
							needMoreData = false;
							finalFrameFlag = true;
						} else if (doneDecoding) {
							audioDone = true;
						}
					}
					else {
						fail_check = 0;
						// FIND OUT HOW MUCH DATA WE NEED
						size_t dataToGet = 0;
						//if((INBUF_SIZE - bytesLeft - lc) > tx_max)
						//	dataToGet = tx_max;
						//else
						//	dataToGet = INBUF_SIZE - bytesLeft - lc;
						dataToGet = tx_max;

						// NOW ONE STEP:
						retLength = WiFiClient_bigRead(avBytes, (uint8_t*) &helix_inBuf[0], dataToGet);

						// INCREMENT THE LOAD CURSOR
						lc += retLength;

						// Load the data when ready
						while(!(my_output_buffer->front_write((int16_t*)&helix_inBuf[0], (retLength/2))));
						//while(!(my_output_buffer->write_ready(retLength/2)));

						// CHECK IF DONE
						/*if (lc == INBUF_SIZE - bytesLeft)
						{
							needMoreData = false;
							doneDecoding = false;
							bytesLeft = INBUF_SIZE;
						}*/
					}
				}
				//stopTick = HAL_GetTick();
				// RESET VARIABLES FOR NEXT TIME
				lc = 0;
				volatile uint8_t breakVar = 0;
				breakVar++;


				HX_inBuf_ptr = &helix_inBuf[0];

				// GET TO THE START OF THE FILE

				// FIRST LET'S GET SOME INFORMATION ABOUT THE
				//   NEXT FRAME OF MP3 DATA
				/*
				while(!doneDecoding)
				{
					//HX_error = MP3GetNextFrameInfo(myHelix, &nf_info, (unsigned char*) HX_inBuf_ptr);
					//if(HX_error)
					//	USB_printf("GetNextFrameInfo ERROR\n");

					if (bytesLeft < 627)
					{
						needMoreData = true;
						brokenFrameFlag = true;
						if(!finalFrameFlag)
							break;
						else
							audioDone = true;
					}

					HX_error = MP3GetNextFrameInfo(myHelix, &nf_info, (unsigned char*) HX_inBuf_ptr);
					// TRY TO DECODE ONE FRAME OF MP3 DATA
					HX_error = MP3Decode(myHelix, &HX_inBuf_ptr, &bytesLeft, helix_outBuf, 0);

//			sprintf(mp3PrintBuf, "time to decode: %ld microseconds\n", startTick - stopTick);
//			printf(mp3PrintBuf);

					if(!HX_error)
					{
						stopTick = HAL_GetTick();
						my_output_buffer->front_write((int16_t*)helix_outBuf, nf_info.outputSamps);
						startTick = HAL_GetTick();
					}

					if(HX_error == -6)
					{
						USB_printf("MP3Decode ERROR\n");
						//needMoreData = true;
						//break;
					}
					else if(HX_error == -1)
					{
						USB_printf("INDATA_UNDERFLOW ERROR, ABORTING\n");
						needMoreData = true;
						doneDecoding = true;
						audioDone = true;
					}
					else
					{
						// SAMPLE THING THAT JUST HELPS ME TO KNOW IF I'M GETTING DATA

						//sprintf(mp3PrintBuf, "decoded %d samples\n", nf_info.outputSamps);
						//USB_printf(mp3PrintBuf);
						//sprintf(mp3PrintBuf, "outBuf[0] = 0x%x\n", helix_outBuf[0]);
						//USB_printf(mp3PrintBuf);

						// HERE'S WHERE I WOULD PUT THE CODE TO LOAD THE RECEIVED SAMPLES
						// INTO THE AUDIO OUTPUT DMA BUFFER.
						//
						//  load teh samples
						//
					}

					//sprintf(mp3PrintBuf, "bytesLeft = %d\n", bytesLeft);
					//USB_printf(mp3PrintBuf);

					if((bytesLeft == 0)||(audioDone))
					{
						doneDecoding = true;
						needMoreData = false;
					}
					//sprintf(mp3PrintBuf, "bitsPerSample = %d\n", );
					//USB_printf(mp3PrintBuf);

				}
				if((needMoreData) && bytesLeft != 0)
				{
					//HX_inBuf_ptr = &helix_inBuf[0];
					for(int i = 0; i < bytesLeft; i++)
					{
						helix_inBuf[i] = helix_inBuf[INBUF_SIZE - bytesLeft + i];
					}
				}*/
			}

			break;
		}
		case TESTING_PACKET:
		{
			bool getTestCMD_done = false;
			bool gotTestCMD = false;
			char secPrintBuf[32];
			uint8_t msgGetBuffer[32];

			Homie_Scheduler.rem_event(MICDONE_EVENT);//does stream_ping and AI_guess
			while(!getTestCMD_done) /* Get more data and feed it to the amp */
			{
				while(!gotTestCMD)
				{
					avBytes = WiFi_packetCheckEvent();
					if(avBytes == 255)
						HAL_Delay(1);
					else
						gotTestCMD = true;
				}

				// Get the command
				retLength = WiFiClient_bigRead(avBytes, (uint8_t*)&msgGetBuffer[0], sizeof(msgGetBuffer));

				if(((char)msgGetBuffer[0] == 'A')&&((char)msgGetBuffer[1] == '\n'))
				{

					//printTime();
					//setRTC(12, 45, 00);
					display_printf("EPIC GAMER MOMENT");
					//HAL_RTC_GetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32_t Format);
					USB_printf("Success!!\n");
				}
				if(((char)msgGetBuffer[0] == 'B')&&((char)msgGetBuffer[1] == '\n'))
				{
					display_printf("YEETICUS");
					USB_printf("Success!!\n");
					//printTime();
				}


				getTestCMD_done = true;
			}
			Homie_Scheduler.add_event(MICDONE_EVENT);
			break;
		}
		case TEXT_PACKET: /* Print the received packet to the USB */
						  /* if an Audio Packet header was found  */
		{

			messageBuf[retLength] = '\0';	// Terminate the received message
											// so that it prints properly
			USB_printf(messageBuf);
			break;
		default:
			break;

		}
		}

		//WiFi_stopClient(avBytes - 1);
		/*if((avBytes == 6) && (avBytes != 255))
		{
			for(int i = 0; i < avBytes-1; i++)
			{
				WiFi_stopClient(i);
				HAL_Delay(50);
			}
		}*/
		if(avBytes == 9)
		{
			write_LEDs(_PURE_RED);
			//display_printf("NO RESPONSE");
			//display_printf("GO GET SOME COFFEE");
			clear_neoPixels();

			WiFi_kick();
			HAL_Delay(50);
			WiFi_Demo(SECRET_SSID, SECRET_PASS, makeIP(192, 168, 0, 115), 5555);

			//WiFi_resetFortuneCookie();

			AI_block = true;
			Stream_block = false;
			/*for(int i = 0; i < 9; i++)
			{
				WiFi_stopClient(i);
				HAL_Delay(50);
			}*/
		}

	}
	// Now, if the time is right, we close some sockets :)
	//WiFi_stopClient(avBytes);
	/*if((avBytes > 5) && (avBytes != 255))
	{
		for(int i = 0; i < avBytes; i++)
		{
			HAL_Delay(10);
			WiFi_stopClient(i);
		}
		HAL_Delay(1000);
	}*/
}


#define NUM_FORTUNES		5

// void fortuneCookie(void): Print some advice to stall for time
//                           while the wifi reconnects
void WiFi_resetFortuneCookie(void)
{
	USB_printf("Fortune Cookie called.\n");

	uint8_t status = WL_IDLE_STATUS;
	uint8_t attempts = WL_MAX_ATTEMPT_CONNECTION*4;

	char adviceStr[32];
	uint32_t oracle = HAL_GetTick();
	oracle = oracle % NUM_FORTUNES;
	switch(oracle) {
	case 0:
		sprintf(adviceStr, "GO GET SOME COFFEE");
		break;
	case 1:
		sprintf(adviceStr, "FIND INNER PEACE");
		break;
	case 2:
		sprintf(adviceStr, "STOP AND SMELL THE ROSES");
		break;
	case 3:
		sprintf(adviceStr, "WASTE NOT WANT NOT");
		break;
	case 4:
		sprintf(adviceStr, "I LOVE YOU");
		break;
	}
	while(status != WL_CONNECTED)
	{
		WiFi_kick();
		HAL_Delay(50);

		airLift.SPI1_open();
		airLift.begin();

		//WiFi_Demo(SECRET_SSID, SECRET_PASS, makeIP(192, 168, 0, 115), 5555);
		if (wifiSetPassphrase(SECRET_SSID, strlen(SECRET_SSID), SECRET_PASS, strlen(SECRET_PASS))!= WL_FAILURE)
		{
			do
			{
				//delay(WL_DELAY_START_CONNECTION);
				//HAL_Delay(5000);
				display_printf(adviceStr);
				//HAL_Delay(500);
				status = WiFi_getStatus();
			}
			while ((( status == WL_IDLE_STATUS)||(status == WL_NO_SSID_AVAIL)||(status == WL_SCAN_COMPLETED))&&(--attempts>0));
		}else{
			status = WL_CONNECT_FAILED;
		}
	}
	/*HAL_Delay(50);
	uint8_t socketVal = WiFi_getSocket();
	WiFi_startServer(5555, socketVal, TCP_MODE);
	HAL_Delay(50);*/

	WiFi_updateLocalInfo();

	USB_printf("Start a TCP server.\n");

	uint8_t socketVal = WiFi_getSocket();
	char printBuf[128];
	sprintf(printBuf, "Got socket: %d\n", socketVal);
	USB_printf(printBuf);

	WiFi_startServer(5555, socketVal, TCP_MODE);
	uint8_t server_status;
	do {
		server_status = WiFi_getServerState(0);
		if (server_status == 0) {
			USB_printf("Trying again in a second...\n");
			HAL_Delay(1000);
		}
	} while (server_status == 0);
	sprintf(printBuf, "Got server status: %d\n", server_status);
	USB_printf(printBuf);

	sprintf(printBuf, "\nSetup complete, try connecting to me!\n"
					  "Open a terminal on your Linux machine and type:\n\n"
					  "echo \"Hello, AirLift!\" | nc (MY IP ADDRESS) %lu\n",
					  5555);
	USB_printf(printBuf);


	Display_Off();
}
