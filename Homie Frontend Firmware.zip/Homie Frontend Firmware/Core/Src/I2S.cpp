/*
 * I2S.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion and Justin
 */

#include "I2S.hpp"


//#include <math.h>
//#define PI 3.14159265
//#define HALF_SAMPLE_RATE 8000
//void I2S::tone_gen(unsigned int frequency, unsigned int duration){
//	int data_len = duration*32;
//	int32_t data[data_len];
//	for(int i=0; i<data_len; i++){
//		data[i] = 256000*sin(i*frequency*PI/HALF_SAMPLE_RATE);
//	}
//	while(1){
//	speaker_init(0, (int32_t*)data, data_len);
//	}
//}

//initialize custom function pointers to null
static 	void (*speaker_callback)(void) = 0;
static  void (*mic_callback)(void) = 0;
DMA_HandleTypeDef dma_handleA;
DMA_HandleTypeDef dma_handleB;


static DMA_HandleTypeDef* Speaker_DMA_Init(void){
	__HAL_RCC_DMA2_CLK_ENABLE();
	__HAL_RCC_DMAMUX1_CLK_ENABLE();
	HAL_NVIC_SetPriority(DMA2_Channel1_IRQn, 0, 3);
	HAL_NVIC_EnableIRQ(DMA2_Channel1_IRQn);

	dma_handleB.Instance = DMA2_Channel1;
	dma_handleB.Init.Request = DMA_REQUEST_SAI1_B;
	dma_handleB.Init.Direction= DMA_MEMORY_TO_PERIPH;
	dma_handleB.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_handleB.Init.MemInc = DMA_MINC_ENABLE;
//	dma_handle.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	dma_handleB.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
//    dma_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    dma_handleB.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
//    dma_handleB.Init.Mode = DMA_NORMAL; //DMA_CIRCULAR
    dma_handleB.Init.Mode = DMA_CIRCULAR;
    dma_handleB.Init.Priority = DMA_PRIORITY_VERY_HIGH;
	if(HAL_OK != HAL_DMA_Init(&dma_handleB)){
		Error_Handler();
	}
	return &dma_handleB;
}

static DMA_HandleTypeDef* Mic_DMA_Init(void){
	__HAL_RCC_DMA1_CLK_ENABLE();
	__HAL_RCC_DMAMUX1_CLK_ENABLE();
	HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 4);
	HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

	dma_handleA.Instance = DMA1_Channel1;
	dma_handleA.Init.Request = DMA_REQUEST_SAI1_A;
	dma_handleA.Init.Direction= DMA_PERIPH_TO_MEMORY;
	dma_handleA.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_handleA.Init.MemInc = DMA_MINC_ENABLE;
//	dma_handle.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	dma_handleA.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
//    dma_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    dma_handleA.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
//    dma_handleA.Init.Mode = DMA_NORMAL; //DMA_CIRCULAR
    dma_handleA.Init.Mode = DMA_CIRCULAR;
    dma_handleA.Init.Priority = DMA_PRIORITY_HIGH;
	if(HAL_OK != HAL_DMA_Init(&dma_handleA)){
		Error_Handler();
	}
	return &dma_handleA;
}





//constructor
	I2S::I2S(){

      hsai_BlockA1.Instance = SAI1_Block_A;
	  hsai_BlockA1.Init.AudioMode = SAI_MODEMASTER_RX;
	  hsai_BlockA1.Init.Synchro = SAI_ASYNCHRONOUS;
	  hsai_BlockA1.Init.OutputDrive = SAI_OUTPUTDRIVE_DISABLE;
	  hsai_BlockA1.Init.NoDivider = SAI_MASTERDIVIDER_ENABLE;
	  hsai_BlockA1.Init.MckOverSampling = SAI_MCK_OVERSAMPLING_DISABLE;
	  hsai_BlockA1.Init.FIFOThreshold = SAI_FIFOTHRESHOLD_EMPTY;//mic needs 32
	  hsai_BlockA1.Init.AudioFrequency = SAI_AUDIO_FREQUENCY_32K;//SAI_AUDIO_FREQUENCY_32K;
	  hsai_BlockA1.Init.SynchroExt = SAI_SYNCEXT_DISABLE;
	  hsai_BlockA1.Init.MonoStereoMode = SAI_STEREOMODE;//SAI_MONOMODE;
	  hsai_BlockA1.Init.CompandingMode = SAI_NOCOMPANDING;
	  hsai_BlockA1.Init.TriState = SAI_OUTPUT_NOTRELEASED;

	  if (HAL_SAI_InitProtocol(&hsai_BlockA1, SAI_I2S_STANDARD, SAI_PROTOCOL_DATASIZE_24BIT, 2) != HAL_OK)
	  {
		Error_Handler();
	  }
	    hsai_BlockA1.hdmarx = Mic_DMA_Init();
	    hsai_BlockA1.hdmarx->Parent = &hsai_BlockA1;


	hsai_BlockB1.Instance = SAI1_Block_B;
	hsai_BlockB1.Init.AudioMode = SAI_MODESLAVE_TX;
	hsai_BlockB1.Init.Synchro = SAI_SYNCHRONOUS;
	hsai_BlockB1.Init.OutputDrive = SAI_OUTPUTDRIVE_DISABLE;
	hsai_BlockB1.Init.FIFOThreshold = SAI_FIFOTHRESHOLD_EMPTY;
	hsai_BlockB1.Init.SynchroExt = SAI_SYNCEXT_DISABLE;
	hsai_BlockB1.Init.MonoStereoMode = SAI_MONOMODE;
	hsai_BlockB1.Init.CompandingMode = SAI_NOCOMPANDING;
	hsai_BlockB1.Init.TriState = SAI_OUTPUT_NOTRELEASED;



	  if (HAL_SAI_InitProtocol(&hsai_BlockB1, SAI_I2S_STANDARD, SAI_PROTOCOL_DATASIZE_24BIT, 2) != HAL_OK)
	  {
		Error_Handler();
	  }
	    hsai_BlockB1.hdmatx = Speaker_DMA_Init();
	    hsai_BlockB1.hdmatx->Parent = &hsai_BlockB1;
//
//	  //enable the SAIs
//		__HAL_SAI_ENABLE(&hsai_BlockB1);
	  //	  hsai_BlockA1.Instance->SLOTR &= ~(3<<6);//switches the SlotSize to equal the data Size instead of 32 bits
//	  	  hsai_BlockA1.Instance->CR1 |= (1<<27);//enable master clock
		__HAL_SAI_ENABLE(&hsai_BlockA1);


//		#define PLAY_BUFFER_SIZE 1024
//		  int16_t play_buffer_arr[PLAY_BUFFER_SIZE];
//
//  /* USER CODE BEGIN SAI1_Init 2 */
//	if(HAL_OK != HAL_SAI_Transmit(&hsai_BlockB1, (uint8_t*)play_buffer_arr, PLAY_BUFFER_SIZE, 1000)){
//		Error_Handler();
//	}
//
	}

//deconstructor
    I2S::~I2S(){

    }

//Initializing callback function for speaker. Returns 0 if already assigned
//buffer is the pointer that DMA will use
//size is the size of the array
    bool I2S::speaker_init(void (*function)(void), int32_t* buffer, uint16_t size)
    {
    	//starting the DMA
    	if(HAL_OK != HAL_SAI_Transmit_DMA(&hsai_BlockB1, (uint8_t*)buffer, size)){
    		Error_Handler();
    	}
    	//adding the function pointer
    	if(speaker_callback){
    		speaker_callback = function;
    		return 0;
    	}
    	else{
    		speaker_callback = function;
    		return 1;
    	}
    }

//Initializing callback for Mic.  Returns 0 if already assigned
//buffer is the pointer that DMA will use
//size is the size of the array
    bool I2S::mic_init(void (*function)(void), int32_t* buffer, uint16_t size)
    {
	  //starting the DMA
	  if(HAL_OK != HAL_SAI_Receive_DMA(&hsai_BlockA1, (uint8_t*)buffer, size)){
		  Error_Handler();
	  }
	  //adding the function pointer
    	if(mic_callback){
    		mic_callback = function;
    		return 0;
    	}
    	else{
    		mic_callback = function;
    		return 1;
    	}

    }

//DMA complete Callback to trigger writing into the circular buffer
void HAL_SAI_TxCpltCallback(SAI_HandleTypeDef *hsai)
{
    if(speaker_callback){
    	speaker_callback();
    }
    else{
    	Error_Handler();
    }
}

//DMA complete Callback to trigger writing into the circular buffer
void HAL_SAI_RxCpltCallback(SAI_HandleTypeDef *hsai)
{
    if(mic_callback){
    	mic_callback();
    }
    else{
    	Error_Handler();
    }
}



///*
// * I2S.cpp
// *
// *  Created on: Oct 9, 2020
// *      Author: xavion and Justin
// */
//#include "I2S.hpp"
//
////for formatting functions
//#define LARGEST_NUMBER 131072 //(2^17)
//#define COMPLIMENT_NUMBER 262144 //(2^18)
//
////init structs
//I2S Mic_i2s;
//DMA_HandleTypeDef dma_handle = {0};
//SAI_HandleTypeDef hsai_BlockA1 = {0};
//
//
//
//
//
//
//static int twos_compliment(uint32_t x){
//	if( x >= LARGEST_NUMBER){
//		return x - COMPLIMENT_NUMBER;
//	}
//	else{
//		return (int)x;
//	}
//}
//
//static int format(uint32_t x){//only the top 18 bits are used out of the 24 bit number
//	return twos_compliment(x>>6);
//}
//
//
//
//static DMA_HandleTypeDef* DMA_Init(void){
//	__HAL_RCC_DMA1_CLK_ENABLE();
//	__HAL_RCC_DMAMUX1_CLK_ENABLE();
//	HAL_NVIC_SetPriority(DMA1_Channel1_IRQn,1, 4);
//	HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
//
//	dma_handle.Instance = DMA1_Channel1;
//	dma_handle.Init.Request = DMA_REQUEST_SAI1_A;
//	dma_handle.Init.Direction= DMA_PERIPH_TO_MEMORY;
//	dma_handle.Init.PeriphInc = DMA_PINC_DISABLE;
//    dma_handle.Init.MemInc = DMA_MINC_ENABLE;
////	dma_handle.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
//	dma_handle.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
////    dma_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
//    dma_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
////    dma_handle.Init.Mode = DMA_NORMAL; //DMA_CIRCULAR
//    dma_handle.Init.Mode = DMA_CIRCULAR;
//    dma_handle.Init.Priority = DMA_PRIORITY_HIGH;
//	if(HAL_OK != HAL_DMA_Init(&dma_handle)){
//		Error_Handler();
//	}
//
//
////	HAL_DMA_GetState(&dma_handle);
////	HAL_DMA_GetError(&dma_handle);
//	return &dma_handle;
//}
//
///**
//  * @brief SAI1 Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_SAI1_Init(void)
//{
//
////	LL_RCC_SetSAIClockSource(LL_RCC_SAI1_CLKSOURCE_HSI); //HSI = 16MHz - need 4MHz Set in clock.cpp
//
//  hsai_BlockA1.Instance = SAI1_Block_A;
//  hsai_BlockA1.Init.AudioMode = SAI_MODEMASTER_RX;
//  hsai_BlockA1.Init.Synchro = SAI_ASYNCHRONOUS;
//  hsai_BlockA1.Init.OutputDrive = SAI_OUTPUTDRIVE_ENABLE;
//  hsai_BlockA1.Init.NoDivider = SAI_MASTERDIVIDER_ENABLE;
////  hsai_BlockA1.Init.NoDivider = SAI_MASTERDIVIDER_DISABLE;
//  hsai_BlockA1.Init.MckOverSampling = SAI_MCK_OVERSAMPLING_DISABLE;
//  hsai_BlockA1.Init.FIFOThreshold = SAI_FIFOTHRESHOLD_EMPTY;
////  hsai_BlockA1.Init.AudioFrequency = SAI_AUDIO_FREQUENCY_16K;SAI_AUDIO_FREQUENCY_8K
//  hsai_BlockA1.Init.AudioFrequency = SAI_AUDIO_FREQUENCY_32K;
//  hsai_BlockA1.Init.SynchroExt = SAI_SYNCEXT_OUTBLOCKB_ENABLE;//SAI_SYNCEXT_DISABLE;
//  hsai_BlockA1.Init.MonoStereoMode = SAI_MONOMODE;
//  hsai_BlockA1.Init.CompandingMode = SAI_NOCOMPANDING;
//  hsai_BlockA1.Init.TriState = SAI_OUTPUT_NOTRELEASED;
//
//  uint32_t number_of_slots = 2;
//
//  if (HAL_SAI_InitProtocol(&hsai_BlockA1, SAI_I2S_STANDARD, SAI_PROTOCOL_DATASIZE_24BIT, number_of_slots) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  else{
//	  hsai_BlockA1.Instance->SLOTR &= ~(3<<6);//switches the SlotSize to equal the data Size instead of 32 bits
//	  hsai_BlockA1.Instance->CR1 |= (1<<27);//enable master clock
//  }
//
//  hsai_BlockA1.hdmarx = DMA_Init();
//  hsai_BlockA1.hdmarx->Parent = &hsai_BlockA1;
//
//}
//
//
//I2S::I2S(){
//}
//
//void I2S::mic_init(void){
//	MX_SAI1_Init();
//}
//
//
//I2S::~I2S(){}
//
//
//uint32_t I2S::start_mic(void){
//	  //starting the DMA
//	  if(HAL_OK != HAL_SAI_Receive_DMA(&hsai_BlockA1, (uint8_t*)I2S::data_buffer, I2S_BUFFER_SIZE)){
//		  Error_Handler();
//	  }
//	  I2S::writing_pointer = 0;
//
//	  //2 second warmup so no weird values
//	  HAL_Delay(2000);
//	  I2S::writing_pointer = 0;
//	  return 1;
//}
//
//
//static int16_t copy_buffer[I2S_BUFFER_SIZE/I2S_SCALING];
//
////Loads the data into the circular buffer if provided, otherwise drops the data
//uint32_t I2S::load_data(void){ //Private function that takes in if it is halfway in the buffer or all they way and copies the data formatted to a circular buffer
//	for(int i=0; i<(I2S_BUFFER_SIZE/I2S_SCALING); i++){
//		if(I2S_SCALING == 1){//no Scale down 32000 samples/ sec
//			copy_buffer[i] = (int16_t)format(I2S::data_buffer[i]);
//		}
//		else if(I2S_SCALING == 2){//divide samples in two averaging the two values 16000 Samples/sec
//			copy_buffer[i] = (int16_t)((format(I2S::data_buffer[2*i]) + format(I2S::data_buffer[2*i+1]))/2);
//		}
//		else if(I2S_SCALING == 4){//divide samples in two averaging the two values 8000 Samples/ sec
//			copy_buffer[i] = (int16_t)((format(I2S::data_buffer[4*i]) + format(I2S::data_buffer[4*i+1])+format(I2S::data_buffer[4*i+2]) + format(I2S::data_buffer[4*i+3]))/4);
//		}
//		else if(I2S_SCALING == 8){//divide samples in two averaging the two values
//			copy_buffer[i] = (int16_t)((format(I2S::data_buffer[8*i]) + format(I2S::data_buffer[8*i+1])+format(I2S::data_buffer[8*i+2]) + format(I2S::data_buffer[8*i+3])+ format(I2S::data_buffer[8*i+4]) + format(I2S::data_buffer[8*i+5])+format(I2S::data_buffer[8*i+6]) + format(I2S::data_buffer[8*i+7]))/8);
//		}
//		else{
//			Error_Handler();
//		}
//	}
//	if(I2S::circular_data_buffer != 0){
//		I2S::circular_data_buffer->front_write(copy_buffer, (I2S_BUFFER_SIZE/I2S_SCALING));//writes into the circular buffer
//
//	}
//
//	return writing_pointer;
//
//}
//
////Adds a circular buffer to copy the data to
//void I2S::add_buffer(Circular_Buffer* data){
//	circular_data_buffer  = data;
//}
//
//
////removes the circular buffer for copying data
//void I2S::remove_buffer(void){
//	circular_data_buffer = 0;
//}
//
////DMA complete Callback to trigger writing into the circular buffer
//void HAL_SAI_RxCpltCallback(SAI_HandleTypeDef *hsai)
//{//loops through once every time it goes through
//
//	Mic_i2s.load_data();
//	Homie_Scheduler.add_event(I2SDONE_EVENT);
//}
//
//
//void HAL_SAI_RxHalfCpltCallback(SAI_HandleTypeDef *hsai){
//}
//
//void HAL_SAI_ErrorCallback(SAI_HandleTypeDef *hsai)
//{
//	while(1);
//}
//
//
//
//
//
//
