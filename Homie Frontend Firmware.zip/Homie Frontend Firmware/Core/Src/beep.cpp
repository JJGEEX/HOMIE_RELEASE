/*
 * beep.cpp
 *
 *  Created on: Feb 20, 2021
 *      Author: thwai
 */
#include "beep.hpp"
//#include <math.h>
#define PI 3.1415926535


#define MAGNITUDE 6250

#define SMPRDIV10 3200 // 32000/10

#define AUDIO_BUFFER_SZ 500
#define BEEP_ARR_LEN AUDIO_BUFFER_SZ
static Circular_Buffer * out_circular_buffer;


static int32_t sin_data[AUDIO_BUFFER_SZ] = {0,78,157,235,314,392,470,549,627,705,783,861,938,1016,1093,1171,1248,1325,1401,1478,1554,1630,1705,1781,1856,1931,2005,2080,2154,2227,2300,2373,2446,2518,2589,2661,2731,2802,2872,2941,3010,3079,3147,3215,3282,3348,3414,3480,3545,3609,3673,3736,3799,3861,3923,3983,4044,4103,4162,4220,4278,4335,4391,4447,4501,4556,4609,4662,4714,4765,4815,4865,4914,4962,5009,5056,5102,5147,5191,5234,5277,5318,5359,5399,5438,5476,5514,5550,5586,5621,5655,5688,5720,5751,5781,5811,5839,5867,5893,5919,5944,5967,5990,6012,6033,6053,6072,6090,6107,6124,6139,6153,6166,6179,6190,6200,6210,6218,6225,6232,6237,6242,6245,6248,6249,6250,6249,6248,6245,6242,6237,6232,6225,6218,6210,6200,6190,6179,6166,6153,6139,6124,6107,6090,6072,6053,6033,6012,5990,5967,5944,5919,5893,5867,5839,5811,5781,5751,5720,5688,5655,5621,5586,5550,5514,5476,5438,5399,5359,5318,5277,5234,5191,5147,5102,5056,5009,4962,4914,4865,4815,4765,4714,4662,4609,4556,4501,4447,4391,4335,4278,4220,4162,4103,4044,3983,3923,3861,3799,3736,3673,3609,3545,3480,3414,3348,3282,3215,3147,3079,3010,2941,2872,2802,2731,2661,2589,2518,2446,2373,2300,2227,2154,2080,2005,1931,1856,1781,1705,1630,1554,1478,1401,1325,1248,1171,1093,1016,938,861,783,705,627,549,470,392,314,235,157,78,0,-78,-157,-235,-314,-392,-470,-549,-627,-705,-783,-861,-938,-1016,-1093,-1171,-1248,-1325,-1401,-1478,-1554,-1630,-1705,-1781,-1856,-1931,-2005,-2080,-2154,-2227,-2300,-2373,-2446,-2518,-2589,-2661,-2731,-2802,-2872,-2941,-3010,-3079,-3147,-3215,-3282,-3348,-3414,-3480,-3545,-3609,-3673,-3736,-3799,-3861,-3923,-3983,-4044,-4103,-4162,-4220,-4278,-4335,-4391,-4447,-4501,-4556,-4609,-4662,-4714,-4765,-4815,-4865,-4914,-4962,-5009,-5056,-5102,-5147,-5191,-5234,-5277,-5318,-5359,-5399,-5438,-5476,-5514,-5550,-5586,-5621,-5655,-5688,-5720,-5751,-5781,-5811,-5839,-5867,-5893,-5919,-5944,-5967,-5990,-6012,-6033,-6053,-6072,-6090,-6107,-6124,-6139,-6153,-6166,-6179,-6190,-6200,-6210,-6218,-6225,-6232,-6237,-6242,-6245,-6248,-6249,-6250,-6249,-6248,-6245,-6242,-6237,-6232,-6225,-6218,-6210,-6200,-6190,-6179,-6166,-6153,-6139,-6124,-6107,-6090,-6072,-6053,-6033,-6012,-5990,-5967,-5944,-5919,-5893,-5867,-5839,-5811,-5781,-5751,-5720,-5688,-5655,-5621,-5586,-5550,-5514,-5476,-5438,-5399,-5359,-5318,-5277,-5234,-5191,-5147,-5102,-5056,-5009,-4962,-4914,-4865,-4815,-4765,-4714,-4662,-4609,-4556,-4501,-4447,-4391,-4335,-4278,-4220,-4162,-4103,-4044,-3983,-3923,-3861,-3799,-3736,-3673,-3609,-3545,-3480,-3414,-3348,-3282,-3215,-3147,-3079,-3010,-2941,-2872,-2802,-2731,-2661,-2589,-2518,-2446,-2373,-2300,-2227,-2154,-2080,-2005,-1931,-1856,-1781,-1705,-1630,-1554,-1478,-1401,-1325,-1248,-1171,-1093,-1016,-938,-861,-783,-705,-627,-549,-470,-392,-314,-235,-157,-78};//static int32_t sin_data[SMPRDIV10];
static int16_t beep_data[BEEP_ARR_LEN];


void beep_init(Circular_Buffer * my_output_buffer){
	out_circular_buffer = my_output_buffer;

	//initialize sin wav array
//	for(int i=0; i<SMPRDIV10; i++){
////		sin_data[i] = MAGNITUDE*sin(i*2*PI/AUDIO_BUFFER_SZ);//sin wav of 10 HZ
//	}

}

//This function generates a generic tone for any duration mainly used as a helper function
void tone_gen(unsigned int frequency, unsigned int samples){
	int scaling = frequency/64; //scaling is how many of the 32 Hz arrays need to be compacted

	while(samples > BEEP_ARR_LEN){
		tone_gen(frequency, BEEP_ARR_LEN/scaling);
		samples -= BEEP_ARR_LEN/scaling;
	}//calls recursively to add enough data in the circular buffer

	if(scaling){
		for(unsigned int i=0; i<samples; i++){
			beep_data[i] = sin_data[(i*scaling)%BEEP_ARR_LEN];
		}
	}
	else{
		for(unsigned int i=0; i<samples; i++){
			beep_data[i] = 0;
		}
	}
	while(!out_circular_buffer->write_ready(samples));
	out_circular_buffer->front_write(beep_data, samples);
}


void Tone(unsigned int frequency, unsigned int duration){
	tone_gen(frequency, duration*32);
}


//This function generates a tone and then has a short pause at the end
void Beep(unsigned int frequency, unsigned int duration){
	if(duration > 10){
		Tone(frequency, duration-10);
		for(int i=0; i<320; i++){
			beep_data[i] = 0;
		}
		out_circular_buffer->front_write(beep_data, 320);
	}
}

void power_up(){
	tone_gen(220,100);
	tone_gen(440,100);
	tone_gen(660,100);
	tone_gen(880,100);
	tone_gen(1100,100);
	tone_gen(1320,100);
}

void pairing(){
	tone_gen(440,100);
	Beep(880,200);

}

void success(){
	Beep(1174,200);
	Beep(1568,200);
}

void error(){
	Beep(480,200);
	Beep(480,200);
	Beep(320,200);
}

void listening(){
	Beep(831,200);
	Beep(880,200);
}

//credit: https://connysoderholm.com/playing-super-mario-theme-music-with-python/
void mario(){
	int x = HAL_GetTick();
		Beep(480, 200);
		Beep(1568,200);
		Beep(1568,200);
//		while(HAL_GetTick()-x < 500);
		Beep(1568,200);
		Beep(740,200);
		Beep(784,200);
		while(HAL_GetTick()-x < 1000);


		Beep(784,200);
		Beep(784,200);
		Beep(370,200);
//		while(HAL_GetTick()-x < 1600);
		Beep(392,200);
		Beep(370,200);
		while(HAL_GetTick()-x < 2000);

		Beep(392,200);
		Beep(392,400);
//		while(HAL_GetTick()-x < 2600);
		Beep(196,400);
		Beep(740,200);
		Beep(784,200);
		while(HAL_GetTick()-x < 3000);

		Beep(784,200);
		Beep(740,200);
		Beep(784,200);
//		while(HAL_GetTick()-x < 2600);
		Beep(784,200);
		Beep(740,200);
		while(HAL_GetTick()-x < 4000);

		Beep(100,200);
		Beep(880,200);
		Beep(831,200);
//		while(HAL_GetTick()-x < 2600);
		Beep(880,200);
		Beep(988,400);
		while(HAL_GetTick()-x < 5000);


		Beep(880,200);
		Beep(784,200);
		Beep(699,200);
		Beep(740,200);
		Beep(784,200);
		while(HAL_GetTick()-x < 6000);

		Beep(784,200);
		Beep(740,200);
		Beep(784,200);
		Beep(784,200);
		Beep(740,200);
		while(HAL_GetTick()-x < 7000);

		Beep(784,200);
		Beep(880,200);
		Beep(830,200);
		Beep(880,200);
		Beep(988,400);
		while(HAL_GetTick()-x < 8200);

		Beep(0,180);
		Beep(1174,200);
		Beep(1568,200);
		Beep(0,180);
		while(HAL_GetTick()-x < 9000);

		Beep(740,200);
		Beep(784,200);
		Beep(784,200);
		Beep(740,200);
		Beep(784,200);

		while(HAL_GetTick()-x < 10000);

		Beep(784,200);
		Beep(740,200);
		Beep(784,200);
		Beep(880,200);
		Beep(830,200);

		while(HAL_GetTick()-x < 11000);

		Beep(880,200);
		Beep(988,400);
		Beep(880,200);
		Beep(784,200);

		while(HAL_GetTick()-x < 11000);

		Beep(699,200);
		Beep(659,200);
		Beep(699,200);
		Beep(784,200);
		Beep(880,400);

		while(HAL_GetTick()-x < 12200);

		Beep(784,200);
		Beep(699,200);
		Beep(659,200);
		Beep(587,200);

		while(HAL_GetTick()-x < 13000);

		Beep(659,200);
		Beep(699,200);
		Beep(784,400);
		Beep(699,200);

		while(HAL_GetTick()-x < 14000);

		Beep(659,200);
		Beep(587,200);
		Beep(523,200);
		Beep(587,200);
		Beep(659,200);

		while(HAL_GetTick()-x < 15000);

		Beep(699,400);
		Beep(659,200);
		Beep(587,200);
		Beep(494,200);

		while(HAL_GetTick()-x < 16000);

		Beep(523,200);
		Beep(0,400);
		Beep(349,400);

		while(HAL_GetTick()-x < 16000);

		Beep(392,200);
		Beep(330,200);
		Beep(523,200);
		Beep(494,200);
		Beep(466,200);

		while(HAL_GetTick()-x < 17000);

		Beep(440,200);
		Beep(494,200);
		Beep(523,200);
		Beep(880,200);
		Beep(494,200);

		while(HAL_GetTick()-x < 18000);

		Beep(880,200);
		Beep(1760,200);
		Beep(440,200);
		Beep(392,200);
		Beep(440,200);

		while(HAL_GetTick()-x < 19000);

		Beep(494,200);
		Beep(784,200);
		Beep(440, 200);
		Beep(784,200);
		Beep(1568,200);

		while(HAL_GetTick()-x < 20000);

		Beep(392,200);
		Beep(349,200);
		Beep(392,200);
		Beep(440,200);
		Beep(699,200);

		while(HAL_GetTick()-x < 21000);

		Beep(415,200);
		Beep(699,200);
		Beep(1397,200);
		Beep(349,200);
		Beep(330,200);

		while(HAL_GetTick()-x < 22000);

		Beep(311,200);
		Beep(330,200);
		Beep(659,200);
		Beep(699,400);

		while(HAL_GetTick()-x < 23000);

		Beep(784,400);
		Beep(440,200);
		Beep(494,200);
		Beep(523,200);

		while(HAL_GetTick()-x < 24000);

		Beep(880,200);
		Beep(494,200);
		Beep(880,200);
		Beep(1760,200);
		Beep(440,200);

		while(HAL_GetTick()-x < 25000);

		Beep(392,200);
		Beep(440,200);
		Beep(494,200);
		Beep(784,200);
		Beep(440,200);

		while(HAL_GetTick()-x < 26000);

		Beep(784,200);
		Beep(1568,200);
		Beep(392,200);
		Beep(349,200);
		Beep(392,200);

		while(HAL_GetTick()-x < 27000);

		Beep(440,200);
		Beep(699,200);
		Beep(659,200);
		Beep(699,200);
		Beep(740,200);

		while(HAL_GetTick()-x < 28000);

		Beep(784,200);
		Beep(392,200);
		Beep(392,200);
		Beep(392,200);
		Beep(392,200);

		while(HAL_GetTick()-x < 29000);

		Beep(196,200);
		Beep(196,200);
		Beep(196,200);
		Beep(185,200);
		Beep(196,200);

		while(HAL_GetTick()-x < 30000);

		Beep(185,200);
		Beep(196,200);
		Beep(208,200);
		Beep(220,200);
		Beep(233,200);

		while(HAL_GetTick()-x < 31000);

		Beep(247,200);


}
