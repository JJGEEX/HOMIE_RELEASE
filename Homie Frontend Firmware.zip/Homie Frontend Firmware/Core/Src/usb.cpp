/*
 * usb.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "usb.hpp"
#include "error_handling.hpp"


UART_HandleTypeDef huart1 = {0};
DMA_HandleTypeDef hdma_usart1_rx = {0};
DMA_HandleTypeDef hdma_usart1_tx = {0};

#define MY_SIZE 1600 //TX Buffer array size

static uint8_t my_array[MY_SIZE];
static uint8_t stream_enable;


static Circular_Buffer* circular_data_buffer;

#define CLOSE_ARR "i cant hear you"
#define CLOSE_ARR_LEN 15
static char close_rx_message[CLOSE_ARR_LEN];

#define RESTART_ARR "ooohhh"
#define RESTART_ARR_LEN 6
static char restart_rx_message[CLOSE_ARR_LEN];

void Send_Array(){
	//Helper function to copy data into the buffer alloted for the TX send
	//also shifts the read_location to the next needed value
	if(circular_data_buffer->back_read((int16_t*)my_array, MY_SIZE/2)){
		USB_Send((char*)my_array, MY_SIZE);
	}
}

uint8_t str_cmp(char* arr1, char* arr2, int size){
	uint8_t ok = 1;
	for(int i =0; i<size; i++){
		if(arr1[i] != arr2[i]){
			ok = 0;
		}
	}
	return ok;
}



uint32_t Open_Stream(void){
	if(stream_enable == STREAM_RESTART){

//		read_location = *micpointer;
		circular_data_buffer->empty_buffer();//resets read position

		//check to make sure the kids are ready
		char check[16] = "aye aye captain";
		char response[15];
		input((char*)"are ya ready kids", response, 15);
		//the kids are ready at this point
		if(!str_cmp(check, response, 15)){
			while(1);
		}


		//opens a stream to read the circular buffer and write to the TX UART
		stream_enable = STREAM_ON_PAUSE;

//		array_pointer = data_array;
//		array_size = size;
		USB_Receive(close_rx_message, CLOSE_ARR_LEN);
		return 1;
	}
	return 0;

}

void Close_Stream(){
	//closes the stream
	stream_enable = STREAM_OFF;
	USB_Receive(restart_rx_message, RESTART_ARR_LEN);
//	while(USB_Busy());
//	printf("aye aye captain");

}

void Pause_Stream(){
	//closes the stream
	stream_enable = STREAM_ON_PAUSE;
	while(USB_Busy()&1);//TX only
}

void Play_Stream(){
	//plays the stream
	while(USB_Busy()&1);//TX only
	stream_enable = STREAM_ON_PLAY;
	Send_Array();
}

void Stream_Ping(){

	if(stream_enable == STREAM_ON_PAUSE){//Have enough in the circular buffer to start again
		if(circular_data_buffer->read_ready(MY_SIZE/2)){
			Play_Stream();

		}
	}

}



void USB_Send(char* aTxEndMessage, uint32_t size){
    if(HAL_UART_Transmit_DMA(&huart1, (uint8_t*)aTxEndMessage, size)!= HAL_OK)
    {
      /* Transfer error in transmission process */
      Error_Handler();
    }
}

void USB_Sent(char* aTxEndMessage, uint32_t size){
    if(HAL_UART_Transmit_DMA(&huart1, (uint8_t*)aTxEndMessage, size)!= HAL_OK)
    {
      /* Transfer error in transmission process */
      Error_Handler();
    }
	while(USB_Busy());
}


void USB_Receive(char* aRxBuffer, uint32_t size){
    if (HAL_UART_Receive_DMA(&huart1, (uint8_t *)aRxBuffer, size) != HAL_OK)
    {
      /* Transfer error in reception process */
      Error_Handler();
    }
}

void usb_printf(const std::string aTxEndMessage){
	c_usb_printf((char*)aTxEndMessage.c_str());
}


void c_usb_printf(char* aTxEndMessage){
	uint8_t i = 0;
	while(aTxEndMessage[i]){
		i++;
	}
	USB_Send(aTxEndMessage, i);
	while(USB_Busy());
}



void input(char* message, char* aRxBuffer, uint8_t rx_buffersize){
	uint8_t i = 0;
	while(message[i]){
		i++;
	}
	USB_Send(message, i);//make sure to count end character
	USB_Receive(aRxBuffer, rx_buffersize);
	while(USB_Busy());
}


// Ready  = 0
// TX Busy = 1
// RX Busy = 2
uint8_t USB_Busy(void){

	return HAL_UART_GetState(&huart1) - HAL_UART_STATE_READY;
}







static void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
//  huart1.Init.BaudRate = 230400;
//  huart1.Init.BaudRate = 460800;
  huart1.Init.BaudRate = 921600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_NVIC_SetPriority(USART1_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(USART1_IRQn);
}

static void UART1_DMA_Init(uint8_t stream){
    /* USART1 DMA Init */
    /* USART1_RX Init */
	__HAL_RCC_DMA1_CLK_ENABLE();
	__HAL_RCC_DMAMUX1_CLK_ENABLE();
    hdma_usart1_rx.Instance = DMA1_Channel2;
    hdma_usart1_rx.Init.Request = DMA_REQUEST_USART1_RX;
    hdma_usart1_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_usart1_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart1_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart1_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart1_rx.Init.Mode = DMA_NORMAL;
    hdma_usart1_rx.Init.Priority = DMA_PRIORITY_HIGH;
    if (HAL_DMA_Init(&hdma_usart1_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(&huart1,hdmarx,hdma_usart1_rx);

    /* USART1_TX Init */
    hdma_usart1_tx.Instance = DMA1_Channel3;
    hdma_usart1_tx.Init.Request = DMA_REQUEST_USART1_TX;
    hdma_usart1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_usart1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart1_tx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    if(stream){
        hdma_usart1_tx.Init.Mode = DMA_CIRCULAR;
    }
    else{
    	hdma_usart1_tx.Init.Mode = DMA_NORMAL;
    }

    hdma_usart1_tx.Init.Priority = DMA_PRIORITY_HIGH;
    if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(&huart1,hdmatx,hdma_usart1_tx);

    /* DMA controller clock enable */
    __HAL_RCC_DMAMUX1_CLK_ENABLE();
    __HAL_RCC_DMA1_CLK_ENABLE();

    /* DMA interrupt init */
    /* DMA1_Channel1_IRQn interrupt configuration */
    HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 4);
    HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);
    /* DMA1_Channel2_IRQn interrupt configuration */
    HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 3);
    HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
}


void USB_Init(Circular_Buffer* my_buffer){
	stream_enable = STREAM_RESTART;
	circular_data_buffer = my_buffer;
	MX_USART1_UART_Init();
	UART1_DMA_Init(0);
	MX_USB_PCD_Init();

}





/**
  * @brief  Tx Transfer completed callback
  * @param  huart: UART handle.
  * @note   This example shows a simple way to report end of DMA Tx transfer, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
		if(stream_enable == STREAM_ON_PLAY){
			if(circular_data_buffer->read_ready((MY_SIZE/2))){
				Send_Array();
			}
			else{//not enough written to send yet
				Pause_Stream();
			}

		}
}

/**
  * @brief  Rx Transfer completed callback
  * @param  huart: UART handle
  * @note   This example shows a simple way to report end of DMA Rx transfer, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(str_cmp(close_rx_message, (char*)CLOSE_ARR, CLOSE_ARR_LEN)){//closing a stream
		close_rx_message[0] = 0;//clear the message
		Close_Stream();
	}

	if(str_cmp(restart_rx_message, (char*)RESTART_ARR, RESTART_ARR_LEN)){//restarting the stream - needs some delay probably in microseconds
		restart_rx_message[0] = 0;//clear the message
		stream_enable = STREAM_RESTART;
		toggle_LED(LED2);
	}
}

/**
  * @brief  UART error callbacks
  * @param  huart: UART handle
  * @note   This example shows a simple way to report transfer error, and you can
  *         add your own implementation.
  * @retval None
  */





/**
  * @brief USB Initialization Function
  * @param None
  * @retval None
  */
void MX_USB_PCD_Init(void)
{
	PCD_HandleTypeDef hpcd_USB_FS = {0};
  /* USER CODE BEGIN USB_Init 0 */

  /* USER CODE END USB_Init 0 */

  /* USER CODE BEGIN USB_Init 1 */

  /* USER CODE END USB_Init 1 */
  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_Init 2 */

  /* USER CODE END USB_Init 2 */

}




