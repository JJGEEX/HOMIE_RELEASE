/*
 * schedule.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#include "schedule.hpp"

Scheduler Homie_Scheduler;

//Scheduler init
    Scheduler::Scheduler(){
    	Scheduler::schedule = 0;
    	Scheduler::used_flags = 0;
    }

    //Scheduler deinit
    Scheduler::~Scheduler(){

    }


    //Add a flag to watch for and a function pointer to call
    //1 = success
    //0 = failure
    int Scheduler::init_flag(void (*function)(void), uint32_t flag){
    	if((flag & Scheduler::used_flags)||(!function) ){
    		return 0;
    	}
    	else{
    		int i = Scheduler::one_hot_to_num(flag);
    		if(i != -1){
        		Scheduler::used_flags |= flag;
        		Scheduler::function_array[i] = function;
        		return 1;
    		}
    		return 0;
    	}
    }

    //Remove an event from the schedulers use
    void Scheduler::deinit_flag(uint32_t flag){
		int i = Scheduler::one_hot_to_num(flag);
		if(i != -1){
			Scheduler::schedule &= ~flag;
			Scheduler::used_flags &= ~flag;
			Scheduler::function_array[i] = 0;
		}

    }
    //adds an event
    int Scheduler::add_event(uint32_t event){
    	int success = 0;
		int i = Scheduler::one_hot_to_num(event);
		if(i != -1){
			Scheduler::schedule |= event;
			success = 1;
		}
		return success;
    }

    int Scheduler::rem_event(uint32_t event){
    	int success = 0;
		int i = Scheduler::one_hot_to_num(event);
		if(i != -1){
			Scheduler::schedule &= ~event;
			success = 1;
		}
		return success;
    }



    //to convert 1 hot encoding to an index
    int Scheduler::one_hot_to_num(uint32_t index){
    	int val = 0;
    	for(int i= 0; i<32; i++){
    		if(index & 1){
    			return val;
    		}
    		index = index >> 1;
    		val++;
    	}
    	return -1; //error
    }


    //runs through the next event returns 0 if no events
    int Scheduler::run_events(void){
    	uint32_t index=1;
    	for(int i= 0; i<32; i++){
    		if(index & Scheduler::schedule & Scheduler::used_flags){
    			Scheduler::schedule &= ~index;
    			Scheduler::function_array[i]();//calls the function
    			return index;
    		}
    		index = index << 1;
    	}
    	return 0;
    }
