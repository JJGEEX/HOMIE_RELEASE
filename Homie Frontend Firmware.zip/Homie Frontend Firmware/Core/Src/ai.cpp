/*
 * ai.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion and Justin
 */

#include <ai.hpp>

#include <stdlib.h>



#define MFFCSIZE 8
#define WINDOW_SIZE 1024
#define FFT_SIZE WINDOW_SIZE/2+1
#define LOG_FFTSIZE 9


unsigned int a, b, c;
static Circular_Buffer* circular_data_buffer;
static kiss_fftr_cfg fft_config;
static float mffc_coeff[MFFCSIZE][MFFCSIZE];
//char buffer[160];
static float timedata[WINDOW_SIZE];





//Initializes the Artifical Intellegence Softwares
void AI_Init(Circular_Buffer* my_buffer){
	circular_data_buffer = my_buffer;

	int inverse_fft = 0;
	fft_config = kiss_fftr_alloc(WINDOW_SIZE, inverse_fft, 0, 0);
//	fft_init();
	MX_CRC_Init();
	MX_X_CUBE_AI_Init();


}



void AI_clear_buffer(void)
{
	circular_data_buffer->empty_buffer();
	return;
}





//finds if the word is correct or not
//This will check from the circular buffer
//Returns 0 - 1 based on probability
//returns -1 if not enough audio yet

float get_results(){


	//exit no AI yet val
	float NN_val = -1;

	//setup audio array
	int16_t my_array[1024];

	//runs if enough audio is availible
	if(circular_data_buffer->back_read(my_array, WINDOW_SIZE)){

//		a= HAL_GetTick();


		//convert audio to float for accurate computation
		for(int i=0; i<WINDOW_SIZE; i++){
			timedata[i] = ((float)my_array[i]);
		}



		//compute FFT using KISS FFT Library
		kiss_fft_cpx fout[FFT_SIZE];
		kiss_fftr(fft_config, timedata, fout);


		//compute fft
		//Keep the square of the fft

		unsigned long long int fft_data[FFT_SIZE];
		float real, imaginary, total;//, maxf;
		for(int i=0; i<FFT_SIZE; i++){
			real = fout[i].r;//std::real(freqdata[i]);///(2<<10);
			imaginary = fout[i].i;//std::imag(freqdata[i]);///(2<<10);
			real = real*real;
			imaginary = imaginary*imaginary;
			total = real + imaginary;//sqrt(real + imaginary);
//			fft_data[i] = (uint32_t)(total*1000);
//			fft_data[i] = (unsigned long int)total;//((uint32_t)(total));//divide by 10000*256*1000*32*1024
			fft_data[i] = (unsigned long long int)(total);
//			if(maxf<total){
//				maxf = total;
//				max=(unsigned long long int)fft_data[i];//overflows
//			}
		}


		//compute MFFC up to MFFC SIZE and add it to the matrix
		for(int i=0; i<(MFFCSIZE-1); i++){
			for(int j=0; j<MFFCSIZE; j++){
				mffc_coeff[i][j] = mffc_coeff[i+1][j];
			}
		}


		//compute mfcc for the next line of audio
		get_mfcc(mffc_coeff[7], fft_data);

		NN_val = MX_X_CUBE_AI_Process(mffc_coeff);

//		a= HAL_GetTick() - a;

	}

	return NN_val;
}








// MFCC Functions -------------------------------------------------------------------------
//returns the mffc of a given fft

#define AUDIO_SAMPLE_RATE 8000
#define NUMBER_MFCC_FILTERS 8
//This is the number of MFFCs to compute to

//static unsigned int centerFrequency[28] = {0, 533, 1067, 1600, 2133, 2667, 3200, 3733, 4267, 4800, 5333, 5867, 6400, 6933, 7467, 9198, 9850, 10554, 11306, 12110, 12972, 13895, 14884, 15943, 17078, 18294, 19595, 20990};
////these are shifted over <<3




/*
 * Computes the specified (mth) MFCC
 *
 * spectralData - array of doubles containing the results of FFT computation. This data is already assumed to be purely real
 * samplingRate - the rate that the original time-series data was sampled at (i.e 44100)
 * NumFilters - the number of filters to use in the computation. Recommended value = 48
 * binSize - the size of the spectralData array, usually a power of 2
 * m - The mth MFCC coefficient to compute
 *
 */
// has all the values of cosine with index one being l and index 2 being n

int FB[10] ={0, 21, 47, 79, 119, 168, 229, 304, 397, 512};

double GetCoefficient(unsigned long long int* spectralData, unsigned int samplingRate, unsigned int binSize, unsigned int m)
{
		unsigned int NumFilters = 8; //limiting to speed up
//		unsigned int result = 0.0f;
		double outerSum = 0.0f;

			// 0 <= m < L
			if(m >= NumFilters)
			{
				// This represents an error condition - the specified coefficient is greater than or equal to the number of filters. The behavior in this case is undefined.
				return 0.0f;
			}
		int prevCenterFrequency = FB[m];		// fc(l - 1) etc.
		int thisCenterFrequency = FB[m+1];
		int nextCenterFrequency = FB[m+2];
		int filterParameterA = 4096 / (thisCenterFrequency - prevCenterFrequency);
		int filterParameterB = 4096 / (thisCenterFrequency - nextCenterFrequency);//shift by 12
		int filterParameter;
		long long int partSum, innerSum = 0;
		float tmp;

//		float partSum, innerSum = 0;

		int boundary;
		for(int k = 0; k < FFT_SIZE - 1; k++){
			boundary = k;
			if(boundary >= 0 && boundary < prevCenterFrequency) continue;
			else if(boundary >= nextCenterFrequency) break;
			if(boundary >= prevCenterFrequency && boundary < thisCenterFrequency) //Case A
			{
				filterParameter = filterParameterA * (boundary - prevCenterFrequency); //forwarding the dividing
//				filterParameter = filterParameter >> 2; //remove the shifting
			}
			else if(boundary >= thisCenterFrequency && boundary < nextCenterFrequency) //Case B
			{//not keeping negative
				filterParameter = filterParameterB *(boundary - nextCenterFrequency); //forewarding the dividing
//				filterParameter = filterParameter >> 2; //remove the shifting
			}
			else {
				while(1); //error
			}

			tmp = (float)spectralData[k]* (float)filterParameter;

			partSum = (long long int)tmp;
			partSum = partSum;

			if(partSum < 0){
				innerSum -= partSum;
			}
			else{
				innerSum += partSum;
			}


		}
		if(innerSum > 0){
			outerSum = log(innerSum);
			outerSum -= 0.021; //cause to fix offset
//			outerSum -= 2.7725888;
			outerSum -= 6.9284;
			outerSum -= 2.7725888;
			outerSum -= 2.7725888;//16 scaling
			outerSum -= 8.31777;//4096 scaling
			outerSum -= 13.839;//from the fft needing to be divided by 512000
		}
		return outerSum;

}





//wrapper function for MFCC, getting the array of MFFC coefficients
void get_mfcc(float* output_data, unsigned long long int* input_data){
	float x;


	for(unsigned int i=0; i<MFFCSIZE; i++){
		x = GetCoefficient(input_data, AUDIO_SAMPLE_RATE, FFT_SIZE, i);

		output_data[i] = (float)x;

	}




}
