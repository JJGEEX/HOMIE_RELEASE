/*
 * SPI.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */
#include "SPI.hpp"
#include "pin_io.hpp"


//static SPI_HandleTypeDef SPI1_handle_struct;    //may need to go in header

#ifdef __cplusplus

static char  SPI1_TX_data[SPI1_TX_Buffer_Size];
static char  SPI1_RX_data[SPI1_RX_Buffer_Size];
/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
void SpiDrv::SPI1_open(void)
//void SPI1_open(void)
{

RCC->AHB2ENR |= RCC_APB2ENR_SPI1EN;  //clock enable
RCC->AHB2SMENR |= RCC_APB2SMENR_SPI1SMEN; //clock enabled for sleep mode

//GPIOA->MODER &= ~(GPIO_MODER_MODE1 |GPIO_MODER_MODE6 |GPIO_MODER_MODE7);  //GPIO registers
//GPIOA->MODER |= (GPIO_MODER_MODE1_1 |GPIO_MODER_MODE6_1 |GPIO_MODER_MODE7_1);

SPI1_handle_struct.Instance = SPI1;
SPI1_handle_struct.Init.Mode = SPI_MODE_MASTER;
SPI1_handle_struct.Init.Direction = SPI_DIRECTION_2LINES ;
//SPI1_handle_struct.Init.DataSize = SPI_DATASIZE_16BIT;
SPI1_handle_struct.Init.DataSize = SPI_DATASIZE_8BIT;
SPI1_handle_struct.Init.NSS = SPI_NSS_SOFT;
SPI1_handle_struct.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
SPI1_handle_struct.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
SPI1_handle_struct.Init.FirstBit = SPI_FIRSTBIT_MSB;
SPI1_handle_struct.Init.TIMode = SPI_TIMODE_DISABLE;

HAL_SPI_Init(&SPI1_handle_struct);

for(int i = 0; i < SPI1_TX_Buffer_Size; i++)
	SPI1_TX_data[i] = 0;
for(int i = 0; i < SPI1_RX_Buffer_Size; i++)
	SPI1_RX_data[i] = 0;
//SPI1_TX_data[16] = {0};
//SPI1_RX_data[16] = {0};

txDataPtr = SPI1_TX_data;
rxDataPtr = SPI1_RX_data;

//enabling interrupts

//HAL_NVIC_SetPriority(SPI1_IRQn,1,5);
//HAL_NVIC_EnableIRQ(SPI1_IRQn);

}

//=============================================================//
//  BELOW: Definitions of SPI Class Member Functions
//=============================================================//


static bool inverted_reset = false;
//SPIClass *WIFININA_SPIWIFI=&SPI;
//int8_t WIFININA_SLAVESELECT = 10, WIFININA_SLAVEREADY = 7,
//  WIFININA_SLAVERESET = 5, WIFININA_SLAVEGPIO0 = 6;

#define DELAY_TRANSFER()


// "Kick" the AirLift module because it isn't working properly.
void SpiDrv::kick()
{
	HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin, GPIO_PIN_RESET);
	HAL_Delay(10);
	HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin, GPIO_PIN_SET);
	HAL_Delay(50);
}

void SpiDrv::begin()
{
	HAL_GPIO_WritePin(SPI1_CS_Port, SPI1_CS_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin, GPIO_PIN_RESET);
	HAL_Delay(10);
	HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin, GPIO_PIN_SET);
	HAL_Delay(750);
	initialized = true;
	return;
}

void SpiDrv::end() {
	HAL_GPIO_WritePin(WIFI_RESET_Port, WIFI_RESET_Pin, GPIO_PIN_RESET);

	// In the Arduino SPI library, this Disables the SPI Bus.
    //pinMode(WIFININA_SLAVESELECT, INPUT);
    //WIFININA_SPIWIFI->end();

    initialized = false;
}

void SpiDrv::spiSlaveSelect()
{
    //WIFININA_SPIWIFI->beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
    //digitalWrite(WIFININA_SLAVESELECT, LOW);
	bool ready = false;
	GPIO_PinState BUSY_Status = GPIO_PIN_SET;

	// Wait for the ready signal.
	do{
		BUSY_Status = HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin);
		if(BUSY_Status == GPIO_PIN_RESET)
			ready = true;
		else
			HAL_Delay(10);
	}while(!ready);
	HAL_GPIO_WritePin(SPI1_CS_Port, SPI1_CS_Pin, GPIO_PIN_RESET);
	return;

    // wait for up to 5 ms for the NINA to indicate it is not ready for transfer
    // the timeout is only needed for the case when the shield or module is not present
    //-----
	// Original code:
	//for (unsigned long start = millis(); (digitalRead(WIFININA_SLAVEREADY) != HIGH) && (millis() - start) < 5;);
	// My attempt:
	//for(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) == GPIO_PIN_SET)

	// Not gonna do ^^ that right now because it says it's only needed in case
	// the Airlift isn't present, which should never be the case anyway.
}


void SpiDrv::spiSlaveDeselect()
{
	HAL_GPIO_WritePin(SPI1_CS_Port, SPI1_CS_Pin, GPIO_PIN_SET);

	// I don't think we need to do anything like what the next line does.
	//WIFININA_SPIWIFI->endTransaction();
	return;
}


char SpiDrv::spiTransfer(unsigned char data)
{
	//HAL_StatusTypeDef HAL_SPI_TransmitReceive(SPI_HandleTypeDef *hspi, uint8_t *pTxData, uint8_t *pRxData, uint16_t Size,
	//                                          uint32_t Timeout);
	unsigned char _readChar = 0;
	//HAL_SPI_TransmitReceive(&SPI1_handle_struct, (uint8_t *)txDataPtr, &_readChar, 1, 100);
	HAL_SPI_TransmitReceive(&SPI1_handle_struct, &data, &_readChar, 1, 100);
	//HAL_SPI_TransmitReceive(&SPI1_handle_struct, (uint8_t *)txDataPtr, (uint8_t *)rxDataPtr, 1, 100);
	//char result = (char *)rxDataPtr;
	char result = rxDataPtr[0];
	result = _readChar;
	//char result = WIFININA_SPIWIFI->transfer(data);
    //DELAY_TRANSFER();
    return result;                    // return the received byte
}

int SpiDrv::waitSpiChar(unsigned char waitChar)
{
    volatile int timeout = TIMEOUT_CHAR;
    unsigned char _readChar = 0;
    do{
        //_readChar = readChar(); //get data byte
        HAL_SPI_Receive(&SPI1_handle_struct, &_readChar, 1, 10000);
        if (_readChar == ERR_CMD)
        {
        	// We don't use this kind of WARN thing
        	//WARN("Err cmd received\n");
        	//return -1;
        	return 0;
        }
    }while((timeout-- > 0) && (_readChar != waitChar));
    return  (_readChar == waitChar);
}

int SpiDrv::waitSpiChar_alt(unsigned char waitChar)
{
    volatile int timeout = TIMEOUT_CHAR;
    unsigned char _readChar = 0;
    do{
        //_readChar = readChar(); //get data byte
        HAL_SPI_Receive(&SPI1_handle_struct, &_readChar, 1, 10000);
        if (_readChar == ERR_CMD)
        {
        	// We don't use this kind of WARN thing
        	//WARN("Err cmd received\n");
        	return -1;
        	//return 0;
        }
    }while((timeout-- > 0) && (_readChar != waitChar));
    return  (_readChar == waitChar);
}

int SpiDrv::readAndCheckChar(char checkChar, char* readChar)
{
	// How I was doing stuff before
	/*getParam((uint8_t*)readChar);

    return  (*readChar == checkChar);*/

	// How I'm doing stuff now.
	// EXPERIMENTAL.
	bool manipB = true;
	volatile uint16_t counterThing = 0;
	unsigned char _readChar;

	while(manipB)
	{
		HAL_SPI_Receive(&SPI1_handle_struct, &_readChar, 1, 100);
		//manipB = (!(_readChar == checkChar));
		if(_readChar == checkChar)
		{
			manipB = false;
			counterThing = 0;
		}
		else
			counterThing++;
		//return (_readChar == checkChar);
	};
	return (_readChar == checkChar);
}

char SpiDrv::readChar()
{
	uint8_t readChar = 0;
	getParam(&readChar);
	return readChar;
}

#define WAIT_START_CMD(x) waitSpiChar(START_CMD)

/*bool check_start_cmd(x)
{
	if(!waitSpiChar(START_CMD))
	{
		return 0;
	}
}*/

#define IF_CHECK_START_CMD(x)                      \
    if (!WAIT_START_CMD(_data))                 \
    {                                           \
        TOGGLE_TRIGGER()                        \
        WARN("Error waiting START_CMD");        \
        return 0;                               \
    }else                                       \

#define CHECK_DATA(check, x)                   \
        if (!readAndCheckChar(check, &x))   \
        {                                               \
        	TOGGLE_TRIGGER()                        \
            WARN("Reply error");                        \
            INFO2(check, (uint8_t)x);							\
            return 0;                                   \
        }else                                           \

//#define waitSlaveReady() (digitalRead(WIFININA_SLAVEREADY) == LOW)
inline void waitSlaveReady()
{
	while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) == GPIO_PIN_RESET);
}
//#define waitSlaveSign() (digitalRead(WIFININA_SLAVEREADY) == HIGH)
inline void waitSlaveSign()
{
	while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) == GPIO_PIN_SET);
}
//#define waitSlaveSignalH() while(digitalRead(WIFININA_SLAVEREADY) != HIGH){}
inline void waitSlaveSignalH()
{
	while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) != GPIO_PIN_SET);
}
//#define waitSlaveSignalL() while(digitalRead(WIFININA_SLAVEREADY) != LOW){}
inline void waitSlaveSignalL()
{
	while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) != GPIO_PIN_RESET);
}

void SpiDrv::waitForSlaveSign()
{
	//while (!waitSlaveSign());
	while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) != GPIO_PIN_SET);
}

void SpiDrv::waitForSlaveReady()
{
	//while (!waitSlaveReady());
	//while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) != GPIO_PIN_RESET);
	while(HAL_GPIO_ReadPin(WIFI_BUSY_Port, WIFI_BUSY_Pin) == GPIO_PIN_SET);
	return;
}

void SpiDrv::getParam(uint8_t* param)
{
    // Get Params data
    *param = spiTransfer(DUMMY_DATA);
    DELAY_TRANSFER();
}

int SpiDrv::waitResponseCmd(uint8_t cmd, uint8_t numParam, uint8_t* param, uint8_t* param_len)
{
    char _data = 0;
    int ii = 0;
    if(!waitSpiChar(START_CMD))
    	return 0;
    else
    {
    	if (!readAndCheckChar(cmd | REPLY_FLAG, &_data))
    		return 0;

    	if (!readAndCheckChar(numParam, &_data))
    		return 0;
    	else
        {
            readParamLen8(param_len);
            for (ii=0; ii<(*param_len); ++ii)
            {
                // Get Params data
                //param[ii] = spiTransfer(DUMMY_DATA);
                getParam(&param[ii]);
            }
        }

        readAndCheckChar(END_CMD, &_data);
    }

    return 1;
}

int SpiDrv::waitResponseCmd16(uint8_t cmd, uint8_t numParam, uint8_t* param, uint16_t* param_len)
{
    char _data = 0;
    int i =0, ii = 0;

    //IF_CHECK_START_CMD(_data)
    if(!waitSpiChar(START_CMD))
    	return 0;
    else
    {
        //CHECK_DATA(cmd | REPLY_FLAG, _data){};
        if(!readAndCheckChar(cmd | REPLY_FLAG, &_data))
        	return 0;

        //CHECK_DATA(numParam, _data);
        if (!readAndCheckChar(numParam, &_data))
        	return 0;
        else
        {
            readParamLen16(param_len);
            for (ii=0; ii<(*param_len); ++ii)
            {
                // Get Params data
                param[ii] = spiTransfer(DUMMY_DATA);
            }
        }

        readAndCheckChar(END_CMD, &_data);
    }

    return 1;
}

int SpiDrv::waitResponseData16(uint8_t cmd, uint8_t* param, uint16_t* param_len)
{
    char _data = 0;
    uint16_t ii = 0;

    if(!waitSpiChar(START_CMD))
    	return 0;
    else
    {
    	if (!readAndCheckChar(cmd | REPLY_FLAG, &_data))
    		return 0;

        uint8_t numParam = readChar();
        if (numParam != 0)
        {
            readParamLen16(param_len);
            for (ii=0; ii<(*param_len); ++ii)
            {
                // Get Params data
                //param[ii] = spiTransfer(DUMMY_DATA);
                getParam(&param[ii]);
            }
        }

        readAndCheckChar(END_CMD, &_data);
    }

    return 1;
}

int SpiDrv::waitResponseData8(uint8_t cmd, uint8_t* param, uint8_t* param_len)
{
    char _data = 0;
    int ii = 0;

    //if(!waitSpiChar_alt(START_CMD))
    if(!waitSpiChar(START_CMD))
    	return 0;
    else
    {
    	if (!readAndCheckChar(cmd | REPLY_FLAG, &_data))
    		return 0;

        uint8_t numParam = readChar();
        if (numParam != 0)
        {
            readParamLen8(param_len);
            for (ii=0; ii<(*param_len); ++ii)
            {
                // Get Params data
                //param[ii] = spiTransfer(DUMMY_DATA);
                getParam(&param[ii]);
            }
        }

        readAndCheckChar(END_CMD, &_data);
    }

    return 1;
}

int SpiDrv::waitResponseParams(uint8_t cmd, uint8_t numParam, tParam* params)
{
    char _data = 0;
    int i =0, ii = 0;


    if(!waitSpiChar(START_CMD))
    	return 0;
    else
    {
    	if (!readAndCheckChar(cmd | REPLY_FLAG, &_data))
    		return 0;

        uint8_t _numParam = readChar();
        if (_numParam != 0)
        {
            for (i=0; i<_numParam; ++i)
            {
                params[i].paramLen = readParamLen8();
                for (ii=0; ii<params[i].paramLen; ++ii)
                {
                    // Get Params data
                    params[i].param[ii] = spiTransfer(DUMMY_DATA);
                }
            }
        } else
        {
            //WARN("Error numParam == 0");
            return 0;
        }

        if (numParam != _numParam)
        {
            //WARN("Mismatch numParam");
            return 0;
        }

        readAndCheckChar(END_CMD, &_data);
    }
    return 1;
}

/*
int SpiDrv::waitResponse(uint8_t cmd, tParam* params, uint8_t* numParamRead, uint8_t maxNumParams)
{
    char _data = 0;
    int i =0, ii = 0;

    IF_CHECK_START_CMD(_data)
    {
        CHECK_DATA(cmd | REPLY_FLAG, _data){};

        uint8_t numParam = readChar();

        if (numParam > maxNumParams)
        {
            numParam = maxNumParams;
        }
        *numParamRead = numParam;
        if (numParam != 0)
        {
            for (i=0; i<numParam; ++i)
            {
                params[i].paramLen = readParamLen8();

                for (ii=0; ii<params[i].paramLen; ++ii)
                {
                    // Get Params data
                    params[i].param[ii] = spiTransfer(DUMMY_DATA);
                }
            }
        } else
        {
            WARN("Error numParams == 0");
            Serial.println(cmd, 16);
            return 0;
        }
        readAndCheckChar(END_CMD, &_data);
    }
    return 1;
}
*/

int SpiDrv::waitResponse(uint8_t cmd, uint8_t* numParamRead, uint8_t** params, uint8_t maxNumParams)
{
    char _data = 0;
    int i =0, ii = 0;

    char    *index[WL_SSID_MAX_LENGTH];

    for (i = 0 ; i < WL_NETWORKS_LIST_MAXNUM ; i++)
           index[i] = (char *)params + WL_SSID_MAX_LENGTH*i;
    	//index[i] = (char *)params + WL_SSID_MAX_LENGTH;

    if(!waitSpiChar(START_CMD))
    	return 0;
    else
    {
    	if (!readAndCheckChar(cmd | REPLY_FLAG, &_data))
    		return 0;

        uint8_t numParam = readChar();

        if (numParam > maxNumParams)
        {
            numParam = maxNumParams;
        }
        *numParamRead = numParam;
        if (numParam != 0)
        {
            for (i=0; i<numParam; ++i)
            {
            	uint8_t paramLen = readParamLen8();
                for (ii=0; ii<paramLen; ++ii)
                {
                	//ssid[ii] = spiTransfer(DUMMY_DATA);
                    // Get Params data
                    index[i][ii] = (uint8_t)spiTransfer(DUMMY_DATA);

                }
                index[i][ii]=0;
            }
        } else
        {
            //WARN("Error numParams == 0");
            readAndCheckChar(END_CMD, &_data);
            return 0;
        }
        readAndCheckChar(END_CMD, &_data);
    }
    return 1;
}


void SpiDrv::sendParam(uint8_t* param, uint8_t param_len, uint8_t lastParam)
{
    int i = 0;
    // Send Spi paramLen
    sendParamLen8(param_len);

    // Send Spi param data
    /*for (i=0; i<param_len; ++i)
    {
        spiTransfer(param[i]);
    }*/
    HAL_SPI_TransmitReceive(&SPI1_handle_struct, param, (uint8_t *)rxDataPtr, param_len, 100);

    // if lastParam==1 Send Spi END CMD
    if (lastParam == 1)
        spiTransfer(END_CMD);
}

void SpiDrv::sendParamLen8(uint8_t param_len)
{
    // Send Spi paramLen
    spiTransfer(param_len);
}

void SpiDrv::sendParamLen16(uint16_t param_len)
{
    // Send Spi paramLen
    spiTransfer((uint8_t)((param_len & 0xff00)>>8));
    spiTransfer((uint8_t)(param_len & 0xff));
}

uint8_t SpiDrv::readParamLen8(uint8_t* param_len)
{
    uint8_t _param_len = spiTransfer(DUMMY_DATA);
    if (param_len != NULL)
    {
        *param_len = _param_len;
    }
    return _param_len;
}

uint16_t SpiDrv::readParamLen16(uint16_t* param_len)
{
    //uint16_t _param_len = spiTransfer(DUMMY_DATA)<<8 | (spiTransfer(DUMMY_DATA)& 0xff);
    uint8_t paramLen_1 = spiTransfer(DUMMY_DATA);
    uint8_t paramLen_2 = spiTransfer(DUMMY_DATA);
    uint16_t _param_len = (paramLen_1<<8) | (paramLen_2 & 0xff);
    if (param_len != NULL)
    {
        *param_len = _param_len;
    }
    return _param_len;
}


void SpiDrv::sendBuffer(uint8_t* param, uint16_t param_len, uint8_t lastParam)
{
    uint16_t i = 0;

    // Send Spi paramLen
    sendParamLen16(param_len);

    // Send Spi param data
    for (i=0; i<param_len; ++i)
    {
        spiTransfer(param[i]);
    }

    // if lastParam==1 Send Spi END CMD
    if (lastParam == 1)
        spiTransfer(END_CMD);
}


void SpiDrv::sendParam(uint16_t param, uint8_t lastParam)
{
    // Send Spi paramLen
    sendParamLen8(2);

    spiTransfer((uint8_t)((param & 0xff00)>>8));
    spiTransfer((uint8_t)(param & 0xff));

    // if lastParam==1 Send Spi END CMD
    if (lastParam == 1)
        spiTransfer(END_CMD);
}

/* Cmd Struct Message */
/* _________________________________________________________________________________  */
/*| START CMD | C/R  | CMD  |[TOT LEN]| N.PARAM | PARAM LEN | PARAM  | .. | END CMD | */
/*|___________|______|______|_________|_________|___________|________|____|_________| */
/*|   8 bit   | 1bit | 7bit |  8bit   |  8bit   |   8bit    | nbytes | .. |   8bit  | */
/*|___________|______|______|_________|_________|___________|________|____|_________| */

void SpiDrv::sendCmd(uint8_t cmd, uint8_t numParam)
{
    // Send Spi START CMD
    spiTransfer(START_CMD);

    // Send Spi C + cmd
    spiTransfer(cmd & ~(REPLY_FLAG));

    // Send Spi totLen
    //spiTransfer(totLen);

    // Send Spi numParam
    spiTransfer(numParam);

    // If numParam == 0 send END CMD
    if (numParam == 0)
        spiTransfer(END_CMD);
    return;
}

int SpiDrv::available()
{
	// Reimplement this if we decide to connect the GPIO0 pin from the AirLift.
  /*if (WIFININA_SLAVEGPIO0 >= 0) {
    return (digitalRead(WIFININA_SLAVEGPIO0) == HIGH);
  }*/
  return true;
}

//SpiDrv spiDrv;
SpiDrv airLift;

#endif






