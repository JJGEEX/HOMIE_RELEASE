/*
 * uart.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_UART_HPP_
#define INC_UART_HPP_
#include "stm32wbxx_hal.h"
#include "error_handling.hpp"
//UART_HandleTypeDef huart1;

//void MX_USART1_UART_Init(void);

#endif /* INC_UART_HPP_ */
