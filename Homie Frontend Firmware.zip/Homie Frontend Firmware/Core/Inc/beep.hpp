/*
 * beep.hpp
 *
 *  Created on: Feb 20, 2021
 *      Author: thwai
 */

#ifndef INC_BEEP_HPP_
#define INC_BEEP_HPP_
#include "OS.hpp"



#ifdef __cplusplus
void beep_init(Circular_Buffer * my_output_buffer);
#endif

void Beep(unsigned int frequency, unsigned int duration);
void Tone(unsigned int frequency, unsigned int duration);
void tone_gen(unsigned int frequency, unsigned int samples);

void power_up();
void pairing();
void success();
void error();
void listening();

void mario();

#endif /* INC_BEEP_HPP_ */
