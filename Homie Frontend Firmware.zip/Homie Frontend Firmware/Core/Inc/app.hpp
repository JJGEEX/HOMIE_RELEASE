/*
 * app.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_APP_HPP_
#define INC_APP_HPP_

#include "stm32wbxx_hal.h"
#include "wifi.hpp"
#include "main.hpp"
#include "clock.hpp"

//#include "homie_helix.hpp"


void app_setup(void);
void app_config(void);

enum{ // packetTypes
	TEXT_PACKET, // to be printed
	AUDIO_PACKET, // to be played
	TESTING_PACKET, // flexible use, for running tests
	MICSTRM_START_PACKET,
	MICSTRM_STOP_PACKET,
	MP3_AUDIO_PACKET,
	COMMAND_CANCEL_PACKET,
	VOICE_REC_ERROR_PACKET,
	CONNECTION_ERROR_PACKET,
	CONNECTION_READY_PACKET,
	HANDSHAKE_REQUEST_PACKET,
	GOOD_DATA_PACKET,
	DATA_FLUSH_PACKET,
	PLEASE_WAIT_PACKET,
};

#endif /* INC_APP_HPP_ */
