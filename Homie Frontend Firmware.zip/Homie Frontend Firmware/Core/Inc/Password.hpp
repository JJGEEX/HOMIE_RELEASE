/*
 * Password.hpp
 *
 *  Created on: Feb 2, 2021
 *      Author: thwai
 */

#ifndef INC_PASSWORD_HPP_
#define INC_PASSWORD_HPP_


// Don't forget to define these for your network right here!
#define SECRET_SSID "Homie_Demo_Net"//"yournetwork"
#define SECRET_PASS "Homie123"//"yourpassword"


#endif /* INC_PASSWORD_HPP_ */
