/*
 * SPI.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_SPI_HPP_
#define INC_SPI_HPP_
#include "stm32wbxx_hal.h"
#include "error_handling.hpp"
#include "wifi_spi.hpp"
#include <stdbool.h>

#define SPI1_TX_Buffer_Size     16
#define SPI1_RX_Buffer_Size     16

// BOARD DEFINE -- ONLY ONE AT A TIME
#define DEV_BOARD
//#define HOMIE_BOARD_R1

// SPI Pins -- NOTICE: DIFFERENT BETWEEN DEV BOARD AND HOMIE PCB
// FOR DEV BOARD:
//=============================================
// FUNCTION |  DEVBRD  |  HOMIE R1
// SPI1_CS:     PB2         PA4
// SPI1_SCK:    PA5         PA5
// SPI1_MISO:   PA6         PA6
// SPI1_MOSI:	PA7         PA7
// WIFI_BUSY:   PA1         PA1
// WIFI_RESET:  PC4         PC4


                                            //
//static volatile uint8_t  SPI1_TX_data[SPI1_TX_Buffer_Size];
//static volatile uint8_t  SPI1_RX_data[SPI1_RX_Buffer_Size];


//=============================================================//
//NOTE: Because SPI1_ACK_ISR() must be call-able from stm32wbxx_it.c,
//       this extra stuff is necessary to help the compiler properly deal
//       bridge the gap and make these C++ functions call-able from
//       the pure C portions of the program.
//  -Grant
#ifdef __cplusplus
#define EXTERNC extern "C"
#else
#define EXTERNC
#endif

EXTERNC void SPI1_ACK_ISR(void);

#undef EXTERNC
//=============================================================//

//=============================================================//
//  Definition of the SPI Driver Class
//=============================================================//
#define SPI_START_CMD_DELAY 	10

#define NO_LAST_PARAM   0
#define LAST_PARAM      1

#define DUMMY_DATA  0xFF

/*#define WAIT_FOR_SLAVE_SELECT()	      \
	if (!SpiDrv::initialized) {           \
		SpiDrv::begin();      \
	}                             \
	SpiDrv::waitForSlaveReady();  \
	SpiDrv::spiSlaveSelect();*/
#ifdef __cplusplus
class SpiDrv
{
private:
	//static bool waitSlaveReady();
	void waitForSlaveSign();
	void getParam(uint8_t* param);
	SPI_HandleTypeDef SPI1_handle_struct;
	char *txDataPtr;
	char *rxDataPtr;
public:
    bool initialized;

    void SPI1_open();

    void kick();

    void begin();

    void end();

    void spiDriverInit();

    void spiSlaveSelect();

    void spiSlaveDeselect();

    char spiTransfer(unsigned char data);

    void waitForSlaveReady();

    //static int waitSpiChar(char waitChar, char* readChar);

    int waitSpiChar(unsigned char waitChar);

    int waitSpiChar_alt(unsigned char waitChar);

    int readAndCheckChar(char checkChar, char* readChar);

    char readChar();

    int waitResponseParams(uint8_t cmd, uint8_t numParam, tParam* params);

    int waitResponseCmd(uint8_t cmd, uint8_t numParam, uint8_t* param, uint8_t* param_len);

    int waitResponseCmd16(uint8_t cmd, uint8_t numParam, uint8_t* param, uint16_t* param_len);

    int waitResponseData8(uint8_t cmd, uint8_t* param, uint8_t* param_len);

    int waitResponseData16(uint8_t cmd, uint8_t* param, uint16_t* param_len);
 /*
    static int waitResponse(uint8_t cmd, tParam* params, uint8_t* numParamRead, uint8_t maxNumParams);

    static int waitResponse(uint8_t cmd, uint8_t numParam, uint8_t* param, uint16_t* param_len);
*/
    int waitResponse(uint8_t cmd, uint8_t* numParamRead, uint8_t** params, uint8_t maxNumParams);

    void sendParam(uint8_t* param, uint8_t param_len, uint8_t lastParam = NO_LAST_PARAM);

    void sendParamLen8(uint8_t param_len);

    void sendParamLen16(uint16_t param_len);

    uint8_t readParamLen8(uint8_t* param_len = NULL);

    uint16_t readParamLen16(uint16_t* param_len = NULL);

    void sendBuffer(uint8_t* param, uint16_t param_len, uint8_t lastParam = NO_LAST_PARAM);

    void sendParam(uint16_t param, uint8_t lastParam = NO_LAST_PARAM);

    void sendCmd(uint8_t cmd, uint8_t numParam);

    int available();
};

//extern SpiDrv spiDrv;
extern SpiDrv airLift;

#endif

#endif /* INC_SPI_HPP_ */
