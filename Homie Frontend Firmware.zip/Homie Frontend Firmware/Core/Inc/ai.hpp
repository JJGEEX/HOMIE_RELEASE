/*
 * ai.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_AI_HPP_
#define INC_AI_HPP_


#include <crc.hpp>
#include <kfft_api.h>
#include <network.h>
#include <network_data.h>
#include "stm32wbxx_hal.h"
#include "app_x-cube-ai.h"
#include "OS.hpp"

#define SAMPLE_RATE 8000
#define NUMBER_FILTERS 26

#ifdef __cplusplus
void AI_Init(Circular_Buffer* my_buffer);
#endif

void AI_clear_buffer(void);

float get_results();
void get_mfcc(float* output_data, unsigned long long int* input_data);
int tone_predict();

#endif /* INC_AI_HPP_ */
