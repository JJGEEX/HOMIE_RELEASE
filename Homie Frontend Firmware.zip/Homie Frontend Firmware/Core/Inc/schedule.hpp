/*
 * schedule.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion and Justin
 */

#ifndef INC_SCHEDULE_HPP_
#define INC_SCHEDULE_HPP_

#include "stm32wbxx_hal.h"
#include "OS.hpp"

//--------------------------Define Events ----------------------------------------
#define PUSHBUTTON_EVENT     		 	1<<0
#define MICDONE_EVENT 					1<<1
#define PKTCHECK_EVENT					1<<2
#define WIFI_ASEND_EVENT				1<<3
#define SLEEP_EVENT 					1<<31
//--------------------------------------------------------------------------------


#ifdef __cplusplus

class Scheduler {
  private:
    uint32_t schedule;
    void (*function_array[32])(void);
    uint32_t used_flags;
    int one_hot_to_num(uint32_t index);

  public:
    Scheduler();
    ~Scheduler();
    int init_flag(void (*function)(void), uint32_t flag);
    void deinit_flag(uint32_t flag);
    int add_event(uint32_t event);
    int rem_event(uint32_t event);

    int run_events(void);
};

extern Scheduler Homie_Scheduler;
#endif


#endif /* INC_SCHEDULE_HPP_ */
