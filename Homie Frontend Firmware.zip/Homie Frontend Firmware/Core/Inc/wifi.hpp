/*
 * wifi.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: Xavion Cowans & Grant Capan
 */

#ifndef INC_WIFI_HPP_
#define INC_WIFI_HPP_

#include "stm32wbxx_hal.h"
#include "OS.hpp"
#include "SPI.hpp"
#include "pin_io.hpp"
#include "wl_types.h"
#include "wl_definitions.h"
#include <string.h>
#include <Password.hpp>

//#include "amp_driver.hpp"
#include "clock.hpp"
#include "display.hpp"
#include "neopixels.hpp"
//#include "circular_buffer.hpp"
//#include "OS.hpp"

#define WL_FAILURE		-1
#define WL_SUCCESS		1

// Don't forget to define these for your network right here!
//#define SECRET_SSID ""//"yournetwork"
//#define SECRET_PASS ""//"yourpassword"

// STRUCTS & TYPEDEFS
struct WiFiClient_DataStruct
{
	uint16_t srcport;
	uint16_t _socket;
};


static volatile char WIFI_TX_DATA[16];
static volatile char WIFI_RX_DATA[16];

#define MAX_NETWORK_LIST 10
#define MAX_SSID_LENGTH  30
#define NUM_NETWORK_ATTEMPTS 10

#define FW_VER_LENGTH 6

static char networkSSID[MAX_NETWORK_LIST][MAX_SSID_LENGTH];

void WiFi_kick(void);

uint8_t WiFi_Demo(char *ssid, char *pass, uint32_t IPAddr, uint32_t port);
//uint8_t WiFi_AudioStreamTest(void);

#ifdef __cplusplus
uint8_t WiFi_AudioStreamTest(Circular_Buffer* my_buffer);
#endif

uint8_t WiFi_packetCheckEvent(void);
void WIFI_Init(void);

void Wifi_setup(void);
void WiFi_updateLocalInfo(void);
void WiFi_getNetworkData(uint8_t *ip, uint8_t *mask, uint8_t *gwip);
void WiFi_getFirmwareVersion(char * fw_data);

uint8_t WiFi_getStatus(void);
int8_t wifiSetPassphrase(const char* ssid, uint8_t ssid_len, const char *passphrase, const uint8_t len);
int8_t WiFi_connectWPA(void);
void WiFi_setSock(uint8_t newSock);

void printCurrentNet(void);
char* WiFi_getCurrentSSID();
uint8_t* WiFi_getCurrentBSSID();
int32_t WiFi_getCurrentRSSI();
uint8_t WiFi_getCurrentEncryptionType();

void printMacAddress(uint8_t mac[]);

void TEST_connectTCP();
int TEST_pingGoogle();
int TEST_Adafruit();

uint32_t makeIP(uint8_t seg1, uint8_t seg2, uint8_t seg3, uint8_t seg4);
void WiFi_setDNS(uint8_t validParams, uint32_t dns_server1, uint32_t dns_server2);
uint8_t WiFi_reqHostByName(const char* aHostname);
int INTERNAL_getHostByName(uint32_t **aResult);
int WiFi_getHostByName(const char* aHostname, uint32_t* aResult);

//void WiFi_startClient(uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode);
void WiFi_startClientWithHost(const char* host, uint8_t host_len, uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode);
int WiFi_hostConnect(char *host, uint16_t port, uint8_t sock);
int WiFi_connect(uint32_t ip, uint16_t port, uint8_t sock);
void WiFi_stopClient(uint8_t sock);
void WiFiClient_stop(uint8_t *sock);

uint8_t WiFiClient_connected(uint8_t sock);
uint8_t WiFiClient_status(uint8_t sock);
int WiFiClient_available(uint8_t socket);
int WiFiClient_read(uint8_t socket);
size_t WiFiClient_bigRead(uint8_t socket, uint8_t* returnArr, size_t returnLength);
void WiFi_INTERNAL_startClient(uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode);
int WiFiClient_Connect(uint32_t ip, uint16_t port);
void WiFi_stopClient(uint8_t sock);

void WiFi_startServer(uint16_t port, uint8_t sock, uint8_t protMode);
uint8_t WiFi_getServerState(uint8_t sock);
void WiFi_DEBUG_printServerStatus(uint8_t status);
uint16_t WiFiServer_availData(uint8_t sock);
uint8_t WiFiServer_availServer(uint8_t sock);
bool WiFiServer_getData(uint8_t sock, uint8_t *data, uint8_t peek);
//bool WiFiServer_getData(uint8_t sock, uint8_t *data);
struct WiFiClient_DataStruct WiFiServer_availableClient();

uint8_t WiFi_TCP_getClientState(uint8_t sock);
uint16_t WiFi_TCP_sendData(uint8_t sock, const uint8_t *data, uint16_t len);


bool WiFi_TCP_getData(uint8_t sock, uint8_t *_data, uint8_t peek);
bool WiFi_TCP_getDataBuf(uint8_t sock, uint8_t *_data, uint16_t *_dataLen);
bool WiFi_TCP_insertDataBuf(uint8_t sock, const uint8_t *data, uint16_t _len);
uint8_t WiFi_getSocket();

void ScanNetworks(void);
int WifiPing(uint32_t ipAddress);
int SendPacket(const char * host, uint32_t ipAddress, uint16_t port, uint8_t sock, uint8_t protMode ,char * data2send);



#endif /* INC_WIFI_HPP_ */
