/*
 * neopixels.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author:  Grant modified by Xavion
 */

#ifndef INC_NEOPIXELS_HPP_
#define INC_NEOPIXELS_HPP_

#include "stm32wbxx_hal.h"


// INCLUDES
#include "usb.hpp"

/*Flash Patterns*/
enum{
	NEOPIXEL_NO_FLASH,
	NEOPIXEL_STEADY_FLASH,
	NEOPIXEL_LEFT_RIGHT_SCROLL,
	NEOPIXEL_RIGHT_LEFT_SCROLL,
	NEOPIXEL_CONVERGENCE_SCROLL,
	NEOPIXEL_DIVERGENCE_SCROLL,
};

/* Speed Sections*/
enum{
	NEOPIXEL_SPEED_NA,
	NEOPIXEL_SPEED_SLOW   = 750,
	NEOPIXEL_SPEED_MEDIUM = 500,
	NEOPIXEL_SPEED_FAST   = 250,
};

/*Colors*/
#define PURE_GREEN   {0x00, 0xFF, 0x00}
#define DARK_GREEN   {0x00, 0x64, 0x00}
#define PURE_RED     {0xFF, 0x00, 0x00}
#define DARK_RED     {0x64, 0x00, 0x00}
#define PURE_YELLOW	 {0xFF, 0xFF, 0x00}
#define DARK_YELLOW  {0x80, 0x80, 0x00}
#define PURE WHITE   {0xFF, 0xFF, 0xFF}
#define DARK_WHITE   {0x64, 0x64, 0x64}
#define PURE_BLUE    {0x00, 0x00, 0xFF}
#define DARK_BLUE	 {0x00, 0x00, 0x64}
#define ORANGE		 {0xCA, 0x3F, 0x00}
#define CLEAR        {0x00, 0x00, 0x00}


/*Fast Color*/
#define _PURE_GREEN   	0x00, 0xFF, 0x00
#define _DARK_GREEN   	0x00, 0x64, 0x00
#define _PURE_RED     	0xFF, 0x00, 0x00
#define _DARK_RED     	0x64, 0x00, 0x00
#define _PURE_YELLOW  	0xFF, 0xFF, 0x00
#define _DARK_YELLOW  	0x80, 0x80, 0x00
#define _PURE WHITE   	0xFF, 0xFF, 0xFF
#define _DARK_WHITE   	0x64, 0x64, 0x64
#define _PURE_BLUE    	0x00, 0x00, 0xFF
#define _DARK_BLUE	 	0x00, 0x00, 0x64
#define _ORANGE		 	0xCA, 0x3F, 0x00
#define _CLEAR        	0x00, 0x00, 0x00
#define _TURQUOISE		0x28, 0xcc, 0x98


// DEFINES
#define NP_PORT			GPIOA
#define NP_DATAPIN		GPIO_PIN_0

//#define NP_PORT             GPIOC
//#define NP_DATAPIN          GPIO_PIN_15


// FUNCTION PROTOTYPES
void shorterDelay(int counter);

void neo_neoPixelsInit(void);

void neo_write0bit(void);

void delayCheckFunction(void);

void neo_setVal(uint8_t index, uint8_t r, uint8_t g, uint8_t b);

void neo_writePixels(void);

void clear_neoPixels(void);

void write_pattern(uint8_t * color, uint8_t flash_type, uint8_t speed);

void neo_demo(void);

void neo_error(void);

void neo_success(void);

void neo_pairing(void);

void neo_paired(void);

void neo_notification(void);

void neo_listening(void);

void neo_heard(void);

void neo_default(void);

void neo_write_LED(uint8_t index, uint8_t * color);

void neo_write_LEDs(uint8_t * color);

void write_LEDs(uint8_t r, uint8_t g, uint8_t b);



//NEEDED FUNCTIONS: Pairing , error, paired, listening, notificaiton



#endif /* INC_NEOPIXELS_HPP_ */
