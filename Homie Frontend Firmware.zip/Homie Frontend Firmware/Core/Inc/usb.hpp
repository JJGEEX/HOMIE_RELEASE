/*
 * usb.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion and Justin
 */

#ifndef INC_USB_HPP_
#define INC_USB_HPP_
#include "stm32wbxx_hal.h"
#include "stm32wbxx_hal_dma.h"


#include "OS.hpp"
#include "led.hpp"

//PCD_HandleTypeDef hpcd_USB_FS;

#define USB_printf usb_printf

#ifdef __cplusplus

#include <string>

void USB_Init(Circular_Buffer* my_buffer);
void usb_printf(const std::string aTxEndMessage);

#endif


void USB_Send(char* aTxEndMessage, uint32_t size);
void USB_Sent(char* aTxEndMessage, uint32_t size);

void USB_Receive(char* aRxBuffer, uint32_t size);

uint8_t USB_Busy(void);

//uint32_t* Open_Stream(uint8_t* data_array, uint32_t size, uint32_t* micpointer);
uint32_t Open_Stream();
void Close_Stream();
void Play_Stream();
void Pause_Stream();
void Stream_Ping();

void c_usb_printf(char* aTxEndMessage);


void input(char* message, char* aRxBuffer, uint8_t rx_buffersize);



void MX_USB_PCD_Init(void);

enum{
	STREAM_RESTART,
	STREAM_OFF,
	STREAM_ON_PAUSE,
	STREAM_ON_PLAY,
};

#endif /* INC_USB_HPP_ */
