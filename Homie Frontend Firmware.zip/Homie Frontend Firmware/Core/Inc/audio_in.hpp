/*
 * audio_in.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_AUDIO_IN_HPP_
#define INC_AUDIO_IN_HPP_

#include "stm32wbxx_hal.h"
#include "I2S.hpp"
#include "OS.hpp"
#include <string.h>

#define MIC_BUFFER_SIZE 1000
#define MIC_FREQ_SCALING 4

#ifdef __cplusplus
class Mic {
  private:
	I2S* my_i2s;

  public:
    Mic(Circular_Buffer* my_buffer, I2S* Mic_i2s);
    ~Mic();


};
#endif
void mic_callback(void);
void mic_flushBuffers(void);

#endif /* INC_AUDIO_IN_HPP_ */
