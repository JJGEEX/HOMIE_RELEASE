/*
 * app_data.hpp
 *
 *  Created on: Apr 6, 2021
 *      Author: thwai
 */

#ifndef INC_APP_DATA_HPP_
#define INC_APP_DATA_HPP_
#include "app.hpp"


extern bool AI_block;
extern bool Stream_block;
extern Circular_Buffer * my_buffer;
extern Circular_Buffer * my_output_buffer;

void WiFi_streamPing();
void WIFI_STREAMEVT(void);
void I2S_Done(void);
void WIFI_PACKETCHECK(void);

void WiFi_resetFortuneCookie(void);


#endif /* INC_APP_DATA_HPP_ */
