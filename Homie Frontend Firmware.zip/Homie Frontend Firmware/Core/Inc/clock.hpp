/*
 * clock.hpp
 *
 *  Created on: Oct 11, 2020
 *      Author: xavion
 */

#ifndef INC_CLOCK_HPP_
#define INC_CLOCK_HPP_

#include "stm32wbxx_hal.h"
#include "stm32wbxx_hal_tim.h"
#include "schedule.hpp"
#include "error_handling.hpp"
#include "stdio.h" // For sprintf()
#include "usb.hpp"

// GLOBAL VARIABLES ===============//
extern TIM_HandleTypeDef htim16;

// ================================//

//RTC_HandleTypeDef hrtc;

void MX_RTC_Init(void);
void SystemClock_Config(void);
void MX_TIM16_Init(void);
void RTC_Init(void);
void fetch_time(RTC_TimeTypeDef *sTime);
void fetch_date(RTC_DateTypeDef *sDate);

#endif /* INC_CLOCK_HPP_ */
