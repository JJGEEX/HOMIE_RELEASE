/*
 * audio_out.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_AUDIO_OUT_HPP_
#define INC_AUDIO_OUT_HPP_

#include "stm32wbxx_hal.h"
#include "I2S.hpp"
#include "OS.hpp"
#include "beep.hpp"

#define SPEAKER_BUFFER_SIZE 8000//100//4000
#define SPEAKER_SCALING 64//64

#define INBUF_SIZE		4096*2


#ifdef __cplusplus
class Speaker {
  private:
	I2S* my_i2s;

  public:
    Speaker(Circular_Buffer* my_buffer, I2S* Mic_i2s);
    ~Speaker();

};
#endif

void speaker_callback(void);

#endif /* INC_AUDIO_OUT_HPP_ */
