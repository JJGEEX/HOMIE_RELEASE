/*
 * error_handling.hpp
 *
 *  Created on: Oct 14, 2020
 *      Author: xavion
 */

#ifndef INC_ERROR_HANDLING_HPP_
#define INC_ERROR_HANDLING_HPP_


void Error_Handler(void);


#endif /* INC_ERROR_HANDLING_HPP_ */
