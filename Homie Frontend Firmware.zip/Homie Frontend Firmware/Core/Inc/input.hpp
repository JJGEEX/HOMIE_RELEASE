/*
 * input.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_INPUT_HPP_
#define INC_INPUT_HPP_

#include "stm32wbxx_hal.h"



#endif /* INC_INPUT_HPP_ */
