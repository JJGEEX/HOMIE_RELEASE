/*
 * circular_buffer.hpp
 *
 *  Created on: Nov 3, 2020
 *      Author: thwai
 */



#ifndef INC_CIRCULAR_BUFFER_HPP_
#define INC_CIRCULAR_BUFFER_HPP_

#define CIRCULAR_ARRAY_SIZE 8000
#include "stm32wbxx_hal.h"
#include "OS.hpp"
#include <string.h>


////#define
//typedef uint32 uint32_t

#ifdef __cplusplus
class Circular_Buffer {
  private:
    uint32_t size;
    uint32_t write;
    uint32_t read;
    int16_t* my_array;

  public:
    Circular_Buffer (uint32_t my_size);
    ~Circular_Buffer ();
    int front_write(int16_t* data, uint32_t length);
    int back_read(int16_t* data, uint32_t length);
    int back_read_noloop(int16_t* data, uint32_t length);
    uint8_t back_read_u8(int16_t* data, uint32_t length);
    uint32_t back_read_more(int16_t* data, uint32_t max_length);
    int read_ready(uint32_t length);
    int write_ready(uint32_t length);
    uint32_t get_size(void);
    void empty_buffer();
};

#endif





#endif /* INC_CIRCULAR_BUFFER_HPP_ */
