/*
 * rotary_encoder.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_ROTARY_ENCODER_HPP_
#define INC_ROTARY_ENCODER_HPP_

#include "stm32wbxx_hal.h"



#endif /* INC_ROTARY_ENCODER_HPP_ */
