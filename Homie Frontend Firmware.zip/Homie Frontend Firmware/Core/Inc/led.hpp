/*
 * led.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_LED_HPP_
#define INC_LED_HPP_

#include "stm32wbxx_hal.h"
#include "pin_io.hpp"

enum{
	LED1 = 0,
	LED2 = 1,
	LED3 = 2
};

void toggle_LED(int led);

#define LEDPORT2 LD2_GPIO_Port
#define LEDPIN2 LD2_Pin

#define LEDPORT3 LD3_GPIO_Port
#define LEDPIN3 LD3_Pin


#endif /* INC_LED_HPP_ */
