/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* 						NOTES

DMA Channels --------------------------------------------------------------

DMA1_Channel1 = I2S IN
DMA1_Channel2 = USART1 RX
DMA1_Channel3 = USART1 TX
DMA1_Channel4 = I2S Out

Pins-----------------------------------------------------------------------

	PA1     ------> WIFI_BUSY
    PA5     ------> SPI1_SCK
	PA6     ------> SPI1_MISO
    PA7     ------> SPI1_MOSI
    PA8     ------> SAI1_SCK_A   CLK	BCLK
	PA9     ------> SAI1_FS_A    WS		LRCL
    PA10    ------> SAI1_SD_A   DATA 	DOUT





	PB2     ------> SPI1_CS

	PB5     ------> SAI1_SD_B    DATA   DIN
 	PB6     ------> USART1_TX
	PB7     ------> USART1_RX
	PB13    ------> PB3 blocks it
	PB15    ------> Blocked by PB5

	PC4     ------> WIFI_RESET











*/




















/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H



#ifdef __cplusplus
extern "C" {
#endif





/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/


/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN Private defines */



/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif


/* Includes ------------------------------------------------------------------*/
#include "stm32wbxx_hal.h"
#include "ai.hpp"
#include "alpha_numeric.hpp"
#include "app.hpp"
#include "audio_in.hpp"
#include "audio_out.hpp"
#include "circular_buffer.hpp"
#include "clock.hpp"
#include "communication.hpp"
#include "display.hpp"
#include "ezvr.hpp"
#include "I2C.hpp"
#include "I2S.hpp"
#include "input.hpp"
#include "led.hpp"
#include "neopixels.hpp"
#include "pin_io.hpp"
#include "push_button.hpp"
#include "rotary_encoder.hpp"
#include "schedule.hpp"
#include "SPI.hpp"
#include "uart.hpp"
#include "usb.hpp"
#include "wifi.hpp"
#include "OS.hpp" // base hpp files

//#include "neo-neopixels.hpp"

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
