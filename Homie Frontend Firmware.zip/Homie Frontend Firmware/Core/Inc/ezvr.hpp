/*
 * ezvr.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_EZVR_HPP_
#define INC_EZVR_HPP_

#include "stm32wbxx_hal.h"



#endif /* INC_EZVR_HPP_ */
