/*
 * pin_io.hpp
 *
 *  Created on: Oct 11, 2020
 *      Author: xavion
 */

#ifndef INC_PIN_IO_HPP_
#define INC_PIN_IO_HPP_

#include "stm32wbxx_hal.h"
#include "stm32wb55xx.h"

#define DEV_BOARD


#define LD2_Pin GPIO_PIN_0                 //LED
#define LD2_GPIO_Port GPIOB               //LED
#define LD3_Pin GPIO_PIN_1               //LED
#define LD3_GPIO_Port GPIOB             //LED

#define B1_Pin GPIO_PIN_4                   //pushbuttons
#define B1_GPIO_Port GPIOC						//pushbuttons
#define B2_Pin GPIO_PIN_0
#define B2_GPIO_Port GPIOD
#define B3_Pin GPIO_PIN_1      //buttons
#define B3_GPIO_Port GPIOD

#define JTMS_Pin GPIO_PIN_13
#define JTMS_GPIO_Port GPIOA
#define JTCK_Pin GPIO_PIN_14          //system cl0ck
#define JTCK_GPIO_Port GPIOA

#define JTDO_Pin GPIO_PIN_3
#define JTDO_GPIO_Port GPIOB

#define LD1_Pin GPIO_PIN_5                         //LED
#define LD1_GPIO_Port GPIOB						 //LED


#define WIFI_BUSY_Pin GPIO_PIN_1
#define WIFI_BUSY_Port GPIOA
#define WIFI_RESET_Pin GPIO_PIN_4
#define WIFI_RESET_Port GPIOC


#define STLINK_RX_Pin GPIO_PIN_6
#define STLINK_RX_GPIO_Port GPIOB
#define STLINK_TX_Pin GPIO_PIN_7
#define STLINK_TX_GPIO_Port GPIOB      //usart pins */


#define SPI1_SCK_Pin GPIO_PIN_5
#define SPI1_SCK_Port GPIOA
#define SPI1_MISO_Pin GPIO_PIN_6
#define SPI1_MISO_Port GPIOA
#define SPI1_MOSI_Pin GPIO_PIN_7                        //LED
#define SPI1_MOSI_Port GPIOA   //MOSI

#define SPI1_SCK_MISO_MOSI_Port GPIOA

#ifdef DEV_BOARD
#define SPI1_CS_Pin GPIO_PIN_2
#define SPI1_CS_Port GPIOB
#endif
#ifdef HOMIE_BOARD_R1
#define SPI1_CS_Port GPIOA
#define SPI1_CS_Pin GPIO_PIN_4
#endif

//#define I2S_Amp_Port		GPIOB
//#define I2S_Amp_FS_Pin		GPIO_PIN_12
//#define I2S_Amp_SCK_Pin		GPIO_PIN_13
////#define I2S_Amp_SDIN_Pin	GPIO_PIN_7
//
//#define I2S_Amp_SDIN_Port	GPIOC
//#define I2S_Amp_SDIN_Pin	GPIO_PIN_3

#define I2S_Amp_Port		GPIOB
#define I2S_Amp_FS_Pin		GPIO_PIN_6
#define I2S_Amp_SDIN_Pin	GPIO_PIN_5

//#define I2S_Amp_SDIN_Pin	GPIO_PIN_7

#define I2S_Amp_SCK_Port	GPIOC
#define I2S_Amp_SCK_Pin		GPIO_PIN_9



void MX_GPIO_Init(void);





#endif /* INC_PIN_IO_HPP_ */
