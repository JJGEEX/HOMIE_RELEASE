/*
 * I2S.hpp
 *
 *  Created on: Feb 23, 2021
 *      Author: thwai
 */

#ifndef INC_I2S_HPP_
#define INC_I2S_HPP_

#include "OS.hpp"
#include "stm32wbxx_hal.h"
#include "stm32wbxx_hal_sai.h"
#include "stm32wbxx_hal_dma.h"

#ifdef __cplusplus


class I2S {
  private:
	SAI_HandleTypeDef hsai_BlockA1 = {0};
	SAI_HandleTypeDef hsai_BlockB1 = {0};
	DMA_HandleTypeDef dma_handleA1 = {0};
	DMA_HandleTypeDef dma_handleB1 = {0};

//	void (*speaker_callback)(void);
//	void (*mic_callback)(void);



  public:

    I2S();
    ~I2S();
    bool speaker_init(void (*function)(void), int32_t* buffer, uint16_t size);
    bool mic_init(void (*function)(void), int32_t* buffer, uint16_t size);
//    void tone_gen(unsigned int frequency, unsigned int duration);

};
#endif



#endif /* INC_I2S_HPP_ */



///*
// * I2S.hpp
// *
// *  Created on: Oct 9, 2020
// *      Author: xavion and Justin
// */
//
//#ifndef INC_I2S_HPP_
//#define INC_I2S_HPP_
//
//#include "OS.hpp"
//#include "stm32wbxx_hal.h"
//#include "stm32wbxx_hal_sai.h"
//#include "stm32wbxx_hal_dma.h"
////#include "usb.hpp"
////SAI_HandleTypeDef hsai_BlockA1;
//
//#define I2S_BUFFER_SIZE 400
//#define I2S_SCALING 4
//
//
//#ifdef __cplusplus
//
//class I2S {
//  private:
//	Circular_Buffer* circular_data_buffer;
//	uint32_t writing_pointer;
//	uint32_t data_buffer[I2S_BUFFER_SIZE];
//	uint32_t ready;
//
//
//
//  public:
//    I2S();
//    ~I2S();
//    uint32_t start_mic(void);
//    uint32_t load_data(void);
//    void add_buffer(Circular_Buffer* data);
//    void remove_buffer(void);
//    void mic_init(void);
////    uint32_t audio_ready(void);
//
//};
//
//extern I2S Mic_i2s;
//
////void I2S_Init(Circular_Buffer* my_buffer);
//#endif
//
////void MX_SAI1_Init(void);
////void I2S_Data(void);
////uint32_t* start_mic(int16_t* array_pointer, uint32_t size);
////uint32_t start_mic();
//
////uint32_t audio_ready(void);
//
//
//
//#endif /* INC_I2S_HPP_ */
