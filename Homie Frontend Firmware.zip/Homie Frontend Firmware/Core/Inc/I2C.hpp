/*
 * I2C.hpp
 *
 *  Created on: Oct 9, 2020
 *      Author: xavion
 */

#ifndef INC_I2C_HPP_
#define INC_I2C_HPP_

#include "stm32wbxx_hal.h"
#include "error_handling.hpp"

//I2C_HandleTypeDef hi2c1;

void MX_I2C1_Init(void);



#endif /* INC_I2C_HPP_ */
